/**
 * =====================================================
 * RAIMIS - BACKEND SERVER
 * =====================================================
 */

const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
const PORT = 3000;
const IP_ADDRESS = '0.0.0.0'; // Accessible across the local network

// =====================================================
// 1. MIDDLEWARE & CONFIGURATION
// =====================================================
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.static('public')); // Serves static frontend files (HTML/CSS/JS)

// Database Configuration
const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "raimis_db",
    password: "luigi",
    port: 5432
});

// Test Database Connection
pool.connect()
    .then(() => console.log("✅ RAIMIS Database: Connected successfully"))
    .catch(err => console.error("❌ Database Connection Error:", err));

/**
 * Helper: Converts 24-hour time string to 12-hour AM/PM format
 * @param {string} timeStr - Format "HH:MM:SS" or "HH:MM"
 */
const formatAMPM = (timeStr) => {
    if (!timeStr) return "";
    let [hours, minutes] = timeStr.split(':');
    hours = parseInt(hours);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${minutes.substring(0, 2)} ${ampm}`;
};

// =====================================================
// 2. API ENDPOINTS
// =====================================================

/**
 * POST: Create a Manual Reservation
 */
app.post('/api/reservations', async(req, res) => {
    const { room, section, date, start, end, purpose, subject, professor } = req.body;

    // Basic Validation
    if (!room || !subject || !professor) {
        return res.status(400).json({ error: "Missing required fields: Room, Subject, and Professor are mandatory." });
    }

    try {
        const query = `
            INSERT INTO reservations (room, section, date, start_time, end_time, purpose, subject, professor, status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'APPROVED')
            RETURNING *`;
        const values = [room, section, date, start, end, purpose, subject, professor];
        const result = await pool.query(query, values);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error("Database Error:", err.message);
        res.status(500).json({ error: "Failed to record reservation." });
    }
});

/**
 * GET: Real-time Room Status Check
 * Used by Kiosk Dashboard to determine if a room is currently occupied.
 */
app.get('/api/kiosk/check-status/:room_id', async(req, res) => {
    const { room_id } = req.params;
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = days[new Date().getDay()];

    const now = new Date();
    const currentTime = now.toTimeString().split(' ')[0]; // Returns "HH:MM:SS"

    try {
        // Query to check if current time falls within a scheduled class
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND start_time <= $3 
            AND end_time >= $3
            LIMIT 1`;
        const result = await pool.query(query, [room_id, today, currentTime]);

        if (result.rows.length > 0) {
            res.json({ occupied: true, data: result.rows[0] });
        } else {
            res.json({ occupied: false });
        }
    } catch (err) {
        console.error("Status Check Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

/**
 * POST: Add Semester Schedule (Admin Entry)
 * Includes Conflict Validation to prevent overlapping schedules.
 */
app.post('/api/fixed-schedules', async(req, res) => {
    const { room, day, course, subject, prof, start, end } = req.body;

    if (!room || !day || !start || !end) {
        return res.status(400).json({
            success: false,
            error: "Incomplete details: Room, Day, Start Time, and End Time are required."
        });
    }

    try {
        // 1. Conflict Validation
        // Logic: Checks if (NewStart < ExistingEnd) AND (NewEnd > ExistingStart)
        const checkConflictQuery = `
            SELECT subject, start_time, end_time 
            FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND (start_time < $4 AND end_time > $3)
            LIMIT 1
        `;

        const conflictResult = await pool.query(checkConflictQuery, [room, day, start, end]);

        if (conflictResult.rows.length > 0) {
            const conflict = conflictResult.rows[0];
            const formattedStart = formatAMPM(conflict.start_time);
            const formattedEnd = formatAMPM(conflict.end_time);

            return res.status(409).json({
                success: false,
                error: `Schedule Conflict: Room already booked for "${conflict.subject}" from ${formattedStart} to ${formattedEnd}.`
            });
        }

        // 2. Insertion Logic
        const insertQuery = `
            INSERT INTO fixed_schedules (
                room_id, day_of_week, course_section, subject, professor, start_time, end_time
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7) 
            RETURNING *;
        `;

        const result = await pool.query(insertQuery, [room, day, course, subject, prof, start, end]);

        res.status(201).json({
            success: true,
            message: "Schedule successfully recorded.",
            data: result.rows[0]
        });

    } catch (err) {
        console.error("Transaction Error:", err.message);
        res.status(500).json({
            success: false,
            error: "Server error during schedule processing."
        });
    }
});

/**
 * GET: Retrieve All Fixed Schedules
 * Ordered by day and time for the Admin Dashboard.
 */
app.get('/api/fixed-schedules', async(req, res) => {
    try {
        const result = await pool.query('SELECT * FROM fixed_schedules ORDER BY day_of_week, start_time');
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/**
 * DELETE: Remove a specific Fixed Schedule
 */
app.delete('/api/fixed-schedules/:id', async(req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query('DELETE FROM fixed_schedules WHERE id = $1', [id]);
        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, error: "Schedule not found." });
        }
        res.json({ success: true, message: "Schedule deleted successfully." });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/**
 * GET: Fetch Upcoming Classes for a Specific Room
 * Filters schedules for today that haven't ended yet.
 */
app.get('/api/kiosk/upcoming-semester/:room_id', async(req, res) => {
    const { room_id } = req.params;
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = days[new Date().getDay()];
    const currentTime = new Date().toTimeString().split(' ')[0];

    try {
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND end_time > $3
            ORDER BY start_time ASC`;
        const result = await pool.query(query, [room_id, today, currentTime]);
        res.json(result.rows);
    } catch (err) {
        console.error("Fetch Upcoming Error:", err.message);
        res.status(500).json({ error: err.message });
    }
});

// Kunin lahat ng maintenance
app.get('/api/maintenance/status', async(req, res) => {
    try {
        const result = await pool.query('SELECT * FROM room_maintenance');
        res.json(result.rows);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Endpoint para i-save ang maintenance status
app.post('/api/maintenance/lock', async(req, res) => {
    const { room_id, reason } = req.body;
    try {
        // Gagamit tayo ng ON CONFLICT para kung naka-lock na, i-u-update lang ang reason
        const query = `
            INSERT INTO room_maintenance (room_id, reason) 
            VALUES ($1, $2) 
            ON CONFLICT (room_id) DO UPDATE SET reason = $2
            RETURNING *`;
        const result = await pool.query(query, [room_id, reason]);
        res.json({ success: true, data: result.rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Database error" });
    }
});

// Endpoint para tanggalin ang maintenance (Unlock)
app.delete('/api/maintenance/unlock/:room_id', async(req, res) => {
    const { room_id } = req.params;
    try {
        await pool.query('DELETE FROM room_maintenance WHERE room_id = $1', [room_id]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to unlock room" });
    }
});

// Endpoint para makuha ang lahat ng naka-lock na rooms
app.get('/api/maintenance/status', async(req, res) => {
    try {
        const result = await pool.query('SELECT * FROM room_maintenance');
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =====================================================
// 3. SERVER INITIALIZATION
// =====================================================
app.listen(PORT, IP_ADDRESS, () => {
    console.log(`🚀 RAIMIS SERVER RUNNING ON: http://localhost:${PORT}`);
});