/**
 * =====================================================
 * RAIMIS - KIOSK JAVASCRIPT
 * =====================================================
 */

const roomCapacities = {
    "101": 45,
    "102": 40,
    "103": 35,
    "106": 35,
    "107": 35,
    "COURT": 200,
    "202": 40,
    "203": 40,
    "205": 30,
    "207": 30,
    "208": 45,
    "209": 45,
    "210": 45,
    "212": 45,
    "213": 45,
    "301": 50,
    "302": 50,
    "303": 45,
    "304": 45,
    "305": 40,
    "307": 40,
    "308": 40,
    "309": 40,
    "310": 40,
    "401": 35,
    "402": 35,
    "403": 40,
    "404": 40,
    "405": 50,
    "406": 40
};

const rooms = {
    "1st": ["101", "102", "103", "106", "107", "COURT"],
    "2nd": ["202", "203", "205", "207", "208", "209", "210", "212", "213"],
    "3rd": ["301", "302", "303", "304", "305", "307", "308", "309", "310"],
    "4th": ["401", "402", "403", "404", "405", "406"]
};

function init() {
    renderFloors();
    updateClock();
    setInterval(updateClock, 1000);
    setInterval(updateAllRoomStatuses, 3000); // Check status every 3s
}

// -----------------------------------------------------
// ROOM DASHBOARD RENDERING
// -----------------------------------------------------
function renderFloors() {
    const floorsDiv = document.getElementById("floors");
    floorsDiv.innerHTML = "";

    for (let floor in rooms) {
        let floorHTML = `<div class="floor-section">
            <div class="floor-title">${floor} Floor</div>
            <div class="rooms-container">`;

        rooms[floor].forEach(roomNo => {
            const cap = roomCapacities[roomNo] || 0;
            // Binago: Nagdagdag ng 'data-room' attribute at 'room-details' div
            floorHTML += `
                <div class="room-box available" id="room-${roomNo}" onclick="openRoom('${roomNo}')" data-room="${roomNo}">
                    <div class="room-number">${roomNo === "COURT" ? "COURT" : 'Room ' + roomNo}</div>
                    <div id="status-${roomNo}" class="room-info">AVAILABLE</div>
                    <div id="details-${roomNo}" class="room-details" style="font-size: 10px; margin-top: 5px; font-weight: bold; color: #1e3a8a;"></div>
                    <div class="room-capacity">👤 Cap: ${cap}</div>
                </div>`;
        });
        floorHTML += `</div></div>`;
        floorsDiv.innerHTML += floorHTML;
    }
    // Pagkatapos i-render ang boxes, kunin ang data sa server
    updateAllRoomStatuses();
}

async function updateAllRoomStatuses() {
    const allRoomNumbers = Object.values(rooms).flat();
    const now = new Date();
    const currentTimeStr = now.toTimeString().split(' ')[0];
    const nowVal = now.getHours() * 60 + now.getMinutes();

    // 1. Kunin muna ang listahan ng maintenance rooms mula sa API/Server
    let lockedRooms = [];
    try {
        const maintRes = await fetch('/api/maintenance/status');
        lockedRooms = await maintRes.json();
    } catch (err) {
        console.error("Maintenance fetch error:", err);
    }

    for (const roomNo of allRoomNumbers) {
        try {
            const statusEl = document.getElementById(`status-${roomNo}`);
            const detailsEl = document.getElementById(`details-${roomNo}`);
            const roomBox = document.getElementById(`room-${roomNo}`);

            if (!statusEl || !roomBox) continue;

            // Linisin ang lahat ng indicators bago mag-check
            roomBox.classList.remove('available', 'occupied', 'incoming', 'maintenance');

            // 2. CHECK MAINTENANCE (Priority 1 - Gray)
            const isMaint = lockedRooms.find(r => r.room_id === roomNo);
            if (isMaint) {
                roomBox.classList.add('maintenance');
                statusEl.innerText = "MAINTENANCE";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `<div class="status-subtext">${isMaint.reason}</div>`;
                continue; // Laktawan ang schedule check kung maintenance
            }

            // 3. FETCH SCHEDULES (Para sa Red at Yellow)
            const response = await fetch(`/api/kiosk/upcoming-semester/${roomNo}`);
            const schedules = await response.json();

            const ongoing = schedules.find(s => currentTimeStr >= s.start_time && currentTimeStr <= s.end_time);

            const nextClass = schedules.find(s => {
                if (currentTimeStr < s.start_time) {
                    const [sH, sM] = s.start_time.split(':').map(Number);
                    const startVal = sH * 60 + sM;
                    return (startVal - nowVal) > 0 && (startVal - nowVal) <= 360;
                }
                return false;
            });

            // 4. APPLY INDICATORS
            if (ongoing) {
                // RED INDICATOR
                roomBox.classList.add('occupied');
                statusEl.innerText = "OCCUPIED";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `
                    <div class="status-subtext">Ends: ${formatTo12Hour(ongoing.end_time)}</div>
                    <div class="subject-tag">${ongoing.subject}</div>
                    <div class="prof-tag">Prof. ${ongoing.professor}</div>
                `;
            } else if (nextClass) {
                // YELLOW INDICATOR
                roomBox.classList.add('incoming');
                statusEl.innerText = "UPCOMING";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `
                    <div class="status-subtext">Starts: ${formatTo12Hour(nextClass.start_time)}</div>
                    <div class="subject-tag">${nextClass.subject}</div>
                    <div class="prof-tag">Prof. ${nextClass.professor}</div>
                `;
            } else {
                // GREEN INDICATOR
                roomBox.classList.add('available');
                statusEl.innerText = "AVAILABLE";
                detailsEl.style.display = "none";
            }
        } catch (err) {
            console.error(`Error updating room ${roomNo}:`, err);
        }
    }
}

async function checkMaintenanceStatus() {
    try {
        const res = await fetch('/api/maintenance/status');
        const lockedRooms = await res.json();

        // I-reset muna lahat ng maintenance class
        document.querySelectorAll('.room-box').forEach(box => box.classList.remove('maintenance'));

        lockedRooms.forEach(data => {
            const roomBox = document.getElementById(`room-${data.room_id}`);
            if (roomBox) {
                roomBox.classList.add('maintenance');
                const statusEl = document.getElementById(`status-${data.room_id}`);
                if (statusEl) statusEl.innerText = "MAINTENANCE";

                const detailsEl = document.getElementById(`details-${data.room_id}`);
                if (detailsEl) detailsEl.innerHTML = `<div class="status-subtext">${data.reason}</div>`;
            }
        });
    } catch (err) {
        console.error("Maintenance check error:", err);
    }
}

// Tawagin ito tuwing mag-u-update (halimbawa, bawat minuto)
setInterval(checkMaintenanceStatus, 5000); // Check every 5 seconds

// Variables para sa RFID System
let rfidBuffer = "";
let isModalOpen = false;
let selectedRoomForReserve = "";

// -----------------------------------------------------
// KIOSK MODAL
// -----------------------------------------------------
function openRoom(roomNo) {
    const modal = document.getElementById("modal");
    const modalBody = document.querySelector(".kiosk-modal-body");
    const todayString = new Date().toISOString().split('T')[0];
    const roomBox = document.getElementById(`room-${roomNo}`);

    // CHECK: Kung ang box ay may class na 'maintenance', huwag ituloy
    if (roomBox && roomBox.classList.contains('maintenance')) {
        Swal.fire({
            icon: 'error',
            title: 'Room Unavailable',
            text: 'This room is currently under maintenance and cannot be viewed.',
            confirmButtonColor: '#1e3a8a'
        });
        return;
    }

    // I-set ang state na bukas ang modal para gumana ang RFID scanner
    isModalOpen = true;
    selectedRoomForReserve = roomNo;
    rfidBuffer = ""; // I-reset ang scanner buffer

    modal.style.display = "flex";
    document.getElementById("roomTitle").innerText = roomNo === "COURT" ? "Covered Court" : "Room " + roomNo;

    // NILAGYAN NG MGA "id" ANG BAWAT INPUT AT BUTTON
    modalBody.innerHTML = `
        <div style="display: flex; gap: 20px; min-height: 480px; width: 850px; align-items: stretch; margin: 0 auto;">
            
            <div style="flex: 1.5; display: flex; flex-direction: column; gap: 12px;">
                <div id="rfidStatus" style="background: #fef08a; color: #854d0e; padding: 10px; text-align: center; font-weight: 800; border-radius: 8px; font-size: 13px; border: 1px solid #fde047;">
                    🔐 TAP RFID TO START
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 5px;">
                    <div style="grid-column: span 2;">
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">👥 Section/Organization</label>
                        <input type="text" id="formSection" placeholder="Waiting for RFID..." disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📅 Date</label>
                        <input type="date" id="formDate" value="${todayString}" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🎯 Purpose</label>
                        <select id="formPurpose" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                            <option>CLASS</option>
                            <option>EVENT</option>
                            <option>MEETING</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📖 Subject</label>
                        <input type="text" id="formSubject" placeholder="e.g. DBMS" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">👨‍🏫 Professor</label>
                        <input type="text" id="formProf" placeholder="Instructor Name" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🕒 Start Time</label>
                        <input type="time" id="formStart" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🕒 End Time</label>
                        <input type="time" id="formEnd" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                </div>

                <button id="submitBtn" disabled style="margin-top: auto; background: #94a3b8; color: white; padding: 14px; border: none; border-radius: 8px; font-weight: bold; font-size: 13px; transition: 0.3s;">
                    🔒 LOCKED - TAP RFID
                </button>
            </div>

            <div style="flex: 1.1; background: #f8fafc; padding: 15px; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; flex-direction: column; max-height: 520px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">
                    <span style="font-size: 18px;">📅</span>
                    <h3 style="font-size: 15px; color: #1e3a8a; font-weight: 800; margin: 0;">Existing Schedule</h3>
                </div>
                <div id="modalScheduleList" style="overflow-y: auto; flex-grow: 1; padding-right: 5px;">
                    <p style="text-align:center; font-size:12px; color: #94a3b8; margin-top: 20px;">Loading schedule...</p>
                </div>
            </div>
        </div>`;

    renderRoomSchedule(roomNo);
}

// -----------------------------------------------------
// RFID SCANNER EVENT LISTENER
// -----------------------------------------------------
document.addEventListener('keydown', function(e) {
    if (!isModalOpen) return; // Wag pansinin kung nakasara ang modal

    if (e.key === 'Enter') {
        if (rfidBuffer.length > 5) { // Kung may na-scan na ID
            unlockReservationForm();
        }
        rfidBuffer = ""; // I-clear agad pagkatapos
    } else if (e.key.length === 1) {
        rfidBuffer += e.key; // Ipunin ang mga tinatype ng scanner
    }
});

// Function para ma-unlock ang mga inputs sa modal
function unlockReservationForm() {
    // Palitan ang status message sa taas
    const statusDiv = document.getElementById('rfidStatus');
    statusDiv.style.background = '#d1fae5';
    statusDiv.style.color = '#065f46';
    statusDiv.style.borderColor = '#34d399';
    statusDiv.innerHTML = '✅ ACCESS GRANTED. PLEASE FILL DETAILS.';

    // I-enable lahat ng inputs at tanggalin ang gray background
    const inputs = ['formSection', 'formDate', 'formPurpose', 'formSubject', 'formProf', 'formStart', 'formEnd'];
    inputs.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.disabled = false;
            el.style.background = '#ffffff';
            el.style.border = '1.5px solid #3b82f6'; // Blue border to show it's active
        }
    });

    document.getElementById('formSection').placeholder = "e.g. BSIT 3A";

    // I-enable at kulayan ng Green ang Submit button
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = false;
    submitBtn.style.background = '#10b981'; // Green
    submitBtn.style.cursor = 'pointer';
    submitBtn.innerHTML = '✅ CONFIRM RESERVATION';

    // I-attach ang save function
    submitBtn.onclick = submitAdHocReservation;
}


async function renderRoomSchedule(roomNo) {
    const scheduleList = document.getElementById("modalScheduleList");
    const nowFull = new Date();
    const dayName = nowFull.toLocaleDateString('en-US', { weekday: 'long' });

    try {
        const response = await fetch(`/api/kiosk/upcoming-semester/${roomNo}`);
        const schedules = await response.json();

        if (schedules.length === 0) {
            scheduleList.innerHTML = `<div style="text-align:center; margin-top:40px; color:#94a3b8; font-size:13px;">No upcoming classes for today.</div>`;
            return;
        }

        const nowTime = nowFull.toTimeString().split(' ')[0];

        scheduleList.innerHTML = schedules.map(sched => {
            let statusColor = "#4f46e5";
            let statusLabel = "UPCOMING";

            if (nowTime >= sched.start_time && nowTime <= sched.end_time) {
                statusColor = "#ef4444";
                statusLabel = "ON-GOING";
            }

            return `
            <div style="background: white; padding: 15px; border-radius: 12px; margin-bottom: 12px; border-left: 5px solid ${statusColor}; box-shadow: 0 2px 6px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 4px;">
                
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="background: ${statusColor}20; color: ${statusColor}; font-size: 10px; font-weight: 900; padding: 4px 8px; border-radius: 5px; text-transform: uppercase;">
                        ${statusLabel}
                    </span>
                    <div style="font-size: 12px; font-weight: 700; color: #475569; display: flex; align-items: center; gap: 4px;">
                        <span>🕒</span>
                        <span>${formatTo12Hour(sched.start_time)} - ${formatTo12Hour(sched.end_time)}</span>
                    </div>
                </div>
                
                <div style="font-size: 17px; font-weight: 900; color: #0f172a; line-height: 1.2; margin-top: 4px;">
                    ${sched.subject}
                </div>
                
                <div style="font-size: 11px; color: #64748b; font-weight: 600; border-top: 1px solid #f1f5f9; padding-top: 8px; margin-top: 4px;">
                    ${sched.course_section} <span style="color: #cbd5e1; margin: 0 4px;">|</span> Prof. ${sched.professor}
                </div>
            </div>`;
        }).join('');
    } catch (err) {
        scheduleList.innerHTML = `<p style="color:red; text-align:center; font-size:12px;">Connection Error.</p>`;
    }
}

function formatTo12Hour(time) {
    if (!time) return "";
    let [h, m] = time.split(':');
    let ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return `${h}:${m} ${ampm}`;
}

function updateClock() {
    const clockEl = document.getElementById("clock");
    if (clockEl) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        clockEl.innerText = new Date().toLocaleString('en-US', options);
    }
}

function closeModal() {
    document.getElementById("modal").style.display = "none";
    isModalOpen = false;
    rfidBuffer = "";
}

window.onload = init;