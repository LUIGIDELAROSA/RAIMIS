-- 1. Gawa ng Database (Optional kung nakagawa ka na manual)
-- CREATE DATABASE raimis_db;

-- 2. Siguraduhin na malinis ang table kung uulitin ang setup
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS rfid_users;

-- 3. Table para sa mga Rehistradong RFID Cards
-- Mas maganda kung sa DB ito nakalagay kaysa hardcoded sa JS
CREATE TABLE rfid_users (
    rfid_uid VARCHAR(20) PRIMARY KEY,
    section_name VARCHAR(50) NOT NULL,
    student_name VARCHAR(100), -- Optional: para sa records
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Table para sa Room Reservations
CREATE TABLE reservations (
    id SERIAL PRIMARY KEY,
    room VARCHAR(10) NOT NULL,           -- Halimbawa: "101", "405"
    section VARCHAR(50) NOT NULL,        -- Galing sa rfid_users
    date DATE NOT NULL,                  -- Format: YYYY-MM-DD
    start_time TIME NOT NULL,            -- Format: HH:mm:ss
    end_time TIME NOT NULL,              -- Format: HH:mm:ss
    purpose VARCHAR(50) DEFAULT 'CLASS', -- CLASS, MEETING, EXAM, etc.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Initial Data para sa RFID (Para sa testing)
INSERT INTO rfid_users (rfid_uid, section_name) VALUES 
('0006585813', 'BSCpE 1-1'),
('0004768226', 'BSCpE 1-2');

-- 6. Indexing (Para mabilis ang query lalo na kung marami na ang bookings)
CREATE INDEX idx_room_date ON reservations(room, date);

ALTER TABLE reservations ADD COLUMN receipt_claimed BOOLEAN DEFAULT FALSE;
