/**
 * =====================================================
 * RAIMIS - ROOM RESERVATION & AVAILABILITY SYSTEM
 * Final Production Version (2026)
 * =====================================================
 * SYSTEM DESCRIPTION:
 * Manages university room bookings using a kiosk interface. 
 * Features: Real-time DB sync, RFID verification, and status detection.
 */

// =====================================================
// 1. GLOBAL VARIABLES & CONFIGURATION
// =====================================================

let reservations = []; // Holds approved reservation objects
let rfidBuffer = ""; // Temporary storage for RFID keystrokes
let isRfidVerified = false; // Security flag for unlocked state

/** Seating capacity mapping per room */
const roomCapacities = {
    "101": 45,
    "102": 40,
    "103": 35,
    "104": 50,
    "105": 45,
    "201": 40,
    "202": 40,
    "203": 30,
    "204": 30,
    "205": 45,
    "301": 50,
    "302": 50,
    "303": 45,
    "304": 45,
    "305": 40,
    "401": 35,
    "402": 35,
    "403": 40,
    "404": 40,
    "405": 50
};

// =====================================================
// 2. CORE INITIALIZATION
// =====================================================

async function init() {
    try {
        console.log("🚀 RAIMIS System: Initializing...");

        // Initial setup and rendering
        await loadFromServer();
        renderFloors();
        updateClock();
        updateRoomStatus();
        loadReservationSidebar();
        setupRFIDListener();

        // Intervals for real-time updates
        setInterval(updateClock, 1000); // Refresh clock (1s)
        setInterval(updateRoomStatus, 1000); // Check occupancy (1s) - Adjusted from 0 for stability
        setInterval(loadFromServer, 2000); // Sync DB (2s)

        console.log("✅ RAIMIS System: Ready.");
    } catch (error) {
        console.error("❌ Critical Initialization Error:", error);
    }
}

// =====================================================
// 3. DATA PERSISTENCE (API INTEGRATION)
// =====================================================

/** Fetches and filters APPROVED records from PostgreSQL */
async function loadFromServer() {
    try {
        const response = await fetch('http://localhost:3000/api/reservations');
        if (!response.ok) throw new Error("Server communication failed");

        const data = await response.json();

        // Data Transformation: Keep only APPROVED and format for UI
        reservations = data
            .filter(res => res.status === 'APPROVED')
            .map(res => {
                const d = new Date(res.date);
                return {
                    room: res.room.toString(),
                    section: res.section,
                    date: d.toISOString().split('T')[0],
                    start: res.start_time.substring(0, 5),
                    end: res.end_time.substring(0, 5),
                    purpose: res.purpose
                };
            });

        updateRoomStatus();
    } catch (err) {
        console.error("Fetch Error:", err);
    }
}

/** Sends a PENDING reservation request to the server */
async function saveReservation(roomNo) {
    const submitBtn = document.getElementById("submitBtn");
    const resData = {
        room: roomNo,
        section: document.getElementById('formSection').value,
        date: document.getElementById('formDate').value,
        start_time: document.getElementById('formStart').value,
        end_time: document.getElementById('formEnd').value,
        purpose: document.getElementById('formPurpose').value,
        status: 'PENDING'
    };

    try {
        submitBtn.disabled = true;
        submitBtn.innerHTML = "⌛ Wait for Approval...";

        const response = await fetch('http://localhost:3000/api/reserve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(resData)
        });

        if (response.ok) {
            submitBtn.style.background = "#22c55e";
            submitBtn.innerHTML = "✅ Sent Successfully!";

            setTimeout(() => {
                Swal.fire({
                    title: 'Success!',
                    text: 'Request submitted to Admin.',
                    icon: 'success',
                    timer: 1500,
                    showConfirmButton: false
                });
                closeModal();
            }, 2000);
        } else {
            throw new Error("Failed to send");
        }
    } catch (err) {
        console.error("Save Error:", err);
        Swal.fire('Error', 'Hindi maipadala ang request.', 'error');
        submitBtn.disabled = false;
        submitBtn.style.background = "#1e3a8a";
        submitBtn.innerHTML = "✅ CONFIRM RESERVATION";
    }
}

// =====================================================
// 4. RFID SECURITY LOGIC
// =====================================================

/** Global listener for RFID scanner inputs (acting as keyboard) */
function setupRFIDListener() {
    document.addEventListener('keydown', function(event) {
        const modal = document.getElementById('modal');
        if (isRfidVerified || modal.style.display !== 'flex') return;

        if (event.key === 'Enter') {
            event.preventDefault();
            if (rfidBuffer.length > 0) {
                handleRFIDInput(rfidBuffer.trim());
                rfidBuffer = "";
            }
        } else if (event.key.length === 1) {
            rfidBuffer += event.key;
        }
    });
}

/** Validates RFID UID and unlocks the form on success */
async function handleRFIDInput(uid) {
    try {
        const response = await fetch('http://localhost:3000/api/verify-rfid', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ uid })
        });

        const data = await response.json();
        const sectionInput = document.getElementById("formSection");
        const submitBtn = document.getElementById("submitBtn");
        const lockMsg = document.getElementById("rfid-lock-message");

        if (data.success) {
            isRfidVerified = true;
            sectionInput.value = data.section;
            lockMsg.style.background = "#dcfce7";
            lockMsg.innerHTML = `✅ <strong>VERIFIED: ${data.section}</strong>`;
            submitBtn.innerHTML = "🕐 INPUT TIME FIRST";
            submitBtn.style.background = "#94a3b8";
        } else {
            showInvalidCardFeedback(uid);
        }
    } catch (err) {
        console.error("RFID Verification Failed:", err);
    }
}

/** Visual error state for invalid cards */
function showInvalidCardFeedback(uid) {
    const lockMsg = document.getElementById('rfid-lock-message');
    const submitBtn = document.getElementById('submitBtn');

    lockMsg.innerHTML = `❌ <strong>INVALID CARD (${uid})</strong><br><small>Use registered Student ID</small>`;
    lockMsg.style.background = "#fee2e2";
    lockMsg.style.color = "#ef4444";
    submitBtn.disabled = true;
    submitBtn.innerHTML = "🔐 ACCESS DENIED";

    setTimeout(() => {
        if (!isRfidVerified) {
            lockMsg.innerHTML = `🔐 <strong>TAP YOUR RFID CARD</strong><br><small>Student ID required to unlock</small>`;
            lockMsg.style.background = "#fef3c7";
            lockMsg.style.color = "";
            submitBtn.innerHTML = "🔐 LOCKED - TAP RFID";
        }
    }, 3000);
}

// =====================================================
// 5. MODAL & RESERVATION UI
// =====================================================

/** Opens the booking interface for a specific room */
function openRoom(roomNo) {
    const modal = document.getElementById("modal");
    const modalBody = document.querySelector(".kiosk-modal-body");
    const today = new Date().toLocaleDateString('en-CA');

    modal.style.display = "flex";
    document.getElementById("roomTitle").innerText = "Room " + roomNo;

    modalBody.innerHTML = `
        <div class="modal-split-view" style="display: flex; gap: 20px; min-height: 400px;">
            <div class="form-side" style="flex: 1.2; padding-right: 20px; border-right: 2px solid #f1f5f9;">
                <div id="rfid-lock-message" class="rfid-prompt-large" style="text-align:center; padding:15px; background:#fef3c7; border-radius:10px; margin-bottom:15px;">
                    🔐 <strong>TAP RFID TO START</strong>
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label>👥 Section/Organization</label>
                    <input type="text" id="formSection" readonly placeholder="Waiting for RFID..." style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                </div>
                <div class="form-row" style="display: flex; gap: 10px; margin-bottom:15px;">
                    <div style="flex: 1.2;">
                        <label>📅 Date</label>
                        <input type="date" id="formDate" value="${today}" min="${today}"
                               onchange="checkConflicts('${roomNo}'); renderRoomSchedule('${roomNo}')"
                               style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                    </div>
                    <div style="flex: 0.8;">
                        <label>🎯 Purpose</label>
                        <select id="formPurpose" style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px; background:white;">
                            <option value="CLASS">CLASS</option>
                            <option value="MEETING">MEETING</option>
                            <option value="EXAM">EXAM</option>
                            <option value="EVENT">EVENT</option>
                        </select>
                    </div>
                </div>
                <div class="form-row" style="display: flex; gap: 10px; margin-bottom:20px;">
                    <div style="flex: 1;">
                        <label>🕐 Start</label>
                        <input type="time" id="formStart" oninput="checkConflicts('${roomNo}')" style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                    </div>
                    <div style="flex: 1;">
                        <label>🕑 End</label>
                        <input type="time" id="formEnd" oninput="checkConflicts('${roomNo}')" style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                    </div>
                </div>
                <button id="submitBtn" disabled onclick="saveReservation('${roomNo}')" style="width:100%; padding:15px; background:#94a3b8; color:white; border:none; border-radius:10px; font-weight:bold; cursor:not-allowed;">
                    🔐 LOCKED - TAP RFID
                </button>
            </div>
            <div class="schedule-side" style="flex: 0.8; background: #f8fafc; padding: 15px; border-radius: 12px; overflow-y: auto;">
                <h3 style="font-size: 16px; color: #1e3a8a; margin-bottom: 15px; border-bottom: 2px solid #e2e8f0; padding-bottom: 5px;">📅 Upcoming Schedule</h3>
                <div id="modalScheduleList"></div>
            </div>
        </div>`;

    renderRoomSchedule(roomNo);
}

/** Handles logical validation and overlap detection */
function checkConflicts(roomNo) {
    const start = document.getElementById("formStart").value;
    const end = document.getElementById("formEnd").value;
    const submitBtn = document.getElementById("submitBtn");
    const lockMsg = document.getElementById("rfid-lock-message");

    if (!start || !end) {
        submitBtn.disabled = true;
        submitBtn.style.background = "#94a3b8";
        submitBtn.innerText = "🔐 INPUT TIME FIRST";
        return;
    }

    if (end <= start) {
        lockMsg.style.background = "#fee2e2";
        lockMsg.innerHTML = "⚠️ <strong>INVALID TIME:</strong> End must be later than start.";
        submitBtn.disabled = true;
        submitBtn.style.background = "#ef4444";
        return;
    }

    const conflict = reservations.find(r => r.room === roomNo && (start < r.end && end > r.start));

    if (conflict) {
        submitBtn.disabled = true;
        submitBtn.innerText = "❌ SLOT OCCUPIED";
    } else if (isRfidVerified) {
        submitBtn.disabled = false;
        submitBtn.style.background = "#1e3a8a";
        submitBtn.innerText = "✅ CONFIRM RESERVATION";
        submitBtn.style.cursor = "pointer";
    }
}

/** Resets all modal variables and UI states */
function closeModal() {
    document.getElementById('modal').style.display = 'none';
    isRfidVerified = false;
    rfidBuffer = "";

    const lockMsg = document.getElementById("rfid-lock-message");
    const sectionInput = document.getElementById("formSection");
    const submitBtn = document.getElementById("submitBtn");

    if (lockMsg) {
        lockMsg.innerHTML = `🔐 <strong>TAP RFID TO START</strong>`;
        lockMsg.style.background = "#fef3c7";
        lockMsg.style.color = "";
    }
    if (sectionInput) sectionInput.value = "";
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.style.background = "#94a3b8";
        submitBtn.innerHTML = "🔐 LOCKED - TAP RFID";
        submitBtn.style.cursor = "not-allowed";
    }
}

// =====================================================
// 6. DASHBOARD RENDERING & STATUS UPDATES
// =====================================================

/** Creates the physical layout of rooms on the dashboard */
function renderFloors() {
    const floorsDiv = document.getElementById("floors");
    floorsDiv.innerHTML = "";

    for (let floor = 1; floor <= 4; floor++) {
        let floorHTML = `<div class="floor"><h3>Floor ${floor}</h3><div class="rooms-grid">`;
        for (let room = 1; room <= 5; room++) {
            const roomNo = `${floor}0${room}`;
            const cap = roomCapacities[roomNo] || 40;
            floorHTML += `
                <div class="room available" id="room${roomNo}" onclick="openRoom('${roomNo}')">
                    <div class="room-number">Room ${roomNo}</div>
                    <div class="room-info">AVAILABLE</div>
                    <div class="room-timer"></div>
                    <div class="room-capacity">🪑 Cap: ${cap}</div>
                </div>`;
        }
        floorHTML += `</div></div>`;
        floorsDiv.innerHTML += floorHTML;
    }
}

/** Logic to determine room colors (Green/Red/Yellow) based on time */
function updateRoomStatus() {
    const now = new Date();
    const today = now.toLocaleDateString('en-CA');
    const currentTime = now.getHours().toString().padStart(2, '0') + ":" +
        now.getMinutes().toString().padStart(2, '0');

    // Reset all to available first
    document.querySelectorAll('.room').forEach(el => {
        el.className = 'room available';
        const info = el.querySelector('.room-info');
        const timer = el.querySelector('.room-timer');
        if (info) info.innerText = "AVAILABLE";
        if (timer) timer.innerText = "";
    });

    // Apply specific status based on reservation schedule
    reservations.forEach(res => {
        if (res.date !== today) return;

        const roomEl = document.getElementById(`room${res.room}`);
        if (!roomEl) return;

        const info = roomEl.querySelector('.room-info');
        const timer = roomEl.querySelector('.room-timer');

        if (currentTime >= res.start && currentTime < res.end) {
            roomEl.classList.remove('available', 'upcoming');
            roomEl.classList.add('occupied');
            if (info) info.innerText = res.section;
            if (timer) timer.innerText = `Ends: ${formatTo12Hour(res.end)}`;
        } else if (isUpcoming(currentTime, res.start, 120)) {
            if (!roomEl.classList.contains('occupied')) {
                roomEl.classList.remove('available');
                roomEl.classList.add('upcoming');
                if (info) info.innerText = "UPCOMING: " + res.section;
                if (timer) timer.innerText = `Starts: ${formatTo12Hour(res.start)}`;
            }
        }
    });

    // Update Header Counts
    const totalRooms = 20;
    const occupiedCount = document.querySelectorAll('.room.occupied').length;
    const availableCount = totalRooms - occupiedCount;

    const availableEl = document.querySelector('.header-stats div:nth-child(1)');
    const occupiedEl = document.querySelector('.header-stats div:nth-child(2)');
    const freeTextEl = document.querySelector('.floor-header span');

    if (availableEl) availableEl.innerText = `${availableCount} Available`;
    if (occupiedEl) occupiedEl.innerText = `${occupiedCount} Occupied`;
    if (freeTextEl) freeTextEl.innerText = `${availableCount}/${totalRooms} rooms free`;
}

function isUpcoming(current, start, threshold) {
    const [currH, currM] = current.split(':').map(Number);
    const [startH, startM] = start.split(':').map(Number);
    const diff = (startH * 60 + startM) - (currH * 60 + currM);
    return diff > 0 && diff <= threshold;
}

// =====================================================
// 7. RECEIPT & PENDING APPROVAL MODAL
// =====================================================

/** Initializes the Receipt/Approval overlay listeners */
document.addEventListener('DOMContentLoaded', function() {
    const openBtn = document.getElementById('openApprovalBtn');
    const closeBtn = document.getElementById('closeBox');
    const overlay = document.getElementById('pendingContainer');
    const modalBox = document.getElementById('modalBox');

    if (openBtn) {
        openBtn.onclick = function() {
            overlay.style.display = 'flex';
            modalBox.classList.remove('animate-close');
            modalBox.classList.add('animate-open');
            loadPendingList();
        };
    }

    if (closeBtn) closeBtn.onclick = closeOverlay;

    overlay.onclick = function(e) {
        if (e.target === overlay) closeOverlay();
    };

    function closeOverlay() {
        modalBox.classList.remove('animate-open');
        modalBox.classList.add('animate-close');
        setTimeout(() => { overlay.style.display = 'none'; }, 300);
    }
});

/** Fetches and displays reservations for receipt claiming */
async function loadPendingList() {
    const content = document.getElementById('pendingContent');

    try {
        const response = await fetch('http://localhost:3000/api/reservations');
        if (!response.ok) throw new Error('Network response was not ok');

        const data = await response.json();
        const list = data.filter(res => res.status !== 'REJECTED' && res.receipt_claimed !== true);

        if (list.length === 0) {
            content.innerHTML = `<div style="text-align:center; padding:40px; color:#94a3b8;"><p style="font-size: 32px;">✅</p><p>Walang aktibong requests o claimed na lahat.</p></div>`;
            return;
        }

        content.innerHTML = `
            <table class="modal-table">
                <thead>
                    <tr><th>Room</th><th>Section</th><th>Schedule</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                    ${list.map(p => {
                        const isApproved = p.status === 'APPROVED';
                        const resId = p.id || p.reservation_id;
                        return `
                        <tr id="row-${resId}">
                            <td>Room ${p.room}</td>
                            <td>${p.section}</td>
                            <td>${p.date} (${formatTo12Hour(p.start_time)} - ${formatTo12Hour(p.end_time)})</td>
                            <td><span class="status-pill ${isApproved ? 'status-approved' : 'status-pending'}">${p.status}</span></td>
                            <td>
                                <button class="btn-receipt" ${!isApproved ? 'disabled' : ''} onclick="generateReceipt('${resId}')">
                                    ${isApproved ? '📄 Get Receipt' : '⏳ Waiting...'}
                                </button>
                            </td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>`;
    } catch (err) {
        console.error("Load Error:", err);
        content.innerHTML = `<div style="color:red; text-align:center; padding:20px;">Connection failed.</div>`;
    }
}

/** Handles receipt claim logic and row removal animation */
async function generateReceipt(id) {
    const row = document.getElementById(`row-${id}`);
    if (!row) return;

    try {
        const response = await fetch(`http://localhost:3000/api/reservations/${id}/claim`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' }
        });

        if (response.ok) {
            removeRowWithAnimation(row);
        } else {
            alert("Failed to update database.");
        }
    } catch (err) {
        console.error("Network Error:", err);
    }
}

function removeRowWithAnimation(rowElement) {
    const btn = rowElement.querySelector('button');
    if (btn) btn.disabled = true;

    rowElement.style.transition = "all 0.6s cubic-bezier(0.4, 0, 0.2, 1)";
    rowElement.style.opacity = "0";
    rowElement.style.transform = "translateX(50px)";
    rowElement.style.backgroundColor = "#fee2e2";

    setTimeout(() => {
        rowElement.remove();
        const tbody = document.querySelector('.modal-table tbody');
        if (!tbody || tbody.children.length === 0) {
            document.getElementById('pendingContent').innerHTML = 
                `<div style="text-align:center; padding:40px; color:#94a3b8;"><p style="font-size: 32px;">✅</p><p>All receipts claimed!</p></div>`;
        }
    }, 600);
}

// =====================================================
// 8. UI HELPERS
// =====================================================

function renderRoomSchedule(roomNo) {
    const listContainer = document.getElementById("modalScheduleList");
    const today = new Date().toLocaleDateString('en-CA');
    const currentTime = new Date().toTimeString().substring(0, 5);

    const filtered = reservations.filter(res =>
        res.room === roomNo && (res.date > today || (res.date === today && res.end > currentTime))
    ).sort((a, b) => a.date.localeCompare(b.date) || a.start.localeCompare(b.start));

    listContainer.innerHTML = filtered.length ? filtered.map(res => `
        <div style="background: white; border-left: 4px solid #1e3a8a; padding: 10px; margin-bottom: 10px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <div style="font-size: 10px; font-weight: bold; color: #64748b;">${res.date}</div>
            <div style="font-size: 13px; font-weight: bold; color: #1e3a8a;">${res.section}</div>
            <div style="font-size: 12px;">🕒 ${formatTo12Hour(res.start)} - ${formatTo12Hour(res.end)}</div>
        </div>
    `).join('') : "<p style='text-align:center; font-size:12px; color:#94a3b8;'>No upcoming bookings.</p>";
}

function loadReservationSidebar() {
    const list = document.getElementById("sideReservationList");
    if (!list) return;

    const today = new Date().toLocaleDateString('en-CA');
    const activeToday = reservations.filter(r => r.date === today).sort((a, b) => a.start.localeCompare(b.start));

    list.innerHTML = activeToday.length ? activeToday.map(r => `
        <div style="border-bottom:1px solid #eee; padding:8px; font-size:12px;">
            <b>Room ${r.room}</b> - ${r.section}<br>
            🕒 ${formatTo12Hour(r.start)} to ${formatTo12Hour(r.end)}
        </div>`).join('') : "<p style='padding:10px; font-size:12px;'>No active bookings today</p>";
}

function formatTo12Hour(time) {
    if (!time) return "";
    let [h, m] = time.split(':');
    let ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return `${h}:${m} ${ampm}`;
}

function updateClock() {
    const clockEl = document.getElementById("clock");
    if (clockEl) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        clockEl.innerText = new Date().toLocaleString('en-US', options);
    }
}

// Launch the system
init();