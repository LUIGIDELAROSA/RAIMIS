-- 1. Gawa ng Database (Optional kung nakagawa ka na manual)
-- CREATE DATABASE raimis_db;

-- 2. Siguraduhin na malinis ang table kung uulitin ang setup
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS rfid_users;

-- 3. Table para sa mga Rehistradong RFID Cards
-- Mas maganda kung sa DB ito nakalagay kaysa hardcoded sa JS

CREATE TABLE reservations (
    id SERIAL PRIMARY KEY,
    room VARCHAR(10) NOT NULL,          -- Halimbawa: "101", "COURT"
    rfid_tag VARCHAR(50),               -- ID ng card ng nag-tap
    section VARCHAR(50) NOT NULL,       -- Section o Org
    subject VARCHAR(100),               -- Subject name
    professor VARCHAR(100),             -- Pangalan ng Instructor
    date DATE NOT NULL,                 -- Petsa ng reservation
    start_time TIME NOT NULL,           -- Oras ng simula
    end_time TIME NOT NULL,             -- Oras ng pagtatapos
    purpose VARCHAR(50) DEFAULT 'CLASS',-- CLASS, MEETING, etc.
    status VARCHAR(20) DEFAULT 'PENDING',-- PENDING, APPROVED, REJECTED
    print_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Fixed Weekly Class Schedules
CREATE TABLE fixed_schedules (
    id SERIAL PRIMARY KEY,
    room_id VARCHAR(50) NOT NULL,
    day_of_week VARCHAR(20) NOT NULL, -- Monday, Tuesday, etc.
    course_section VARCHAR(100) NOT NULL, -- e.g., BSIT 3A
    subject VARCHAR(150) NOT NULL, -- e.g., Web Development
    professor VARCHAR(150) NOT NULL, -- e.g., Prof. Juan
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table para sa Maintenance (Gray Logic)
CREATE TABLE room_maintenance (
    room_id VARCHAR(50) PRIMARY KEY,
    reason TEXT,
    locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE fixed_schedules ADD COLUMN is_cancelled BOOLEAN DEFAULT FALSE;

CREATE TABLE rfid_users (
    id SERIAL PRIMARY KEY,
    rfid_serial VARCHAR(50) NOT NULL UNIQUE,
    identifier VARCHAR(100) NOT NULL,
    role VARCHAR(20) CHECK (role IN ('professor', 'student')) NOT NULL,
    security_pin VARCHAR(4) NOT NULL,
    additional_info JSONB, -- Mas maganda ang JSONB sa Postgres kaysa TEXT
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE rfid_users 
ADD COLUMN cancel_strikes INT DEFAULT 0,
ADD COLUMN is_blocked BOOLEAN DEFAULT false;

CREATE TABLE room_cancellations (
    id SERIAL PRIMARY KEY,
    schedule_id INT NOT NULL,          -- ID ng fixed class galing sa fixed_schedules table
    cancelled_date DATE NOT NULL,      -- Ang eksaktong petsa kung kailan cinancel ang klase
    cancelled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_fixed_schedule FOREIGN KEY (schedule_id) REFERENCES fixed_schedules(id) ON DELETE CASCADE
);