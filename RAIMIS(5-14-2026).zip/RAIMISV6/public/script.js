/**
 * =====================================================
 * RAIMIS - KIOSK JAVASCRIPT
 * This script runs the Kiosk display. Its job is to 
 * show the rooms on the screen and update their status 
 * (Available or Occupied) every few seconds.
 * =====================================================
 */

// A simple list (Dictionary) of how many students can fit in each room.
const roomCapacities = {
    "101": 45,
    "102": 40,
    "103": 35,
    "106": 35,
    "107": 35,
    "COURT": 200,
    "202": 40,
    "203": 40,
    "205": 30,
    "207": 30,
    "208": 45,
    "209": 45,
    "210": 45,
    "212": 45,
    "213": 45,
    "301": 50,
    "302": 50,
    "303": 45,
    "304": 45,
    "305": 40,
    "307": 40,
    "308": 40,
    "309": 40,
    "310": 40,
    "401": 35,
    "402": 35,
    "403": 40,
    "404": 40,
    "405": 50,
    "406": 40
};

// Organizing the rooms by which Floor they are on.
const rooms = {
    "1st": ["101", "102", "103", "106", "107", "COURT"],
    "2nd": ["202", "203", "205", "207", "208", "209", "210", "212", "213"],
    "3rd": ["301", "302", "303", "304", "305", "307", "308", "309", "310"],
    "4th": ["401", "402", "403", "404", "405", "406"]
};

/**
 * The Start Function:
 * This runs as soon as the Kiosk screen turns on.
 */
function init() {
    renderFloors(); // Draw the rooms on the screen
    updateClock(); // Show the current time
    setInterval(updateClock, 1000); // Refresh the clock every 1 second
    setInterval(updateAllRoomStatuses, 3000); // Ask the server for room updates every 3 seconds
}

// -----------------------------------------------------
// ROOM DASHBOARD RENDERING
// This part actually creates the "Boxes" you see on the screen.
// -----------------------------------------------------
function renderFloors() {
    const floorsDiv = document.getElementById("floors");
    floorsDiv.innerHTML = ""; // Clear the screen first

    // Loop through each floor (1st, 2nd, etc.)
    for (let floor in rooms) {
        let floorHTML = `
            <div class="floor-section">
                <div class="floor-title">${floor} Floor</div>
                <div class="rooms-container">`;

        // Loop through each room on that specific floor
        rooms[floor].forEach(roomNo => {
            const cap = roomCapacities[roomNo] || 0; // Get the capacity number

            // Create the HTML for the Room Box
            floorHTML += `
                <div class="room-box available" id="room-${roomNo}" onclick="openRoom('${roomNo}')" data-room="${roomNo}">
                    <div class="room-number">${roomNo === "COURT" ? "COURT" : 'Room ' + roomNo}</div>
                    
                    <div id="status-${roomNo}" class="room-info">AVAILABLE</div>
                    
                    <div id="details-${roomNo}" class="room-details" style="font-size: 10px; margin-top: 5px; font-weight: bold; color: #1e3a8a;"></div>
                    
                    <div class="room-capacity">👤 Cap: ${cap}</div>
                </div>`;
        });

        floorHTML += `</div></div>`;
        floorsDiv.innerHTML += floorHTML; // Add the finished floor to the screen
    }

    // Immediately check the server to see which rooms are currently in use
    updateAllRoomStatuses();
}

/**
 * updateAllRoomStatuses:
 * This is the most important function for the Kiosk.
 * It constantly checks: "What is happening in this room right now?"
 */
async function updateAllRoomStatuses() {
    const allRoomNumbers = Object.values(rooms).flat();
    const now = new Date();
    const currentTimeStr = now.toTimeString().split(' ')[0]; // "HH:MM:SS"
    const nowVal = now.getHours() * 60 + now.getMinutes();

    // 1. Isang beses lang i-fetch ang maintenance para sa lahat
    let lockedRooms = [];
    try {
        const maintRes = await fetch('/api/maintenance/status');
        lockedRooms = await maintRes.json();
    } catch (err) { console.error("Maint error:", err); }

    for (const roomNo of allRoomNumbers) {
        try {
            const statusEl = document.getElementById(`status-${roomNo}`);
            const detailsEl = document.getElementById(`details-${roomNo}`);
            const roomBox = document.getElementById(`room-${roomNo}`);
            if (!statusEl || !roomBox) continue;

            roomBox.classList.remove('available', 'occupied', 'incoming', 'maintenance');

            // CHECK MAINTENANCE (Priority 1)
            const isMaint = lockedRooms.find(r => r.room_id === roomNo);
            if (isMaint) {
                roomBox.classList.add('maintenance');
                statusEl.innerText = "MAINTENANCE";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `<div class="status-subtext">${isMaint.reason}</div>`;
                continue;
            }

            // FETCH DATA
            const [semRes, reserveRes] = await Promise.all([
                fetch(`/api/kiosk/upcoming-semester/${roomNo}`),
                fetch(`http://192.168.1.2:3000/api/approved-reservations/${roomNo}`) // Siguraduhin na kasama rito ang Pending kung gusto mo makita
            ]);

            const semSchedules = await semRes.json();
            const reservations = await reserveRes.json();

            // NORMALIZATION & SORTING (Importante ang sort para makuha ang pinakamalapit na schedule)
            const allActivities = [
                ...semSchedules.map(s => ({...s, type: 'CLASS' })),
                ...reservations.map(r => ({
                    ...r,
                    type: 'RESERVATION',
                    course_section: r.section || 'RESERVATION',
                    professor: r.professor || 'N/A',
                    start_time: r.start_time,
                    end_time: r.end_time,
                    is_cancelled: false // I-assume na false kung approved na ito
                }))
            ].sort((a, b) => a.start_time.localeCompare(b.start_time)); // I-sort mula umaga hanggang gabi

            // 3. CHECK ONGOING
            const ongoing = allActivities.find(s =>
                currentTimeStr >= s.start_time &&
                currentTimeStr <= s.end_time &&
                !s.is_cancelled
            );

            // 4. CHECK UPCOMING (Dapat ay para sa araw na ito lang)
            const nextClass = allActivities.find(s => {
                if (currentTimeStr < s.start_time && !s.is_cancelled) {
                    const [sH, sM] = s.start_time.split(':').map(Number);
                    const startVal = sH * 60 + sM;
                    const diff = startVal - nowVal;
                    // Ipakita lang kung loob ng 6 hours (360 mins) at hindi pa nakalipas
                    return diff > 0 && diff <= 360;
                }
                return false;
            });

            // 5. RENDER LOGIC
            if (ongoing) {
                roomBox.classList.add('occupied');
                statusEl.innerText = "OCCUPIED";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `
                    <div class="course-tag">${ongoing.course_section}</div>
                    <div class="subject-tag">${ongoing.subject}</div>
                    <div class="prof-tag">Prof. ${ongoing.professor}</div>
                    <div class="status-subtext">ENDS: ${formatTo12Hour(ongoing.end_time)}</div>
                `;
            } else if (nextClass) {
                // Dito mo pwedeng i-check kung "Pending" ang reservation
                const isPending = nextClass.status === 'Pending';
                roomBox.classList.add('incoming');
                statusEl.innerText = isPending ? "PENDING" : "UPCOMING";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `
                    <div class="course-tag">${nextClass.course_section}</div>
                    <div class="subject-tag">${nextClass.subject}</div>
                    <div class="prof-tag">Prof. ${nextClass.professor}</div>
                    <div class="status-subtext">STARTS: ${formatTo12Hour(nextClass.start_time)}</div>
                `;
            } else {
                roomBox.classList.add('available');
                statusEl.innerText = "AVAILABLE";
                detailsEl.innerHTML = ""; // Linisin ang lumang text
                detailsEl.style.display = "none";
            }
        } catch (err) {
            console.error(`Error:`, err);
        }
    }
}

/**
 * checkMaintenanceStatus:
 * This is a secondary helper that specifically double-checks 
 * the maintenance status every 5 seconds.
 */
async function checkMaintenanceStatus() {
    try {
        const res = await fetch('/api/maintenance/status');
        const lockedRooms = await res.json();

        // Clear the maintenance color from all rooms first
        document.querySelectorAll('.room-box').forEach(box => box.classList.remove('maintenance'));

        // Put the Gray color back on only the rooms that are actually locked
        lockedRooms.forEach(data => {
            const roomBox = document.getElementById(`room-${data.room_id}`);
            if (roomBox) {
                roomBox.classList.add('maintenance');
                const statusEl = document.getElementById(`status-${data.room_id}`);
                if (statusEl) statusEl.innerText = "MAINTENANCE";

                const detailsEl = document.getElementById(`details-${data.room_id}`);
                if (detailsEl) detailsEl.innerHTML = `<div class="status-subtext">${data.reason}</div>`;
            }
        });
    } catch (err) {
        console.error("Maintenance check error:", err);
    }
}

// Start the timer: Check for "Broken" rooms every 5 seconds
setInterval(checkMaintenanceStatus, 5000);

/**
 * =====================================================
 * KIOSK MODAL & RFID SYSTEM
 * =====================================================
 */

// Variables to keep track of the RFID scanner and the popup window
let rfidBuffer = ""; // This "catches" the numbers sent by the RFID scanner
let isModalOpen = false; // Tells the computer if the popup is currently on screen
let selectedRoomForReserve = ""; // Remembers which room you clicked on

/**
 * openRoom:
 * This opens the popup (Modal) when you click a room box.
 */
function openRoom(roomNo) {
    const modal = document.getElementById("modal");
    const modalBody = document.querySelector(".kiosk-modal-body");
    const todayString = new Date().toISOString().split('T')[0]; // Get today's date
    const roomBox = document.getElementById(`room-${roomNo}`);

    // 1. SECURITY CHECK: If the room is broken (Maintenance), don't let anyone in!
    if (roomBox && roomBox.classList.contains('maintenance')) {
        Swal.fire({
            icon: 'error',
            title: 'Room Unavailable',
            text: 'This room is currently under maintenance and cannot be viewed.',
            confirmButtonColor: '#1e3a8a'
        });
        return;
    }

    // 2. SET UP THE MODAL: Tell the computer the window is now open
    isModalOpen = true;
    selectedRoomForReserve = roomNo;
    rfidBuffer = ""; // Clear any old scans

    modal.style.display = "flex";
    document.getElementById("roomTitle").innerText = roomNo === "COURT" ? "Covered Court" : "Room " + roomNo;

    // 3. CREATE THE FORM: Notice that everything is "disabled" (locked) at first!
    // The student must tap their RFID card to "Unlock" these inputs.
    modalBody.innerHTML = `
        <div style="display: flex; gap: 20px; min-height: 480px; width: 850px; align-items: stretch; margin: 0 auto;">
            
            <div style="flex: 1.5; display: flex; flex-direction: column; gap: 12px;">
                <div id="rfidStatus" style="background: #fef08a; color: #854d0e; padding: 10px; text-align: center; font-weight: 800; border-radius: 8px; font-size: 13px; border: 1px solid #fde047;">
                    🔐 TAP RFID TO START
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 5px;">
                    <div style="grid-column: span 2;">
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">👥 Section/Organization</label>
                        <input type="text" id="formSection" placeholder="Waiting for RFID..." disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📅 Date</label>
                        <input type="date" id="formDate" value="${todayString}" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🎯 Purpose</label>
                        <select id="formPurpose" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                            <option>CLASS</option>
                            <option>EVENT</option>
                            <option>MEETING</option>
                            <option>EXAM</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📖 Subject</label>
                        <input type="text" id="formSubject" placeholder="e.g. DBMS" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">👨‍🏫 Professor</label>
                        <input type="text" id="formProf" placeholder="Instructor Name" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🕒 Start Time</label>
                        <input type="time" id="formStart" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🕒 End Time</label>
                        <input type="time" id="formEnd" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 4px;">
                    </div>
                </div>

                <button id="submitBtn" disabled style="margin-top: auto; background: #94a3b8; color: white; padding: 14px; border: none; border-radius: 8px; font-weight: bold; font-size: 13px; transition: 0.3s;">
                    🔒 LOCKED - TAP RFID
                </button>
            </div>

            <div style="flex: 1.1; background: #f8fafc; padding: 15px; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; flex-direction: column; max-height: 520px;">
                <!-- Header with Options -->
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 18px;">📅</span>
                        <h3 style="font-size: 15px; color: #1e3a8a; font-weight: 800; margin: 0;">Existing Schedule</h3>
                    </div>
                    
                    <!-- Dropdown Selector -->
                    <select id="dayFilter" onchange="renderRoomSchedule('${roomNo}', this.value)" style="font-size: 11px; padding: 4px; border-radius: 6px; border: 1px solid #cbd5e1; outline: none; cursor: pointer; background: white; font-weight: 600; color: #334155;">
                        <option value="today">TODAY</option>
                        <option value="Monday">MONDAY</option>
                        <option value="Tuesday">TUESDAY</option>
                        <option value="Wednesday">WEDNESDAY</option>
                        <option value="Thursday">THURSDAY</option>
                        <option value="Friday">FRIDAY</option>
                        <option value="Saturday">SATURDAY</option>
                    </select>
                </div>

                <!-- Scrollable Content -->
                <div id="modalScheduleList" style="overflow-y: auto; flex-grow: 1; padding-right: 5px;">
                    <p style="text-align:center; font-size:12px; color: #94a3b8; margin-top: 20px;">Loading schedule...</p>
                </div>
            </div>
        </div>`;

    // Load the existing classes so students can see when the room is free
    renderRoomSchedule(roomNo);
}

/**
 * RFID SCANNER LISTENER:
 * This is always "listening" for a card tap. 
 * Most RFID scanners act like a super-fast keyboard that types 
 * a number and hits "Enter."
 */
document.addEventListener('keydown', function(e) {
    if (!isModalOpen) return; // If the popup isn't open, don't do anything

    if (e.key === 'Enter') {
        // If the scanner finished typing a long number (more than 5 digits)
        if (rfidBuffer.length > 5) {
            unlockReservationForm(); // This is the function that makes the inputs clickable!
        }
        rfidBuffer = ""; // Clear the buffer for the next person
    } else if (e.key.length === 1) {
        // Collect each number typed by the scanner one by one
        rfidBuffer += e.key;
    }
});

/**
 * unlockReservationForm:
 * This function handles the visual "transformation" of the popup
 * once the student taps their ID card.
 */
function unlockReservationForm() {
    // 1. UPDATE THE TOP MESSAGE
    // Changes the yellow "TAP RFID" box into a green "ACCESS GRANTED" box.
    const statusDiv = document.getElementById('rfidStatus');
    statusDiv.style.background = '#d1fae5'; // Light Green background
    statusDiv.style.color = '#065f46'; // Dark Green text
    statusDiv.style.borderColor = '#34d399';
    statusDiv.innerHTML = '✅ ACCESS GRANTED. PLEASE FILL DETAILS.';

    // 2. UNLOCK ALL INPUT FIELDS
    // We have a list of all the ID names for the text boxes and dropdowns.
    const inputs = ['formSection', 'formDate', 'formPurpose', 'formSubject', 'formProf', 'formStart', 'formEnd'];

    // KUNIN ANG PETSA NGAYON (Format: YYYY-MM-DD)
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;

    inputs.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.disabled = false;
            el.style.background = '#ffffff';
            el.style.border = '1.5px solid #3b82f6';

            // AUTOMATIC DATE SETTING:
            if (id === 'formDate') {
                el.value = formattedDate; // Dito natin ilalagay ang petsa ngayon
                el.min = formattedDate; // OPTIONAL: Pinipigilan ang student na mag-book ng past dates
            }
        }
    });

    inputs.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.disabled = false; // This makes the box clickable/typeable
            el.style.background = '#ffffff'; // Changes the box color to White
            el.style.border = '1.5px solid #3b82f6'; // Adds a Blue border to show it's active
        }
    });

    // Change the placeholder text to guide the student
    document.getElementById('formSection').placeholder = "e.g. BSIT 3A";

    // 3. ACTIVATE THE SUBMIT BUTTON
    // Changes the button from a gray "Locked" state to a bright green "Confirm" state.
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = false;
    submitBtn.style.background = '#10b981'; // Green color
    submitBtn.style.cursor = 'pointer'; // Makes the mouse cursor turn into a "hand" icon
    submitBtn.innerHTML = '✅ CONFIRM RESERVATION';

    // 4. ATTACH THE ACTION
    // Tells the button: "When you are clicked, run the function that saves the data to the database."
    submitBtn.onclick = submitAdHocReservation;
}

/**
 * Unified Validation: Checks for logic errors and schedule conflicts.
 * Returns true if valid, false if there's an error.
 */
async function isReservationValid(data, activities) {

    // Extract HH:MM only
    const newStart = data.start_time.substring(0, 5);
    const newEnd = data.end_time.substring(0, 5);

    // Get current date and time
    const now = new Date();
    const currentTime = now.toTimeString().substring(0, 5);
    const todayDate = now.toISOString().split('T')[0];

    // =====================================================
    // 1. CHECK INVALID TIME RANGE
    // =====================================================
    if (newEnd <= newStart) {

        await Swal.fire({
            icon: 'error',
            title: 'Invalid Time Range',
            text: 'The End Time must be later than the Start Time.',
            confirmButtonColor: '#ef4444'
        });

        return false;
    }

    // =====================================================
    // 2. CHECK PAST TIME IF DATE IS TODAY
    // =====================================================
    if (data.date === todayDate && newStart < currentTime) {

        await Swal.fire({
            icon: 'warning',
            title: 'Time Already Passed',
            text: `You cannot book ${formatTo12Hour(newStart)} because the current time is already ${formatTo12Hour(currentTime)}.`,
            confirmButtonColor: '#f59e0b'
        });

        return false;
    }

    // =====================================================
    // 3. CHECK SCHEDULE CONFLICT
    // =====================================================
    const conflict = activities.find(sched =>
        !sched.is_cancelled &&
        newStart < sched.end_time.substring(0, 5) &&
        newEnd > sched.start_time.substring(0, 5)
    );

    if (conflict) {

        await Swal.fire({
            icon: 'warning',
            title: 'Schedule Conflict',
            text: 'This time slot is already occupied.',
            confirmButtonColor: '#f59e0b'
        });

        return false;
    }

    // Reservation is valid
    return true;
}

/**
 * This function executes when the "CONFIRM RESERVATION" button is clicked.
 */
async function submitAdHocReservation() {

    // =====================================================
    // 1. COLLECT FORM DATA
    // =====================================================
    const reservationData = {
        room: selectedRoomForReserve,
        section: formSection.value,
        date: formDate.value,
        start_time: formStart.value,
        end_time: formEnd.value,
        purpose: formPurpose.value,
        subject: formSubject.value,
        professor: formProf.value
    };

    // =====================================================
    // 2. CHECK REQUIRED FIELDS
    // =====================================================
    if (!reservationData.section ||
        !reservationData.start_time ||
        !reservationData.end_time) {

        return Swal.fire(
            'Error',
            'Please fill in the Section and Time fields.',
            'error'
        );
    }

    try {

        // =====================================================
        // 3. FETCH EXISTING SCHEDULES
        // =====================================================
        const [semRes, reserveRes] = await Promise.all([
            fetch(`/api/kiosk/upcoming-semester/${reservationData.room}`),
            fetch(`http://192.168.1.2:3000/api/approved-reservations/${reservationData.room}`)
        ]);

        // Combine classes and reservations
        const allActivities = [
            ...(await semRes.json()).map(s => ({...s, type: 'CLASS' })),
            ...(await reserveRes.json()).map(r => ({
                ...r,
                type: 'RESERVATION',
                is_cancelled: false
            }))
        ];

        // =====================================================
        // 4. VALIDATE RESERVATION
        // =====================================================
        if (!(await isReservationValid(reservationData, allActivities))) return;

        // =====================================================
        // 5. SUBMIT RESERVATION
        // =====================================================
        const response = await fetch(
            'http://192.168.1.2:3000/api/reservations', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(reservationData)
            }
        );

        // =====================================================
        // 6. HANDLE SERVER RESPONSE
        // =====================================================
        if (response.ok) {

            Swal.fire(
                'Success',
                'Reservation sent for approval!',
                'success'
            );

            closeModal();

            if (typeof updateAllRoomStatuses === 'function') {
                updateAllRoomStatuses();
            }

        } else {

            Swal.fire({
                icon: 'warning',
                title: 'Schedule Conflict',
                text: 'This time slot is already occupied.',
                confirmButtonColor: '#f59e0b'
            });
        }

    } catch (err) {

        // =====================================================
        // 7. HANDLE SYSTEM ERRORS
        // =====================================================
        console.error('System Error:', err);

        Swal.fire(
            'Error',
            'Could not connect to the server.',
            'error'
        );
    }
}

// HELPER FUNCTION: Kinukuha ang eksaktong petsa (YYYY-MM-DD) ng piniling araw sa linggong ito
function getTargetDate(selectedDay) {
    if (selectedDay === 'today') return new Date().toISOString().split('T')[0];

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const targetDayIndex = days.indexOf(selectedDay);
    const now = new Date();
    const currentDayIndex = now.getDay();

    // Kunin ang petsa ng piniling araw (kukuwentahin mula sa araw ngayon)
    const diff = targetDayIndex - currentDayIndex;
    const targetDate = new Date(now);
    targetDate.setDate(now.getDate() + diff);

    const year = targetDate.getFullYear();
    const month = String(targetDate.getMonth() + 1).padStart(2, '0');
    const day = String(targetDate.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

/**
 * renderRoomSchedule:
 * This draws the "Existing Schedule" list on the right side of the popup.
 * It helps students avoid booking a room that already has a class.
 */
async function renderRoomSchedule(roomNo, selectedDay = 'today') {
    const scheduleList = document.getElementById("modalScheduleList");
    const nowFull = new Date();
    const nowTime = nowFull.toTimeString().split(' ')[0];

    // I-convert ang napiling araw para sa reservation fetch
    const targetDateStr = getTargetDate(selectedDay);

    try {
        // 1. Ipasa ang selectedDay at targetDate bilang "query parameters" (?day=...)
        const [semRes, reserveRes] = await Promise.all([
            fetch(`/api/kiosk/upcoming-semester/${roomNo}?day=${selectedDay}`),
            fetch(`http://192.168.1.2:3000/api/approved-reservations/${roomNo}?date=${targetDateStr}`)
        ]);

        const semSchedules = await semRes.json();
        const reservations = await reserveRes.json();

        // 2. MERGE & TAG
        const combined = [
            ...semSchedules.map(s => ({...s, type: 'CLASS' })),
            ...reservations.map(r => ({
                ...r,
                type: 'RESERVATION',
                course_section: r.section,
                professor: r.professor || 'N/A'
            }))
        ];

        // 3. FILTER LOGIC
        let upcomingAndOngoing = combined;

        // I-filter lang ang mga "tapos na" na klase KUNG ang tinitignan ay schedule "ngayon"
        if (selectedDay === 'today') {
            upcomingAndOngoing = combined.filter(item => item.end_time > nowTime);
        }

        // 4. SORT
        upcomingAndOngoing.sort((a, b) => a.start_time.localeCompare(b.start_time));

        // 5. EMPTY CHECK
        if (upcomingAndOngoing.length === 0) {
            scheduleList.innerHTML = `<div style="text-align:center; margin-top:40px; color:#94a3b8; font-size:13px;">No scheduled activities for this day.</div>`;
            return;
        }

        // 6. DRAW THE LIST
        scheduleList.innerHTML = upcomingAndOngoing.map(item => {
            let statusColor = "#3b82f6"; // Default Blue for other days
            let statusLabel = item.type === 'RESERVATION' ? "RESERVED" : "SCHEDULED";
            let isCancelled = item.is_cancelled === true;

            if (isCancelled) {
                statusColor = "#94a3b8";
                statusLabel = "CANCELLED";
            } else if (selectedDay === 'today') {
                // Gumagana lang ang "On-Going" at "Upcoming" indicator kung TODAY ang schedule
                if (nowTime >= item.start_time && nowTime <= item.end_time) {
                    statusColor = "#ef4444";
                    statusLabel = "ON-GOING";
                } else {
                    statusColor = "#f59e0b";
                    statusLabel = "UPCOMING";
                }
            }

            return `
            <div style="background: white; padding: 15px; border-radius: 12px; margin-bottom: 12px; border-left: 5px solid ${statusColor}; box-shadow: 0 2px 6px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 4px; ${isCancelled ? 'opacity: 0.8;' : ''}">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="background: ${statusColor}20; color: ${statusColor}; font-size: 10px; font-weight: 900; padding: 4px 8px; border-radius: 5px; text-transform: uppercase;">
                        ${statusLabel}
                    </span>
                    <div style="font-size: 12px; font-weight: 700; color: #475569; display: flex; align-items: center; gap: 4px;">
                        <span>🕒</span>
                        <span>${formatTo12Hour(item.start_time)} - ${formatTo12Hour(item.end_time)}</span>
                    </div>
                </div>
                <div style="font-size: 17px; font-weight: 900; color: ${isCancelled ? '#64748b' : '#0f172a'}; line-height: 1.2; margin-top: 4px;">
                    ${item.subject}
                    ${isCancelled ? '<small style="display:block; font-size:10px; color:#ef4444;">(This session is cancelled)</small>' : ''}
                </div>
                <div style="font-size: 11px; color: #64748b; font-weight: 600; border-top: 1px solid #f1f5f9; padding-top: 8px; margin-top: 4px;">
                    ${item.course_section} <span style="color: #cbd5e1; margin: 0 4px;">|</span> Prof. ${item.professor}
                </div>
            </div>`;
        }).join('');

    } catch (err) {
        console.error(err);
        scheduleList.innerHTML = `<p style="color:red; text-align:center; font-size:12px;">Connection Error.</p>`;
    }
}


/**
 * formatTo12Hour:
 * A simple converter. Changes "13:00" to "1:00 PM".
 */
function formatTo12Hour(time) {
    if (!time) return "";
    let [h, m] = time.split(':');
    let ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return `${h}:${m} ${ampm}`;
}

/**
 * updateClock:
 * Keeps the digital clock on the Kiosk dashboard ticking every second.
 */
function updateClock() {
    const clockEl = document.getElementById("clock");
    if (clockEl) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        clockEl.innerText = new Date().toLocaleString('en-US', options);
    }
}

/**
 * closeModal:
 * Hides the popup and clears the RFID memory so the next student starts fresh.
 */
function closeModal() {
    document.getElementById("modal").style.display = "none";
    isModalOpen = false;
    rfidBuffer = "";
}

window.onload = init;