-- 1. Gawa ng Database (Optional kung nakagawa ka na manual)
-- CREATE DATABASE raimis_db;

-- 2. Siguraduhin na malinis ang table kung uulitin ang setup
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS rfid_users;

-- 3. Table para sa mga Rehistradong RFID Cards
-- Mas maganda kung sa DB ito nakalagay kaysa hardcoded sa JS
CREATE TABLE rfid_users (
    rfid_uid VARCHAR(20) PRIMARY KEY,
    section_name VARCHAR(50) NOT NULL,
    student_name VARCHAR(100), -- Optional: para sa records
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reservations (
    id SERIAL PRIMARY KEY,
    room VARCHAR(10) NOT NULL,          -- Halimbawa: "101", "COURT"
    rfid_tag VARCHAR(50),               -- ID ng card ng nag-tap
    section VARCHAR(50) NOT NULL,       -- Section o Org
    subject VARCHAR(100),               -- Subject name
    professor VARCHAR(100),             -- Pangalan ng Instructor
    date DATE NOT NULL,                 -- Petsa ng reservation
    start_time TIME NOT NULL,           -- Oras ng simula
    end_time TIME NOT NULL,             -- Oras ng pagtatapos
    purpose VARCHAR(50) DEFAULT 'CLASS',-- CLASS, MEETING, etc.
    status VARCHAR(20) DEFAULT 'PENDING',-- PENDING, APPROVED, REJECTED
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Initial Data para sa RFID (Para sa testing)
INSERT INTO rfid_users (rfid_uid, section_name) VALUES 
('0006585813', 'BSCpE 1-1'),
('0004768226', 'BSCpE 1-2');

-- 6. Indexing (Para mabilis ang query lalo na kung marami na ang bookings)
CREATE INDEX idx_room_date ON reservations(room, date);

ALTER TABLE reservations ADD COLUMN receipt_claimed BOOLEAN DEFAULT FALSE;

ALTER TABLE reservations ADD COLUMN subject VARCHAR(100);
ALTER TABLE reservations ADD COLUMN professor VARCHAR(100);

-- Table for Fixed Weekly Class Schedules
CREATE TABLE fixed_schedules (
    id SERIAL PRIMARY KEY,
    room_id VARCHAR(50) NOT NULL,
    day_of_week VARCHAR(20) NOT NULL, -- Monday, Tuesday, etc.
    course_section VARCHAR(100) NOT NULL, -- e.g., BSIT 3A
    subject VARCHAR(150) NOT NULL, -- e.g., Web Development
    professor VARCHAR(150) NOT NULL, -- e.g., Prof. Juan
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table para sa Maintenance (Gray Logic)
CREATE TABLE room_maintenance (
    room_id VARCHAR(50) PRIMARY KEY,
    reason TEXT,
    locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE fixed_schedules ADD COLUMN is_cancelled BOOLEAN DEFAULT FALSE;