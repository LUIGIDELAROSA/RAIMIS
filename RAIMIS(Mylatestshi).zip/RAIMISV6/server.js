/**
 * =====================================================
 * RAIMIS - BACKEND SERVER
 * Think of this as the "Brain" of your project.
 * It sits in the middle and connects the website
 * to the database where all the info is stored.
 * =====================================================
 */

const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
const PORT = 3000;
const IP_ADDRESS = '0.0.0.0'; // This lets other devices on your WiFi talk to this server

// =====================================================
// 1. MIDDLEWARE & CONFIGURATION
// (Setting up the tools the server needs)
// =====================================================

// This allows the website and server to talk even if they are on different addresses
app.use(cors({ origin: true, credentials: true }));

// This lets the server read data sent in "JSON" format (the language of APIs)
app.use(express.json());

// This tells the server where your actual website files (HTML/CSS) are located
app.use(express.static('public'));

// Database Configuration: Telling the server how to log into your database
const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "raimis_db",
    password: "luigi",
    port: 5432
});

// Checking if the connection to the database actually works
pool.connect()
    .then(() => console.log("✅ RAIMIS Database: Connected successfully"))
    .catch(err => console.error("❌ Database Connection Error:", err));

/**
 * Helper: This is a small tool to change "Military Time" (21:00) 
 * into "Normal Time" (9:00 PM) so humans can read it easily.
 */
const formatAMPM = (timeStr) => {
    if (!timeStr) return "";
    let [hours, minutes] = timeStr.split(':');
    hours = parseInt(hours);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${minutes.substring(0, 2)} ${ampm}`;
};

// =====================================================
// 2. API ENDPOINTS
// (These are the "Service Windows" of your server)
// =====================================================

/**
 * POST: Create a Manual Reservation
 * Used when someone manually books a room through the Kiosk.
 */
app.post('/api/reservations', async(req, res) => {
    try {
        const { room, section, date, start_time, end_time, purpose, subject, professor } = req.body;

        const query = `INSERT INTO reservations (room, section, date, start_time, end_time, purpose, subject, professor, status) 
                       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'PENDING') RETURNING *`;

        const values = [room, section, date, start_time, end_time, purpose, subject, professor];
        await pool.query(query, values);

        // MASHADONG IMPORTANTE: Mag-send ng 200 o 201 status at JSON
        return res.status(201).json({ success: true, message: "Saved successfully" });

    } catch (err) {
        console.error(err.message);
        // Mag-send ng error status kung pumalya
        return res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/pending-reservations', async(req, res) => {
    try {
        // Siguraduhin na ang 'status' column ay PENDING (all caps dapat kung yun ang nasa code)
        const result = await pool.query("SELECT * FROM reservations WHERE status = 'PENDING' ORDER BY id DESC");
        res.json(result.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

app.put('/api/reservations/:id/status', async(req, res) => {
    const { id } = req.params;
    const { status } = req.body; // 'APPROVED' or 'REJECTED'

    try {
        const query = "UPDATE reservations SET status = $1 WHERE id = $2";
        await pool.query(query, [status, id]);

        res.json({ success: true, message: "Status updated successfully" });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: "Database error" });
    }
});

app.get('/api/approved-reservations/:roomNo', async(req, res) => {
    const { roomNo } = req.params;

    try {
        // Query para sa PostgreSQL
        // Kinukuha lang ang APPROVED at para sa DATE ngayon
        const query = `
            SELECT 
                id, 
                room, 
                subject, 
                professor, 
                section, 
                start_time, 
                end_time, 
                purpose 
            FROM reservations 
            WHERE room = $1 
              AND status = 'APPROVED' 
              AND date = CURRENT_DATE
            ORDER BY start_time ASC
        `;

        const result = await pool.query(query, [roomNo]);

        // Ipadala ang data bilang JSON
        res.json(result.rows);
    } catch (err) {
        console.error("Error fetching approved reservations:", err.message);
        res.status(500).json({ error: "Server Database Error" });
    }
});

/**
 * GET: Real-time Room Status Check
 * The Kiosk asks this: "Is there a class in this room right now?"
 */
app.get('/api/kiosk/check-status/:room_id', async(req, res) => {
    const { room_id } = req.params;
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    // Getting the current Day and Time from the computer clock
    const today = days[new Date().getDay()];
    const now = new Date();
    const currentTime = now.toTimeString().split(' ')[0];

    try {
        // Checking the database if the current time is between the Start and End of a class
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND start_time <= $3 
            AND end_time >= $3
            LIMIT 1`;
        const result = await pool.query(query, [room_id, today, currentTime]);

        // If the database finds a class, tell the Kiosk the room is "Occupied"
        if (result.rows.length > 0) {
            res.json({ occupied: true, data: result.rows[0] });
        } else {
            res.json({ occupied: false });
        }
    } catch (err) {
        console.error("Status Check Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

/**
 * POST: Add Semester Schedule (Admin Entry)
 * This is for the official school schedule. It has a "Traffic Jam" detector.
 */
app.post('/api/fixed-schedules', async(req, res) => {
    const { room, day, course, subject, prof, start, end } = req.body;

    // Check if the Admin forgot to fill in the time or room
    if (!room || !day || !start || !end) {
        return res.status(400).json({
            success: false,
            error: "Incomplete details: Room, Day, Start Time, and End Time are required."
        });
    }

    try {
        // 1. Conflict Validation (The Traffic Jam Detector)
        // This checks if the room is ALREADY booked at the time you are trying to set.
        const checkConflictQuery = `
            SELECT subject, start_time, end_time 
            FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND (start_time < $4 AND end_time > $3)
            LIMIT 1
        `;

        const conflictResult = await pool.query(checkConflictQuery, [room, day, start, end]);

        // If a conflict is found, stop the process and tell the Admin who is using the room
        if (conflictResult.rows.length > 0) {
            const conflict = conflictResult.rows[0];
            const formattedStart = formatAMPM(conflict.start_time);
            const formattedEnd = formatAMPM(conflict.end_time);

            return res.status(409).json({
                success: false,
                error: `Schedule Conflict: Room already booked for "${conflict.subject}" from ${formattedStart} to ${formattedEnd}.`
            });
        }

        // 2. If the room is free, save the new schedule into the database
        const insertQuery = `
            INSERT INTO fixed_schedules (
                room_id, day_of_week, course_section, subject, professor, start_time, end_time
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7) 
            RETURNING *;
        `;

        const result = await pool.query(insertQuery, [room, day, course, subject, prof, start, end]);

        res.status(201).json({
            success: true,
            message: "Schedule successfully recorded.",
            data: result.rows[0]
        });

    } catch (err) {
        console.error("Transaction Error:", err.message);
        res.status(500).json({
            success: false,
            error: "Server error during schedule processing."
        });
    }
});

/**
 * GET: Retrieve All Fixed Schedules
 * This is used for the Admin's view to see the "Master List" 
 * of every class schedule stored in the database.
 */
app.get('/api/fixed-schedules', async(req, res) => {
    try {
        // Asking the database to give us everything, but keep it organized
        // by the Day (Monday, Tuesday...) and the Time.
        const result = await pool.query('SELECT * FROM fixed_schedules ORDER BY day_of_week, start_time');

        // Sending that organized list back to the Admin screen.
        res.json(result.rows);
    } catch (err) {
        // If the database is busy or has an error, tell the user what went wrong.
        res.status(500).json({ error: err.message });
    }
});

/**
 * DELETE: Remove a specific Fixed Schedule
 * Used when the Admin wants to cancel or delete a specific class schedule.
 */
app.delete('/api/fixed-schedules/:id', async(req, res) => {
    // The "id" is the unique number of the specific schedule we want to delete.
    const { id } = req.params;

    try {
        // Telling the database: "Find the schedule with this ID and erase it."
        const result = await pool.query('DELETE FROM fixed_schedules WHERE id = $1', [id]);

        // Checking if we actually deleted something. 
        // If rowCount is 0, it means the ID didn't exist in the cabinet.
        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, error: "Schedule not found." });
        }

        // Success! The schedule is gone.
        res.json({ success: true, message: "Schedule deleted successfully." });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/**
 * GET: Fetch Upcoming Classes for a Specific Room
 * Used by the Kiosk to show students what classes are coming up NEXT today.
 */
app.get('/api/kiosk/upcoming-semester/:room_id', async(req, res) => {
    const { room_id } = req.params;

    // Getting the current Day and Time so the server knows what "Today" is.
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = days[new Date().getDay()];
    const currentTime = new Date().toTimeString().split(' ')[0];

    try {
        // We only want classes that:
        // 1. Are in this specific room.
        // 2. Are happening today.
        // 3. Haven't finished yet (End Time is in the future).
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND end_time > $3
            ORDER BY start_time ASC`;

        const result = await pool.query(query, [room_id, today, currentTime]);

        // Sending the list of upcoming classes back to the Kiosk.
        res.json(result.rows);
    } catch (err) {
        console.error("Fetch Upcoming Error:", err.message);
        res.status(500).json({ error: err.message });
    }
});

/**
 * GET: Retrieve Maintenance Status
 * This is used to see a list of every room that is 
 * currently under repair or "Locked" for maintenance.
 */
app.get('/api/maintenance/status', async(req, res) => {
    try {
        // Asking the database to show us all rooms inside the maintenance table.
        const result = await pool.query('SELECT * FROM room_maintenance');

        // Sending the list of locked rooms back to the dashboard.
        res.json(result.rows);
    } catch (err) {
        // If something goes wrong with the database, send an error message.
        res.status(500).json({ error: err.message });
    }
});

/**
 * POST: Lock a Room for Maintenance
 * Think of this as putting an "Under Repair" sign on a door.
 */
app.post('/api/maintenance/lock', async(req, res) => {
    // The "room_id" is which room to lock, and "reason" is why (like "Broken AC").
    const { room_id, reason } = req.body;

    try {
        /**
         * "ON CONFLICT" Logic: 
         * If the room is NOT in the table yet, it adds it (Locks the room).
         * If the room is ALREADY in the table, it just updates the reason.
         */
        const query = `
            INSERT INTO room_maintenance (room_id, reason) 
            VALUES ($1, $2) 
            ON CONFLICT (room_id) DO UPDATE SET reason = $2
            RETURNING *`;

        const result = await pool.query(query, [room_id, reason]);

        // Sending back a success message so the Admin knows the room is now locked.
        res.json({ success: true, data: result.rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Database error" });
    }
});

/**
 * DELETE: Unlock a Room (Remove Maintenance)
 * Used when the repair is finished and the room is ready for students again.
 */
app.delete('/api/maintenance/unlock/:room_id', async(req, res) => {
    // We get the room number from the URL address.
    const { room_id } = req.params;

    try {
        // Telling the database to remove this room from the maintenance list.
        // Once removed, the room is "Unlocked" and can be used again.
        await pool.query('DELETE FROM room_maintenance WHERE room_id = $1', [room_id]);

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to unlock room" });
    }
});

/**
 * GET: Retrieve All Locked Rooms
 * This is like a security guard checking a clipboard to see 
 * which rooms are closed for repairs right now.
 */
app.get('/api/maintenance/status', async(req, res) => {
    try {
        // We ask the database: "Give me the list of all rooms under maintenance."
        const result = await pool.query('SELECT * FROM room_maintenance');

        // We send that list back so the website can show which rooms are "Locked."
        res.json(result.rows);
    } catch (err) {
        // If the database has a problem, we send an error message back.
        res.status(500).json({ error: err.message });
    }
});

// =====================================================
// 3. SERVER INITIALIZATION
// =====================================================
app.listen(PORT, IP_ADDRESS, () => {
    console.log(`🚀 RAIMIS Server is running on http://${IP_ADDRESS}:${PORT}`);
    console.log(`📡 Local Network Access: Ready`);
});