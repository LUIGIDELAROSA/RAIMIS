/**
 * =====================================================
 * RAIMIS - BACKEND SERVER
 * =====================================================
 */
const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
const PORT = 3000;
const IP_ADDRESS = '0.0.0.0'; // Listening on all interfaces for Raspberry Pi deployment

// =====================================================
// 1. MIDDLEWARE & CONFIGURATION
// =====================================================
app.use(express.json());
app.use(express.static('public'));

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "raimis_db",
    password: "luigi",
    port: 5432
});

pool.connect()
    .then(() => console.log("✅ RAIMIS Database: Connected successfully"))
    .catch(err => console.error("❌ Database Connection Error:", err));

const formatAMPM = (timeStr) => {
    if (!timeStr) return "";
    const [h, m] = timeStr.split(':');
    return new Date(2000, 0, 1, h, m).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
};

// =====================================================
// 2. API ENDPOINTS
// (These are the "Service Windows" of your server)
// =====================================================

function convertTo24Hour(timeStr) {
    if (!timeStr) return null;
    if (!timeStr.includes('AM') && !timeStr.includes('PM')) return timeStr.substring(0, 5) + ":00";
    const [time, modifier] = timeStr.split(' ');
    const [h, m] = time.split(':');
    const adjustedHour = modifier === 'PM' && h !== '12' ? parseInt(h) + 12 : (modifier === 'AM' && h === '12' ? 0 : h);
    return new Date(2000, 0, 1, adjustedHour, m).toLocaleTimeString('en-GB');
}

// =====================================================
// GET ALL RFID USERS WITH COMPLETE MATRIX CONTEXT
// =====================================================
app.get('/api/rfid-users', async(req, res) => {
    try {
        const query = `
            SELECT id, rfid_serial, role, identifier, security_pin, additional_info, cancel_strikes, is_blocked 
            FROM rfid_users 
            ORDER BY id DESC
        `;
        const result = await pool.query(query);

        return res.status(200).json({
            success: true,
            count: result.rows.length,
            data: result.rows
        });
    } catch (err) {
        console.error("Express Gateway Fetch All Error:", err.message);
        return res.status(500).json({
            success: false,
            error: "Internal server error reading user registry entries."
        });
    }
});

// =====================================================
// GET SINGLE RFID USER BY SERIAL IDENTITY Key
// =====================================================
app.get('/api/rfid-users/:serial', async(req, res) => {
    try {
        const { serial } = req.params;

        if (!serial) {
            return res.status(400).json({ success: false, error: "Missing required rfid serial address parameter." });
        }

        const cleanSerial = String(serial).trim();

        // FIX: Idinagdag na si cancel_strikes at is_blocked sa SELECT fields para mabasa ng frontend wrapper guard
        const query = `
            SELECT id, rfid_serial, role, identifier, security_pin, additional_info, cancel_strikes, is_blocked 
            FROM rfid_users 
            WHERE rfid_serial = $1 
            LIMIT 1
        `;
        const result = await pool.query(query, [cleanSerial]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: `No registered account linked to serial tracker key [${cleanSerial}].`
            });
        }

        return res.status(200).json({
            success: true,
            data: result.rows[0]
        });
    } catch (err) {
        console.error(`Express Gateway Fetch Single Error [${req.params.serial}]:`, err.message);
        return res.status(500).json({
            success: false,
            error: "Database abstraction layer runtime interruption."
        });
    }
});

app.get('/api/rfid/scan/:cardId', async(req, res) => {
    try {
        const { cardId } = req.params;

        // FIXED: Ginamit ang tamang column names (identifier at rfid_serial) mula sa database.sql
        const userQuery = `
            SELECT id, identifier, role, rfid_serial, security_pin 
            FROM rfid_users 
            WHERE rfid_serial = $1 LIMIT 1
        `;
        const result = await pool.query(userQuery, [cardId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "RFID Card not registered." });
        }

        // Ibalik ang user data kasama ang PIN sa frontend
        return res.json({ success: true, user: result.rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// REGISTRATION & UPDATE ENDPOINT
app.post('/api/register', async(req, res) => {
    // 1. Isinama natin ang "id" na manggagaling sa frontend form kapag nag-eedit
    let { id, rfid_serial, role, identifier, security_pin, additional_info } = req.body;

    try {
        if (rfid_serial) {
            rfid_serial = String(rfid_serial).trim();
        } else {
            return res.status(400).json({ success: false, error: "RFID Serial is required" });
        }

        const jsonPayload = JSON.stringify(Array.isArray(additional_info) ? additional_info : []);

        let query;
        let values;

        // 2. DITO ANG LOGIC NG FIX:
        // Kung may 'id' na pinasa, nangangahulugan na nag-eedit tayo ng lumang card!
        if (id) {
            query = `
                UPDATE rfid_users 
                SET rfid_serial = $1, role = $2, identifier = $3, security_pin = $4, additional_info = $5
                WHERE id = $6
                RETURNING *`;

            values = [rfid_serial, role, identifier, security_pin, jsonPayload, id];
        }
        // Kung walang 'id', ibig sabihin ay bagong registration (gaya ng dati mong gawa)
        else {
            query = `
                INSERT INTO rfid_users (rfid_serial, role, identifier, security_pin, additional_info)
                VALUES ($1, $2, $3, $4, $5)
                ON CONFLICT (rfid_serial) 
                DO UPDATE SET 
                    role = EXCLUDED.role,
                    identifier = EXCLUDED.identifier,
                    security_pin = EXCLUDED.security_pin,
                    additional_info = EXCLUDED.additional_info
                RETURNING *`;

            values = [rfid_serial, role, identifier, security_pin, jsonPayload];
        }

        const result = await pool.query(query, values);

        res.status(200).json({ success: true, user: result.rows[0] });

    } catch (err) {
        console.error("FULL ERROR:", err);

        // BONUS FIX: Saluhin natin kung pinalitan ang serial number pero may kapareho na palang iba sa database
        if (err.code === '23505') {
            return res.status(400).json({
                success: false,
                error: "The new RFID Serial is already registered to another user!"
            });
        }

        res.status(500).json({
            success: false,
            error: "Database Error",
            detail: err.message
        });
    }
});

/**
 * GET: Retrieve All Fixed Schedules
 * This is used for the Admin's view to see the "Master List" 
 * of every class schedule stored in the database.
 */
app.get('/api/fixed-schedules', async(req, res) => {
    try {
        // Asking the database to give us everything, but keep it organized
        // by the Day (Monday, Tuesday...) and the Time.
        const result = await pool.query('SELECT * FROM fixed_schedules ORDER BY day_of_week, start_time');

        // Sending that organized list back to the Admin screen.
        res.json(result.rows);
    } catch (err) {
        // If the database is busy or has an error, tell the user what went wrong.
        res.status(500).json({ error: err.message });
    }
});

/**
 * POST: Add Semester Schedule (Admin Entry)
 * This is for the official school schedule. It has a "Traffic Jam" detector.
 */
app.post('/api/fixed-schedules', async(req, res) => {
    const { room, day, course, subject, prof, start, end } = req.body;

    // Check if the Admin forgot to fill in the time or room
    if (!room || !day || !start || !end) {
        return res.status(400).json({
            success: false,
            error: "Incomplete details: Room, Day, Start Time, and End Time are required."
        });
    }

    try {
        // 1. Conflict Validation (The Traffic Jam Detector)
        // This checks if the room is ALREADY booked at the time you are trying to set.
        const checkConflictQuery = `
            SELECT subject, start_time, end_time 
            FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND (start_time < $4 AND end_time > $3)
            LIMIT 1
        `;

        const conflictResult = await pool.query(checkConflictQuery, [room, day, start, end]);

        // If a conflict is found, stop the process and tell the Admin who is using the room
        if (conflictResult.rows.length > 0) {
            const conflict = conflictResult.rows[0];
            const formattedStart = formatAMPM(conflict.start_time);
            const formattedEnd = formatAMPM(conflict.end_time);

            return res.status(409).json({
                success: false,
                error: `Schedule Conflict: Room already booked for "${conflict.subject}" from ${formattedStart} to ${formattedEnd}.`
            });
        }

        // 2. If the room is free, save the new schedule into the database
        const insertQuery = `
            INSERT INTO fixed_schedules (
                room_id, day_of_week, course_section, subject, professor, start_time, end_time
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7) 
            RETURNING *;
        `;

        const result = await pool.query(insertQuery, [room, day, course, subject, prof, start, end]);

        res.status(201).json({
            success: true,
            message: "Schedule successfully recorded.",
            data: result.rows[0]
        });

    } catch (err) {
        console.error("Transaction Error:", err.message);
        res.status(500).json({
            success: false,
            error: "Server error during schedule processing."
        });
    }
});

// Route para i-toggle ang cancel status ng schedule
app.patch('/api/schedule/toggle-cancel/:id', async(req, res) => {
    const { id } = req.params;
    const { is_cancelled } = req.body; // Ito yung pinasa natin sa JSON.stringify

    try {
        // I-update ang database base sa ID
        // Gamit ang pool.query (PostgreSQL example)
        const result = await pool.query(
            "UPDATE fixed_schedules SET is_cancelled = $1 WHERE id = $2 RETURNING *", [is_cancelled, id]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ error: "Schedule not found" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (err) {
        console.error("Database Error:", err);
        res.status(500).json({ error: "Server error during update" });
    }
});

/**
 * DELETE: Remove a specific Fixed Schedule
 * Used when the Admin wants to cancel or delete a specific class schedule.
 */
app.delete('/api/fixed-schedules/:id', async(req, res) => {
    // The "id" is the unique number of the specific schedule we want to delete.
    const { id } = req.params;

    try {
        // Telling the database: "Find the schedule with this ID and erase it."
        const result = await pool.query('DELETE FROM fixed_schedules WHERE id = $1', [id]);

        // Checking if we actually deleted something. 
        // If rowCount is 0, it means the ID didn't exist in the cabinet.
        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, error: "Schedule not found." });
        }

        // Success! The schedule is gone.
        res.json({ success: true, message: "Schedule deleted successfully." });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


app.get('/api/pending-reservations', async(req, res) => {
    try {
        // Siguraduhin na ang 'status' column ay PENDING (all caps dapat kung yun ang nasa code)
        const result = await pool.query("SELECT * FROM reservations WHERE status = 'PENDING' ORDER BY id DESC");
        res.json(result.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

app.get('/api/reservations/history', async(req, res) => {
    try {
        const query = `
            SELECT * FROM reservations 
            WHERE status = 'APPROVED' 
            ORDER BY date DESC, start_time DESC
        `;
        const result = await pool.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error("History Fetch Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.get('/api/approved-reservations/:roomNo', async(req, res) => {
    const { roomNo } = req.params;
    let targetDate = req.query.date;

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const todayStr = `${year}-${month}-${day}`; // Format: YYYY-MM-DD

    if (!targetDate || targetDate === 'today') {
        targetDate = todayStr;
    }

    const currentTime = now.toTimeString().split(' ')[0];

    try {
        let query;
        let values;

        if (targetDate === todayStr) {
            query = `
                SELECT id, room, subject, professor, section, start_time, end_time, purpose 
                FROM reservations 
                WHERE room = $1 
                  AND status = 'APPROVED' 
                  AND date = $2
                  AND end_time > $3  -- Gumagana lang ang time checking kung araw ngayon
                ORDER BY start_time ASC
            `;
            values = [roomNo, targetDate, currentTime];
        } else {
            query = `
                SELECT id, room, subject, professor, section, start_time, end_time, purpose 
                FROM reservations 
                WHERE room = $1 
                  AND status = 'APPROVED' 
                  AND date = $2 -- Ipakita lahat ng schedule para sa araw na ito nang walang time limit
                ORDER BY start_time ASC
            `;
            values = [roomNo, targetDate];
        }

        const result = await pool.query(query, values);
        res.json(result.rows);
    } catch (err) {
        console.error("Error fetching approved reservations:", err.message);
        res.status(500).json({ error: "Server Database Error" });
    }
});

app.post('/api/reservations', async(req, res) => {
    try {
        const { room, rfid_tag, section, date, start_time, end_time, purpose, subject, professor } = req.body;

        // Siguraduhing malinis ang time strings bago i-verify o i-save
        const formattedStart = convertTo24Hour(start_time);
        const formattedEnd = convertTo24Hour(end_time);

        if (formattedStart >= formattedEnd) {
            return res.status(400).json({
                success: false,
                message: "Logical Error: Start time cannot be later than or equal to End time."
            });
        }

        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const dayOfWeek = days[new Date(date).getDay()];

        // Conflict check Engine (APPROVED requests & Fixed Schedules)
        const conflictQuery = `
            SELECT id FROM reservations 
            WHERE room = $1 AND date = $2 AND status = 'APPROVED'
            AND (start_time < $4 AND end_time > $3)
            UNION
            SELECT id FROM fixed_schedules
            WHERE room_id = $1 AND day_of_week = $5 AND is_cancelled = false
            AND (start_time < $4 AND end_time > $3)
        `;

        const conflictCheck = await pool.query(conflictQuery, [room, date, formattedStart, formattedEnd, dayOfWeek]);

        if (conflictCheck.rows.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Double Booking Error: The requested time slot is already occupied by an approved schedule or a fixed class."
            });
        }

        const query = `
            INSERT INTO reservations (room, rfid_tag, section, date, start_time, end_time, purpose, subject, professor, status) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'PENDING') 
            RETURNING *
        `;

        const values = [
            room,
            rfid_tag || null,
            section,
            date,
            formattedStart,
            formattedEnd,
            purpose,
            subject,
            professor
        ];

        const result = await pool.query(query, values);

        return res.status(201).json({
            success: true,
            message: "Reservation successfully sent for approval.",
            data: result.rows[0]
        });

    } catch (err) {
        console.error("Database Insert Error:", err.message);
        return res.status(500).json({
            success: false,
            error: "Internal Database Error: " + err.message
        });
    }
});

app.post('/api/reservations/claim/:id', async (req, res) => {
    const { id } = req.params;
    try {
        
        const checkQuery = "SELECT print_count FROM reservations WHERE id = $1";
        const checkResult = await pool.query(checkQuery, [id]);

        if (checkResult.rows.length === 0) {
            return res.status(404).json({ success: false, error: "Reservation record not found." });
        }

        const currentCount = checkResult.rows[0].print_count || 0;

        if (currentCount >= 3) {
            return res.status(400).json({ 
                success: false, 
                error: "Access Denied: Isang schedule owner ay pinapayagan lamang mag-print ng resibo hanggang tatlong (3) beses." 
            });
        }

        const updateQuery = `
            UPDATE reservations 
            SET print_count = print_count + 1 
            WHERE id = $1 
            RETURNING *
        `;
        const result = await pool.query(updateQuery, [id]);
        
        return res.json({
            success: true,
            message: "Database record updated successfully.",
            reservationData: result.rows[0] // Ibalik ang data para sa thermal printer layout mamaya
        });

    } catch (err) {
        return res.status(500).json({ success: false, error: "Database internal operational error." });
    }
});

app.get('/api/reservations/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query(
            'SELECT * FROM reservations WHERE id = $1', [id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: "Reservation not found." });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/reservations/:id/status', async(req, res) => {
    const { id } = req.params;
    const { status } = req.body; // 'APPROVED' or 'REJECTED'

    try {
        if (status === 'REJECTED') {
            await pool.query("UPDATE reservations SET status = $1 WHERE id = $2", [status, id]);
            return res.json({ success: true, message: "Reservation rejected successfully." });
        }

        const currentReqRes = await pool.query("SELECT * FROM reservations WHERE id = $1", [id]);
        const currentReq = currentReqRes.rows[0];

        if (!currentReq) {
            return res.status(404).json({ error: "Reservation not found." });
        }

        const conflictQuery = `
            SELECT id FROM reservations 
            WHERE room = $1 
              AND date = $2 
              AND status = 'APPROVED'
              AND (start_time < $3 AND end_time > $4)`;

        const conflicts = await pool.query(conflictQuery, [
            currentReq.room,
            currentReq.date,
            currentReq.end_time,
            currentReq.start_time
        ]);

        if (conflicts.rows.length > 0) {
            return res.status(409).json({
                success: false,
                error: "Schedule Conflict",
                message: "May nauna nang na-approve na reservation sa slot na ito."
            });
        }

        await pool.query('BEGIN');

        await pool.query("UPDATE reservations SET status = 'APPROVED' WHERE id = $1", [id]);

        const autoRejectQuery = `
            UPDATE reservations 
            SET status = 'REJECTED' 
            WHERE id != $1 
              AND room = $2 
              AND date = $3 
              AND status = 'PENDING'
              AND (start_time < $4 AND end_time > $5)
        `;
        await pool.query(autoRejectQuery, [
            id,
            currentReq.room,
            currentReq.date,
            currentReq.end_time,
            currentReq.start_time
        ]);

        await pool.query('COMMIT');

        res.json({
            success: true,
            message: "Reservation approved! Other conflicting pending requests were automatically rejected."
        });

    } catch (err) {
        await pool.query('ROLLBACK'); // Bawiin ang changes kung may error
        console.error(err.message);
        res.status(500).json({ error: "Database error during status update." });
    }
});

//*Cancellation Logic
app.post('/api/reservations/cancel', async (req, res) => {
    const { reservation_id, rfid_tag } = req.body; // rfid_tag ang galing sa frontend request niyo

    if (!reservation_id || !rfid_tag) {
        return res.status(400).json({ success: false, message: "Missing reservation ID or RFID tag." });
    }

    // Siguraduhing tama ang variable name ng database connection niyo (db o pool)
    const dbClient = typeof db !== 'undefined' ? db : pool; 

    try {
        await dbClient.query('BEGIN');

        // 1. TUGMA SA DB: 'rfid_users' ang table, 'rfid_serial' ang column name
        const userCheck = await dbClient.query(
            'SELECT is_blocked, cancel_strikes FROM rfid_users WHERE TRIM(rfid_serial) = $1', 
            [rfid_tag.trim()]
        );
        
        if (userCheck.rows.length === 0) {
            await dbClient.query('ROLLBACK');
            return res.status(404).json({ success: false, message: "RFID serial not registered in the system." });
        }

        // 2. I-update ang status ng reservation papuntang CANCELLED
        await dbClient.query('UPDATE reservations SET status = \'CANCELLED\' WHERE id = $1', [reservation_id]);

        // 3. TUGMA SA DB: I-update ang cancel_strikes sa rfid_users table
        const userUpdate = await dbClient.query(
            `UPDATE rfid_users 
             SET cancel_strikes = cancel_strikes + 1 
             WHERE TRIM(rfid_serial) = $1 
             RETURNING cancel_strikes`, 
            [rfid_tag.trim()]
        );

        const currentStrikes = userUpdate.rows[0].cancel_strikes;
        let message = `Reservation cancelled successfully. You have ${3 - currentStrikes} strikes left.`;
        
        // 4. Kung umabot na sa 3 strikes, i-block na (magiging 't' o true sa database)
        if (currentStrikes >= 3) {
            await dbClient.query('UPDATE rfid_users SET is_blocked = true WHERE TRIM(rfid_serial) = $1', [rfid_tag.trim()]);
            message = "Reservation cancelled. Your RFID has been BLOCKED due to 3 cancellation strikes.";
        }

        await dbClient.query('COMMIT');
        return res.json({ success: true, message });

    } catch (err) {
        try { await dbClient.query('ROLLBACK'); } catch(e) {}
        console.error("CRITICAL BACKEND ERROR:", err);
        return res.status(500).json({ success: false, message: "Internal Server Error: " + err.message });
    }
});

// Endpoint para sa pag-unblock ng RFID card (Admin Privileges)
app.post('/api/admin/reset-strikes', async (req, res) => {
    // Kinukuha ang rfid_tag/rfid_serial na ipinadala mula sa frontend body
    const { rfid_tag } = req.body; 

    // Guard Clause: Siguraduhing may ipinasang serial bago mag-query sa DB
    if (!rfid_tag) {
        return res.status(400).json({ 
            success: false, 
            message: "Missing RFID serial address parameter." 
        });
    }

    try {
        // TUGMA SA DB: 'rfid_users' ang table at 'rfid_serial' ang column name
        // Nilalagyan din natin ng TRIM para siguradong walang hidden spaces ang RFID string
        const query = `
            UPDATE rfid_users 
            SET cancel_strikes = 0, 
                is_blocked = false 
            WHERE TRIM(rfid_serial) = $1
            RETURNING identifier;
        `;
        
        const result = await pool.query(query, [rfid_tag.trim()]);

        // Kung walang nahanap na record sa database na may ganoong serial
        if (result.rows.length === 0) {
            return res.status(404).json({ 
                success: false, 
                message: "RFID serial not found in the records." 
            });
        }

        const userName = result.rows[0].identifier;

        // Magpasa ng tagumpay na response pabalik sa frontend admin panel
        return res.status(200).json({ 
            success: true, 
            message: `Account privileges for ${userName} have been successfully restored. Strikes reset to 0.` 
        });

    } catch (err) {
        console.error("CRITICAL ADMIN UNBLOCK ERROR:", err.message);
        return res.status(500).json({ 
            success: false, 
            message: "Database runtime interruption during account reset." 
        });
    }
});

/**GET: Real-time Room Status Check*/
app.get('/api/kiosk/check-status/:room_id', async(req, res) => {
    const { room_id } = req.params;
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const today = days[new Date().getDay()];
    const now = new Date();
    const currentTime = now.toTimeString().split(' ')[0];

    try {
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND start_time <= $3 
            AND end_time >= $3
            LIMIT 1`;
        const result = await pool.query(query, [room_id, today, currentTime]);

        if (result.rows.length > 0) {
            res.json({ occupied: true, data: result.rows[0] });
        } else {
            res.json({ occupied: false });
        }
    } catch (err) {
        console.error("Status Check Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

/**
 * GET: Fetch Upcoming Classes for a Specific Room
 * Used by the Kiosk to show students what classes are coming up NEXT today.
 */
app.get('/api/kiosk/upcoming-semester/:room_id', async(req, res) => {
    const { room_id } = req.params;
    const { day } = req.query; // Kunin ang araw mula sa dropdown

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    let targetDay = day;
    let timeFilter = '00:00:00'; // Default: Ipakita LAHAT ng klase sa araw na iyon

    // Kung "today" ang pinili, i-filter base sa kasalukuyang oras at araw
    if (!day || day === 'today') {
        targetDay = days[new Date().getDay()];
        timeFilter = new Date().toTimeString().split(' ')[0];
    }

    try {
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND end_time > $3
            ORDER BY start_time ASC`;

        const result = await pool.query(query, [room_id, targetDay, timeFilter]);
        res.json(result.rows);
    } catch (err) {
        console.error("Fetch Upcoming Error:", err.message);
        res.status(500).json({ error: err.message });
    }
});

/**
 * GET: Retrieve Maintenance Status
 * This is used to see a list of every room that is 
 * currently under repair or "Locked" for maintenance.
 */
app.get('/api/maintenance/status', async(req, res) => {
    try {
        // Asking the database to show us all rooms inside the maintenance table.
        const result = await pool.query('SELECT * FROM room_maintenance');

        // Sending the list of locked rooms back to the dashboard.
        res.json(result.rows);
    } catch (err) {
        // If something goes wrong with the database, send an error message.
        res.status(500).json({ error: err.message });
    }
});

/**
 * POST: Lock a Room for Maintenance
 * Think of this as putting an "Under Repair" sign on a door.
 */
app.post('/api/maintenance/lock', async(req, res) => {
    // The "room_id" is which room to lock, and "reason" is why (like "Broken AC").
    const { room_id, reason } = req.body;

    try {
        /**
         * "ON CONFLICT" Logic: 
         * If the room is NOT in the table yet, it adds it (Locks the room).
         * If the room is ALREADY in the table, it just updates the reason.
         */
        const query = `
            INSERT INTO room_maintenance (room_id, reason) 
            VALUES ($1, $2) 
            ON CONFLICT (room_id) DO UPDATE SET reason = $2
            RETURNING *`;

        const result = await pool.query(query, [room_id, reason]);

        // Sending back a success message so the Admin knows the room is now locked.
        res.json({ success: true, data: result.rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Database error" });
    }
});

/**
 * DELETE: Unlock a Room (Remove Maintenance)
 * Used when the repair is finished and the room is ready for students again.
 */
app.delete('/api/maintenance/unlock/:room_id', async(req, res) => {
    // We get the room number from the URL address.
    const { room_id } = req.params;

    try {
        // Telling the database to remove this room from the maintenance list.
        // Once removed, the room is "Unlocked" and can be used again.
        await pool.query('DELETE FROM room_maintenance WHERE room_id = $1', [room_id]);

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to unlock room" });
    }
});

/**GET: Analytics Statistics*/
app.get('/api/analytics/stats', async(req, res) => {
    try {
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const today = new Date();
        const todayStr = days[today.getDay()];
        const todayDate = today.toISOString().split('T')[0];

        // 1. Today's Total Usage (Fixed + Approved) - Exclude Sunday
        let todayCount = 0;
        if (todayStr !== 'Sunday') {
            const todayCountQuery = `
                SELECT 
                    (SELECT COUNT(*) FROM fixed_schedules WHERE day_of_week = $1 AND is_cancelled = false) +
                    (SELECT COUNT(*) FROM reservations WHERE date = $2 AND status = 'APPROVED') as total
            `;
            const todayCountRes = await pool.query(todayCountQuery, [todayStr, todayDate]);
            todayCount = parseInt(todayCountRes.rows[0].total);
        }

        // 2. Room Demand & Top Room - Exclude Sundays
        const roomDemandQuery = `
            SELECT room, COUNT(*) as usage_count FROM (
                SELECT room_id as room FROM fixed_schedules WHERE is_cancelled = false AND day_of_week != 'Sunday'
                UNION ALL
                SELECT room FROM reservations WHERE status = 'APPROVED' AND EXTRACT(DOW FROM date) != 0
            ) combined
            GROUP BY room
            ORDER BY usage_count DESC
        `;
        const roomDemandRes = await pool.query(roomDemandQuery);
        const roomStats = roomDemandRes.rows;
        const topRoom = roomStats[0] || { room: '---', usage_count: 0 };

        // 3. Peak Hour (Counting all hours of occupancy) - Exclude Sundays
        const peakHourQuery = `
            SELECT hour, COUNT(*) as count FROM (
                SELECT generate_series(EXTRACT(HOUR FROM start_time)::int, EXTRACT(HOUR FROM (end_time - interval '1 minute'))::int) as hour 
                FROM fixed_schedules 
                WHERE is_cancelled = false AND day_of_week != 'Sunday'
                UNION ALL
                SELECT generate_series(EXTRACT(HOUR FROM start_time)::int, EXTRACT(HOUR FROM (end_time - interval '1 minute'))::int) as hour 
                FROM reservations 
                WHERE status = 'APPROVED' AND EXTRACT(DOW FROM date) != 0
            ) combined
            GROUP BY hour
            ORDER BY count DESC
            LIMIT 1
        `;
        const peakHourRes = await pool.query(peakHourQuery);
        let peakHour = "---";
        if (peakHourRes.rows.length > 0) {
            const hour = parseInt(peakHourRes.rows[0].hour);
            const nextHour = hour + 1;
            
            const formatHour = (h) => {
                const ampm = h >= 12 ? 'PM' : 'AM';
                const displayH = h % 12 || 12;
                return `${displayH} ${ampm}`;
            };
            
            peakHour = `${formatHour(hour)} - ${formatHour(nextHour)}`;
        }

        // 4. 7-Day Trend (Excluding Sundays)
        const trend = [];
        let i = 0;
        let daysCounted = 0;
        while (daysCounted < 7) {
            const d = new Date();
            d.setDate(d.getDate() - i);
            const dayName = days[d.getDay()];

            if (dayName !== 'Sunday') {
                const dateStr = d.toISOString().split('T')[0];
                const countQuery = `
                    SELECT 
                        (SELECT COUNT(*) FROM fixed_schedules WHERE day_of_week = $1 AND is_cancelled = false) +
                        (SELECT COUNT(*) FROM reservations WHERE date = $2 AND status = 'APPROVED') as total
                `;
                const countRes = await pool.query(countQuery, [dayName, dateStr]);
                trend.push({
                    day: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
                    count: parseInt(countRes.rows[0].total)
                });
                daysCounted++;
            }
            i++;
            if (i > 14) break; // Safety to avoid infinite loop
        }
        trend.reverse(); // Oldest to newest

        res.json({
            todayCount,
            topRoom,
            peakHour,
            roomStats,
            trend
        });
    } catch (err) {
        console.error("Analytics Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});
// =====================================================
// 3. SERVER INITIALIZATION
// =====================================================
app.listen(PORT, IP_ADDRESS, () => {
    console.log(`🚀 RAIMIS Server is running on http://${IP_ADDRESS}:${PORT}`);
    console.log(`📡 Local Network Access: Ready`);
});