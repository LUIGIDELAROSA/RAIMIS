/**
 * =====================================================
 * RAIMIS - KIOSK JAVASCRIPT
 * This script runs the Kiosk display. Its job is to 
 * show the rooms on the screen and update their status 
 * (Available or Occupied) every few seconds.
 * =====================================================
 */
// A simple list (Dictionary) of how many students can fit in each room.
const roomCapacities = {
    "101": 45, "102": 40, "103": 35, "106": 35, "107": 35,
    "202": 40, "203": 40, "205": 30, "207": 30, "208": 45, "209": 45, "210": 45, "212": 45, "213": 45,
    "301": 50, "302": 50, "303": 45, "304": 45, "305": 40, "307": 40, "308": 40, "309": 40, "310": 40,
    "401": 35, "402": 35, "403": 40, "404": 40, "405": 50, "406": 40
};

// Organizing the rooms by which Floor they are on.
const rooms = {
    "1st": ["101", "102", "103", "106", "107"],
    "2nd": ["202", "203", "205", "207", "208", "209", "210", "212", "213"],
    "3rd": ["301", "302", "303", "304", "305", "307", "308", "309", "310"],
    "4th": ["401", "402", "403", "404", "405", "406"]
};

let isApprovalModalOpen = false;
let waitingListTimer = null;
let selectedRoomForReserve = "";
let isModalOpen = false;

document.addEventListener('DOMContentLoaded', () => {
    const openApprovalBtn = document.getElementById('openApprovalBtn');
    if (openApprovalBtn) {
        openApprovalBtn.onclick = openApprovalModal;
    }
});

async function openApprovalModal() {
    const modal = document.getElementById("approvalModal");
    if (modal) {
        modal.style.display = "flex";
        isApprovalModalOpen = true;
        loadWaitingList();
        waitingListTimer = setInterval(loadWaitingList, 5000);
    }
}

function closeApprovalModal() {
    const modal = document.getElementById("approvalModal");
    if (modal) {
        modal.style.display = "none";
        isApprovalModalOpen = false;
        clearInterval(waitingListTimer);
    }
}

async function loadWaitingList() {
    const tableBody = document.getElementById("approvalTableBody");
    if (!tableBody) return;

    try {
        const [pendingRes, historyRes] = await Promise.all([
            fetch('/api/pending-reservations'),
            fetch('/api/reservations/history')
        ]);
        const pending = await pendingRes.json();
        const history = await historyRes.json();

        let combined = [
            ...pending.map(item => ({ ...item, status: 'PENDING' })),
            ...history.map(item => ({ ...item, status: 'APPROVED' }))
        ];

        const now = new Date();
        const todayStr = now.toLocaleDateString('en-CA'); // Format: YYYY-MM-DD
        
        const currentHours = String(now.getHours()).padStart(2, '0');
        const currentMinutes = String(now.getMinutes()).padStart(2, '0');
        const currentTimeStr = `${currentHours}:${currentMinutes}`;

        combined = combined.filter(item => {
            // KUNG ANG STATUS AY CANCELLED, ITAPON AGAD (Mawawala sa table)
            if (item.status === 'CANCELLED') {
                return false;
            }

            if (!item.date) return false;

            const resDateStr = new Date(item.date).toLocaleDateString('en-CA');

            // Tanggalin ang mga lumang petsa (mula sa lumang code mo)
            if (resDateStr < todayStr) {
                return false;
            }

            // Tanggalin ang mga tapos na ang oras ngayon (mula sa lumang code mo)
            if (resDateStr === todayStr) {
                const endTime = item.end_time || "00:00";
                if (currentTimeStr >= endTime) {
                    return false;
                }
            }
            return true;
        });

        combined.sort((a, b) => b.id - a.id);

        if (combined.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="8" class="empty-table-msg">No active requests found for today.</td></tr>`;
            return;
        }

        tableBody.innerHTML = combined.map(item => {
            const isApproved = item.status === 'APPROVED';
            const currentPrintCount = parseInt(item.print_count) || 0;
            const maxPrints = 2;
            const printsLeft = maxPrints - currentPrintCount;

            const roomDisplay = 'Room ' + item.room;
            const formattedDate = item.date ? new Date(item.date).toLocaleDateString('en-CA') : 'N/A';
            
            let statusColor = '#f59e0b'; // Pending
            if (isApproved) statusColor = '#10b981'; // Approved

            const cancelBtnHTML = `
                <button onclick="initiateCancel(${item.id}, '${item.rfid_tag ? item.rfid_tag.trim() : ''}')" 
                        style="background: rgba(239, 68, 68, 0.2); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.4); padding: 8px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 11px; transition: 0.2s;">
                    Cancel
                </button>
            `;

            return `
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <td style="padding: 12px; font-weight: bold; color: #ffffff;">${roomDisplay}</td>
                    <td style="padding: 12px; color: #cbd5e1;">${item.subject || 'N/A'}</td>
                    <td style="padding: 12px; color: #cbd5e1;">${item.professor || 'N/A'}</td>
                    <td style="padding: 12px; color: #cbd5e1;">${item.section || 'N/A'}</td>
                    <td style="padding: 12px;">
                        <b style="color: #ffffff;">${formattedDate}</b><br>
                        <span style="color: #94a3b8; font-size: 11px;">
                            ${formatTo12Hour(item.start_time)} - ${formatTo12Hour(item.end_time)}
                        </span>
                    </td>
                    <td style="padding: 12px; color: #94a3b8;">${item.purpose || 'CLASS'}</td>
                    
                    <td style="padding: 12px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span style="background: ${statusColor}20; color: ${statusColor}; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase;">
                                ${item.status}
                            </span>
                            ${cancelBtnHTML}
                        </div>
                    </td>
                    
                    <td style="padding: 12px; text-align: center;">
                        ${isApproved ? (
                            printsLeft > 0 ? `
                                <button class="view-receipt-btn" 
                                        onclick="claimReceipt(${item.id}, '${item.rfid_tag ? item.rfid_tag.trim() : ''}')"
                                        style="background: #1e3a8a; color: white; border: none; padding: 8px 14px; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 12px; width: 100%;">
                                    Claim Receipt (${printsLeft}/${maxPrints})
                                </button>
                            ` : `
                                <span style="color: #ef4444; font-size: 12px; font-weight: bold; background: rgba(239,68,68,0.1); padding: 10px 12px; border-radius: 6px; border: 1px solid rgba(239,68,68,0.2); display: block;">
                                    Limit Reached (2/2)
                                </span>
                            `
                        ) : `
                            <div style="color: #64748b; font-size: 11px;">
                                <span>Waiting Approval</span>
                            </div>
                        `}
                    </td>
                </tr>
            `;
        }).join('');

    } catch (err) {
        console.error("Load waiting list error:", err);
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" class="empty-table-msg" style="color: #f43f5e !important;">
                    Failed to fetch reservation logs. Server might be down.
                </td>
            </tr>`; }}

async function initiateCancel(reservationId, ownerRfid) {
    // 1. Ilabas ang prompt para mag-scan
    const { value: scannedRfid } = await Swal.fire({
        title: 'Cancel Reservation',
        text: 'Please tap the exact RFID card used for this booking to confirm cancellation.',
        input: 'text',
        inputAttributes: {
            autocapitalize: 'off',
            autocomplete: 'off'
        },
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'Verify & Cancel',
        customClass: {
            // Pwede mong itago ang input box sa CSS kung gusto mo na parang magic ang pag-scan
            input: 'rfid-hidden-input' 
        }
    });

    if (!scannedRfid) return; // Kung pinindot ang 'Cancel' o walang nilagay

    // 2. I-check kung match ang ini-scan na RFID sa nag-book
    if (scannedRfid.trim() !== ownerRfid.trim()) {
        return Swal.fire({
            icon: 'error',
            title: 'RFID Mismatch',
            text: 'Cancellation denied. The scanned RFID does not match the owner of this reservation.'
        });
    }

    // 3. Ipadala sa Express Backend
    try {
        Swal.showLoading();
        
        const response = await fetch(`/api/reservations/cancel`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                reservation_id: reservationId, 
                rfid_tag: scannedRfid.trim() 
            })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            Swal.fire({
                icon: 'success',
                title: 'Reservation Cancelled',
                text: result.message // Halimbawa: "Cancelled. You have 2 strikes left."
            });
            loadWaitingList(); // I-refresh ang table
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Cancellation Failed',
                text: result.message || 'Error processing request.'
            });
        }
    } catch (err) {
        console.error("Cancel connection error:", err);
        Swal.fire({ icon: 'error', title: 'Server Error', text: 'Cannot connect to database.' });
    }
}            

async function claimReceipt(reservationId, expectedRfid) {
    if (!expectedRfid || expectedRfid.trim() === "") {
        Swal.fire({
            icon: 'warning',
            title: 'Missing Security Tag',
            text: 'This reservation does not have an assigned RFID owner tag in the database.',
            confirmButtonColor: '#f59e0b'
        });
        return;
    }

    Swal.fire({
        title: 'Scan RFID to Claim',
        html: `
            <p>Please tap your authorized RFID card now.</p>
            <input type="password" id="kiosk-rfid-input" class="swal2-input" placeholder="Waiting for card scan..." autofocus style="text-align: center;">
        `,
        showCancelButton: true,
        confirmButtonText: 'Verify',
        allowOutsideClick: false,
        didOpen: () => {
            const rfidInput = document.getElementById('kiosk-rfid-input');
            if (rfidInput) {
                rfidInput.focus();
                
                rfidInput.addEventListener('keydown', async (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        const scannedRfid = rfidInput.value.replace(/[^a-zA-Z0-9]/g, "").trim();
                        const cleanExpectedRfid = expectedRfid.replace(/[^a-zA-Z0-9]/g, "").trim();
                        
                        console.log("=== HARDWARE SCAN DETECTED ===");
                        console.log("Input Value:", scannedRfid);
                        console.log("Expected Value:", cleanExpectedRfid);

                        if (scannedRfid === cleanExpectedRfid) {
                            Swal.close();
                            await processReceiptClaim(reservationId);
                        } else {
                            rfidInput.value = "";
                            Swal.showValidationMessage(`Mismatch Card!`);
                        }
                    }
                });
            }
        }
    });
}

async function processReceiptClaim(reservationId) {
    Swal.fire({
        title: 'Processing...',
        text: 'Updating print counts safely in database...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });

    try {
        const response = await fetch(`/api/reservations/claim/${reservationId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const result = await response.json();

        if (response.ok && result.success) {
            Swal.close();

            await Swal.fire({
                icon: 'success',
                title: 'Access Granted!',
                text: 'Print count incremented successfully in database.',
                timer: 1500,
                showConfirmButton: false
            });

            if (typeof loadWaitingList === 'function') {
                await loadWaitingList();
            }

            if (result.reservationData) {
                printThermalReceipt(result.reservationData);
            }

        } else {
            throw new Error(result.error || "Failed to update logs on database engine.");
        }
    } catch (error) {
        console.error("Fetch Exception Captured:", error);
        Swal.fire({
            icon: 'error',
            title: 'System Rejection',
            text: error.message || 'Error occurred during cross-network negotiation.',
            confirmButtonColor: '#ef4444'
        });
    }
}

function printThermalReceipt(data) {
    const iframeId = 'raimis-printer-iframe';
    let oldIframe = document.getElementById(iframeId);
    if (oldIframe) { oldIframe.remove(); }

    const iframe = document.createElement('iframe');
    iframe.id = iframeId;
    
    iframe.style.position = 'fixed';
    iframe.style.bottom = '0';
    iframe.style.right = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';
    
    document.body.appendChild(iframe);

    const roomNo = data.room || 'N/A';
    const sectionName = data.section || 'N/A'; 
    const resDate = data.date ? new Date(data.date).toLocaleDateString('en-CA') : 'N/A';
    const startTime = data.start_time || 'N/A';
    const endTime = data.end_time || 'N/A';
    const purposeText = data.purpose || 'CLASS';
    const professorName = data.professor || 'N/A';
    const subjectName = data.subject || 'N/A';

    const doc = iframe.contentWindow.document;

    const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>RAIMIS Receipt</title>
            <style>
                @page { margin: 0; }
                body { 
                    font-family: 'Courier New', Courier, monospace; 
                    width: 54mm; /* Sakto sa 58mm paper standard matapos ang margins */
                    padding: 8px; 
                    margin: 0; 
                    font-size: 11px; 
                    color: #000000;
                    line-height: 1.3;
                }
                .text-center { text-align: center; }
                
                .header-title { font-size: 13px; font-weight: bold; margin: -20px; text-transform: uppercase; }
                .header-subtitle { font-size: 9px; margin: 0px 0 5px 0;margin-top: -5px font-weight: bold; }
                
                .line { border-top: 1px dashed #000000; margin: 6px 0; }
                .double-line { border-top: 3px double #000000; margin: 6px 0; }
                
                .ticket-title { 
                font-size: 12px; 
                font-weight: 
                bold; margin: 5px 0; 
                letter-spacing: 1px; 
                }
                
                table { 
                width: 100%; 
                border-collapse: collapse; 
                margin: 6px 0; 
                }

                td { 
                padding: 2px 0; 
                vertical-align: top; 
                }

                .label { font-weight: bold; 
                width: 40%; 
                text-transform: uppercase; 
                }

                .value { width: 60%; 
                word-break: 
                break-word;  
                font-weight: bold;
                }
                
                .footer-text { 
                font-size: 9px; 
                margin-top: 4px; 
                }

                .text-center{
                font-weight: bold;
                }

                
            </style>
        </head>
        <body>
            <div class="text-center">
                <div class="header-title" padding><h1>RAIMIS</h1></div>
                <div class="header-subtitle"> <b>PUPBC CITE CAMPUS</b></div>
                <div class="ticket-title">ROOM RESERVATION SLIP</div>
            </div>
            
            <div class="double-line"></div>
            
            <table>
                <tr><td class="label">ROOM:</td><td class="value" style="font-weight: bold; font-size: 12px;">${'ROOM ' + roomNo}</td></tr>
                <tr><td class="label">SUBJECT:</td><td class="value">${subjectName}</td></tr>
                <tr><td class="label">PROF:</td><td class="value">${professorName}</td></tr>
                <tr><td class="label">SECTION:</td><td class="value">${sectionName}</td></tr>
                <div class="line"></div>
                <tr><td class="label">DATE:</td><td class="value" style="font-weight: bold;">${resDate}</td></tr>
                <tr><td class="label">TIME:</td><td class="value">${formatTo12Hour(startTime)} - ${formatTo12Hour(endTime)}</td></tr>
                <tr><td class="label">PURPOSE:</td><td class="value">${purposeText.toUpperCase()}</td></tr>
            </table>
            
            <div class="line"></div>
            
            <div class="text-center">
                <div class="line"></div>
                <div style="font-size: 10px; font-weight: bold;">Printed on: ${new Date().toLocaleString()}</div>
            </div>
        </body>
        </html>
    `;

    doc.open();
    doc.write(htmlContent);
    doc.close();

    iframe.onload = () => {
        setTimeout(() => {
            try {
                iframe.contentWindow.focus();

                const isPrinted = iframe.contentWindow.document.execCommand('print', false, null);
                if (!isPrinted) {
                    iframe.contentWindow.print();
                }
                console.log("Print pipeline successfully triggered for reservation slip.");
            } catch (err) {
                console.error("Failed to execute printing routine:", err);
            }
        }, 300);
    };
}

/**
 * The Start Function:
 * This runs as soon as the Kiosk screen turns on.
 */
function init() {
    renderFloors(); // Draw the rooms on the screen
    updateClock(); // Show the current time
    setInterval(updateClock, 1000); // Refresh the clock every 1 second
    setInterval(updateAllRoomStatuses, 4000); // Ask the server for room updates every 4 seconds
}

// -----------------------------------------------------
// ROOM DASHBOARD RENDERING
// -----------------------------------------------------
function renderFloors() {
    const floorsDiv = document.getElementById("floors");
    if (!floorsDiv) return;

    // Loop at i-render ang lahat ng floor at kwarto sa isang bagsakan
    floorsDiv.innerHTML = Object.entries(rooms).map(([floor, roomList]) => `
        <div class="floor-section">
            <div class="floor-title">${floor} Floor</div>
            <div class="rooms-container">
                ${roomList.map(roomNo => `
                    <div class="room-box available" id="room-${roomNo}" onclick="openRoom('${roomNo}')" data-room="${roomNo}">
                        <div class="room-number">Room ${roomNo}</div>
                        <div id="status-${roomNo}" class="room-info">AVAILABLE</div>
                        <div id="details-${roomNo}" class="room-details" style="font-size: 10px; margin-top: 5px; font-weight: bold; color: #1e3a8a;"></div>
                        <div class="room-capacity">Cap: ${roomCapacities[roomNo] || 0}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('');

    // Immediately check the server to see which rooms are currently in use
    if (typeof updateAllRoomStatuses === 'function') updateAllRoomStatuses();
}

/**
 * updateAllRoomStatuses:
 * This is the most important function for the Kiosk.
 * It constantly checks: "What is happening in this room right now?"
 */
async function updateAllRoomStatuses() {
    const now = new Date();
    const currentTimeStr = now.toTimeString().split(' ')[0];
    const nowVal = now.getHours() * 60 + now.getMinutes();

    let lockedRooms = [];
    try {
        lockedRooms = await (await fetch('/api/maintenance/status')).json();
    } catch (err) { console.error("Maint error:", err); }

    for (const roomNo of Object.values(rooms).flat()) {
        try {
            const statusEl = document.getElementById(`status-${roomNo}`);
            const detailsEl = document.getElementById(`details-${roomNo}`);
            const roomBox = document.getElementById(`room-${roomNo}`);
            if (!statusEl || !roomBox) continue;

            roomBox.classList.remove('available', 'occupied', 'incoming', 'maintenance');

            // 1. CHECK MAINTENANCE (Priority 1)
            const isMaint = lockedRooms.find(r => r.room_id === roomNo);
            if (isMaint) {
                roomBox.classList.add('maintenance');
                statusEl.innerText = "MAINTENANCE";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `<div class="status-subtext">${isMaint.reason}</div>`;
                continue;
            }

            // 2. FETCH DATA & NORMALIZATION
            const [semSchedules, reservations] = await Promise.all([
                fetch(`/api/kiosk/upcoming-semester/${roomNo}`).then(r => r.json()),
                fetch(`api/approved-reservations/${roomNo}`).then(r => r.json())
            ]);

            const allActivities = [
                ...semSchedules.map(s => ({ ...s, type: 'CLASS' })),
                ...reservations.map(r => ({
                    ...r, type: 'RESERVATION', course_section: r.section || 'RESERVATION',
                    professor: r.professor || 'N/A', is_cancelled: false
                }))
            ].sort((a, b) => a.start_time.localeCompare(b.start_time));

            // 3. EVALUATE STATUS (Ongoing vs Upcoming)
            const ongoing = allActivities.find(s => currentTimeStr >= s.start_time && currentTimeStr <= s.end_time && !s.is_cancelled);
            
            const nextClass = !ongoing && allActivities.find(s => {
                if (currentTimeStr >= s.start_time || s.is_cancelled) return false;
                const [sH, sM] = s.start_time.split(':').map(Number);
                const diff = (sH * 60 + sM) - nowVal;
                return diff > 0 && diff <= 180;
            });

            // 4. COMPACT RENDER LOGIC
            const active = ongoing || nextClass;
            if (active) {
                const isPending = nextClass && active.status === 'Pending';
                const statusText = ongoing ? "OCCUPIED" : (isPending ? "PENDING" : "UPCOMING");
                
                roomBox.classList.add(ongoing ? 'occupied' : 'incoming');
                statusEl.innerText = statusText;
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `
                    <div class="course-tag">${active.course_section}</div>
                    <div class="subject-tag">${active.subject}</div>
                    <div class="prof-tag">Prof. ${active.professor}</div>
                    <div class="status-subtext">${ongoing ? 'ENDS' : 'STARTS'}: ${formatTo12Hour(ongoing ? active.end_time : active.start_time)}</div>
                `;
            } else {
                roomBox.classList.add('available');
                statusEl.innerText = "AVAILABLE";
                detailsEl.innerHTML = "";
                detailsEl.style.display = "none";
            }
        } catch (err) {
            console.error(`Error on Room ${roomNo}:`, err);
        }
    }
}

/**
 * checkMaintenanceStatus:
 * This is a secondary helper that specifically double-checks 
 * the maintenance status every 5 seconds.
 */
async function checkMaintenanceStatus() {
    try {
        const res = await fetch('/api/maintenance/status');
        const lockedRooms = await res.json();

        // Clear the maintenance color from all rooms first
        document.querySelectorAll('.room-box').forEach(box => box.classList.remove('maintenance'));

        // Put the Gray color back on only the rooms that are actually locked
        lockedRooms.forEach(data => {
            const roomBox = document.getElementById(`room-${data.room_id}`);
            if (roomBox) {
                roomBox.classList.add('maintenance');
                const statusEl = document.getElementById(`status-${data.room_id}`);
                if (statusEl) statusEl.innerText = "MAINTENANCE";

                const detailsEl = document.getElementById(`details-${data.room_id}`);
                if (detailsEl) detailsEl.innerHTML = `<div class="status-subtext">${data.reason}</div>`;
            }
        });
    } catch (err) {
        console.error("Maintenance check error:", err);
    }
}

// Start the timer: Check for "Broken" rooms every 5 seconds
setInterval(checkMaintenanceStatus, 5000);

/**
 * =====================================================
 * KIOSK MODAL & RFID SYSTEM
 * =====================================================
 */

// Variables to keep track of the RFID scanner and the popup window
let rfidBuffer = "";
let scanningTimer = null;
let currentRFIDUser = null;
let currentUserRole = "";

/**
 * openRoom:
 * This opens the popup (Modal) when you click a room box.
 */
function openRoom(roomNo) {
    const roomBox = document.getElementById(`room-${roomNo}`);
    if (roomBox?.classList.contains('maintenance')) {
        return Swal.fire({
            icon: 'error', title: 'Room Unavailable',
            text: 'This room is currently under maintenance.', confirmButtonColor: '#1e3a8a'
        });
    }

    isModalOpen = true;
    selectedRoomForReserve = roomNo;
    rfidBuffer = "";

    document.getElementById("modal").style.display = "flex";
    document.getElementById("roomTitle").innerText = `Room ${roomNo}`;

    // Helper para hindi paulit-ulit ang istilo ng mga PIN buttons
    const pinBtn = (num, extra = '') => 
        `<button type="button" onclick="pressPinNum('${num}')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;" ${extra}>${num}</button>`;

    document.querySelector(".kiosk-modal-body").innerHTML = `
        <div style="display: flex; gap: 20px; min-height: 480px; width: 850px; align-items: stretch; margin: 0 auto;">
            <div style="flex: 1.5; display: flex; flex-direction: column; gap: 12px;">
                <div id="rfidStatus" style="background: #fef08a; color: #854d0e; padding: 10px; text-align: center; font-weight: 800; border-radius: 8px; font-size: 13px; border: 1px solid #fde047;">
                    TAP RFID TO START
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 5px;">
                    <div id="pinBox" style="grid-column: span 2; display: none;">
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a; display: block; text-align: center;"> ENTER SECURITY PIN</label>
                        <input type="password" id="formPin" maxlength="4" readonly placeholder="• • • •" style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px; font-size: 24px; letter-spacing: 12px; text-align: center; font-weight: bold; background: white; margin-bottom: 12px; color: #1e3a8a;">
                        
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; max-width: 280px; margin: 0 auto;">
                            ${[1,2,3,4,5,6,7,8,9].map(n => pinBtn(n)).join('')}
                            <button type="button" onclick="clearPin()" style="padding: 15px; font-size: 16px; font-weight: bold; background: #ef4444; color: white; border: none; border-radius: 8px; cursor: pointer;">CLEAR</button>
                            ${pinBtn(0)}
                            <button type="button" onclick="backspacePin()" style="padding: 15px; font-size: 18px; font-weight: bold; background: #475569; color: white; border: none; border-radius: 8px; cursor: pointer;">⌫</button>
                        </div>
                    </div>

                    <div style="grid-column: span 2;">
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">User</label>
                        <input type="text" id="formIdentifier" placeholder="Waiting for RFID..." disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; font-weight: bold;">
                    </div>
                    
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">Date</label>
                        <input type="date" id="formDate" value="${new Date().toISOString().split('T')[0]}" disabled style="width: 100%; padding: 15px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">Purpose</label>
                        <select id="formPurpose" disabled onchange="handlePurposeChange()" style="width: 100%; padding: 15px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                            <option value="CLASS">CLASS</option><option value="EVENT">EVENT</option><option value="MEETING">MEETING</option><option value="EXAM">EXAM</option>
                        </select>
                    </div>

                    <div id="academicBox" style="grid-column: span 2; display: none; gap: 12px;"></div>

                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">Start Time</label>
                        <input type="time" id="formStart" disabled style="width: 100%; padding: 15px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">End Time</label>
                        <input type="time" id="formEnd" disabled style="width: 100%; padding: 15px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                    </div>
                </div>

                <button id="submitBtn" onclick="submitAdHocReservation()" disabled style="margin-top: auto; background: #94a3b8; color: white; padding: 14px; border: none; border-radius: 8px; font-weight: bold; font-size: 13px; transition: 0.3s;">
                    LOCKED - TAP RFID
                </button>
            </div>

            <div style="flex: 1.1; background: #f8fafc; padding: 15px; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; flex-direction: column; max-height: 520px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <h3 style="font-size: 15px; color: #1e3a8a; font-weight: 800; margin: 0;">Existing Schedule</h3>
                    </div>
                    <select id="dayFilter" onchange="renderRoomSchedule('${roomNo}', this.value)" style="font-size: 11px; padding: 10px; border-radius: 6px; border: 1px solid #cbd5e1; outline: none; cursor: pointer; background: white; font-weight: 600; color: #334155;">
                        <option value="today">TODAY</option>
                        ${['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => `<option value="${day}">${day.toUpperCase()}</option>`).join('')}
                    </select>
                </div>
                <div id="modalScheduleList" style="overflow-y: auto; flex-grow: 1; padding-right: 5px;">
                    <p style="text-align:center; font-size:12px; color: #94a3b8; margin-top: 20px;">Loading schedule...</p>
                </div>
            </div>
        </div>`;

    renderRoomSchedule(roomNo);
}

function handleSuccessfulRFIDScan(userData) {
    currentRFIDUser = userData;
    document.getElementById('accessBanner').textContent = `ACCESS GRANTED: ${userData.identifier}`;
    document.getElementById('displayOrg').value = userData.identifier;
}

function unlockFormWithRFID(userData) {
    // 1. Save global state variables
    currentRFIDUser = userData;
    currentUserRole = userData.role; 

    // 3. Enable Inputs & Set Identifier
    ['formDate', 'formPurpose', 'formStart', 'formEnd'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.disabled = false;
    });
    
    const idField = document.getElementById('formIdentifier');
    if (idField) idField.value = userData.identifier;

    // 4. Show PIN Box & Reset/Clear Existing PIN
    const pinBox = document.getElementById('pinBox');
    if (pinBox) pinBox.style.display = "block";

    if (typeof clearPin === 'function') clearPin();
    else if (document.getElementById('formPin')) document.getElementById('formPin').value = "";

    // 5. Update Submit Button
    const submitBtn = document.getElementById('submitBtn');
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = "CONFIRM & RESERVE ROOM";
        submitBtn.style.background = "#2563eb";
    }

    // 6. Trigger Dynamic Dropdowns safely
    if (typeof buildDynamicDropdowns === 'function') buildDynamicDropdowns(userData);
}

function buildDynamicDropdowns(userData) {
    const academicBox = document.getElementById('academicBox');
    if (!academicBox) return;

    academicBox.style.display = "grid";
    const tags = userData.additional_info || [];
    const selectStyle = 'width: 100%; padding: 10px; border: 1.5px solid #cbd5e1; border-radius: 8px; background: white; color: #334155; font-weight: 600;';

    if (userData.role === 'professor') {
        academicBox.style.gridTemplateColumns = "1fr 1fr";

        const sections = new Set(), subjects = new Set();
        tags.forEach(t => {
            if (t.course_section || t.section) sections.add((t.course_section || t.section).trim());
            if (t.subjects || t.subject) subjects.add((t.subjects || t.subject).trim());
        });

        academicBox.innerHTML = `
            <div>
                <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">Handle Section</label>
                <select id="dynSection" style="${selectStyle}">
                    <option value="">Select Section</option>
                    ${[...sections].map(s => `<option value="${s}">${s}</option>`).join('')}
                </select>
            </div>
            <div>
                <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">Subject</label>
                <select id="dynSubject" style="${selectStyle}">
                    <option value="">Select Subject</option>
                    ${[...subjects].map(s => `<option value="${s}">${s}</option>`).join('')}
                </select>
            </div>`;

    } else if (userData.role === 'student') {
        academicBox.style.gridTemplateColumns = "1fr";

        const combined = new Set(tags.map(t => 
            `${(t.subjects || t.subject || "Unknown Subject").trim()}|${(t.professor_name || t.professor || "TBA").trim()}`
        ));

        academicBox.innerHTML = `
            <div>
                <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📖 Subject & Assigned Professor</label>
                <select id="dynCombined" style="${selectStyle}">
                    <option value="">Select Subject & Professor</option>
                    ${[...combined].map(item => {
                        const [subj, prof] = item.split('|');
                        return `<option value="${item}">${subj} (Prof. ${prof})</option>`;
                    }).join('')}
                </select>
            </div>`;
    }
}

function handlePurposeChange() {
    const purpose = document.getElementById('formPurpose').value;
    const academicBox = document.getElementById('academicBox');

    if (currentUserRole === 'student') {
        if (purpose === 'EVENT' || purpose === 'MEETING') {
            academicBox.style.display = 'none';
        } else {
            academicBox.style.display = 'grid';
            academicBox.style.gridTemplateColumns = '1fr';
        }
    }
}

/**
 * RFID SCANNER LISTENER
 */
document.addEventListener('keydown', function(e) {
    if (!isModalOpen) return;

    if (e.key === 'Enter') {
        if (rfidBuffer.length > 3) processKioskRFID(rfidBuffer);
        rfidBuffer = "";
        return;
    }

    if (e.key.length === 1 && !isNaN(e.key)) {
        rfidBuffer += e.key;
        clearTimeout(scanningTimer);
        scanningTimer = setTimeout(() => { rfidBuffer = ""; }, 100);
    }
});

function setStatusBanner(text, bg, color, border = bg) {
    const el = document.getElementById('rfidStatus');
    if (el) {
        el.innerHTML = text;
        Object.assign(el.style, { background: bg, color: color, border: `1px solid ${border}` });
    }
}

async function processKioskRFID(rfidSerial) {
    if (!rfidSerial) return;
    currentRFIDUser = null;

    setStatusBanner("🔄 SCANNING CARD...", "#fef3c7", "#92400e", "#fcd34d");

    try {
        const response = await fetch(`api/rfid-users/${rfidSerial}`);
        const result = await response.json().catch(() => ({ success: false, message: "Malformed gateway payload." }));

        if (response.ok && result.success) {
            const userData = result.data;

            // ==========================================
            // BAGONG GUARD BLOCK: HARANG KUNG BLOCKED ANG RFID
            // ==========================================
            const isBlocked = userData.is_blocked === true || userData.is_blocked === 't' || parseInt(userData.cancel_strikes) >= 3;

            if (isBlocked) {
                // 1. Gawing pula ang Status Banner ng Kiosk
                setStatusBanner("ACCOUNT BLOCKED", "#fee2e2", "#991b1b", "#fca5a5");
                
                // 2. I-lock o i-disable ang mga input kung sakaling nakabukas ang form
                ['formDate', 'formPurpose', 'formStart', 'formEnd'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.disabled = true;
                });
                
                const submitBtn = document.getElementById('submitBtn');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = "BOOKING SUSPENDED";
                    submitBtn.style.background = "#64748b";
                }

                // 3. Magbato ng SweetAlert para alam ng user kung bakit bawal
                Swal.fire({
                    icon: 'error', 
                    title: 'ACCESS SUSPENDED',
                    text: `The account for ${userData.identifier || 'this card'} has been BLOCKED due to reaching 3 cancellation strikes. Please look for the Admin to unblock your account.`,
                    confirmButtonColor: '#ef4444'
                });

                return; // HINTO RITO. Hindi na nito tatawagin ang unlockFormWithRFID.
            }
            currentRFIDUser = result.data;
            console.log("RFID User loaded:", currentRFIDUser);
            
            if (typeof unlockFormWithRFID === 'function') unlockFormWithRFID(currentRFIDUser);
            setStatusBanner("RFID VERIFIED", "#dcfce7", "#166534", "#4ade80");
        } else {
            setStatusBanner("UNREGISTERED RFID", "#fee2e2", "#991b1b", "#fca5a5");
            Swal.fire({
                icon: 'error', title: 'Unregistered Card',
                text: result.message || 'This RFID credential is not registered in the system database.',
                confirmButtonColor: '#ef4444'
            });
        }
    } catch (error) {
        console.error("Critical RFID Fetch Failure:", error);
        setStatusBanner("GATEWAY OFFLINE", "#fee2e2", "#991b1b", "#fca5a5");
        Swal.fire({
            icon: 'error', title: 'Connection Failure',
            text: 'Unable to communicate with the central database server.',
            confirmButtonColor: '#ef4444'
        });
    }
}

// =====================================================
// CHAPTER 2: SAFE TOUCHSCREEN NUMPAD ENGINES
// =====================================================
let pinBuffer = "";
let isSubmittingTransaction = false; 

function updatePinDisplay() {
    const pinInput = document.getElementById('formPin');
    if (pinInput) pinInput.value = "•".repeat(pinBuffer.length);
}

function pressPinNum(num) {
    if (pinBuffer.length < 4) { pinBuffer += num; updatePinDisplay(); }
}

function clearPin() {
    pinBuffer = ""; updatePinDisplay();
}

function backspacePin() {
    if (pinBuffer.length) { pinBuffer = pinBuffer.slice(0, -1); updatePinDisplay(); }
}
// =====================================================
// CHAPTER 3: UNIFIED VALIDATION & CONFLICT ENGINE
// =====================================================

async function isReservationValid(data, activities) {
    const newStart = data.start_time.substring(0, 5);
    const newEnd = data.end_time.substring(0, 5);
    
    const now = new Date();
    const currentTime = now.toTimeString().substring(0, 5);
    const todayDate = now.toISOString().split('T')[0];

    // 1. CHECK INVALID TIME RANGE
    if (newEnd <= newStart) {
        await Swal.fire({
            icon: 'error', title: 'Invalid Time Range',
            text: 'The End Time must be later than the Start Time.', confirmButtonColor: '#ef4444'
        });
        return false;
    }

    // 2. CHECK PAST TIME IF DATE IS TODAY
    if (data.date === todayDate && newStart < currentTime) {
        await Swal.fire({
            icon: 'warning', title: 'Time Already Passed',
            text: `You cannot book ${FormatTo12Hour(newStart)} because the current time is already ${FormatTo12Hour(currentTime)}.`,
            confirmButtonColor: '#f59e0b'
        });
        return false;
    }

    // 3. CHECK SCHEDULE CONFLICT
    const hasConflict = activities.some(sched => {
        if (sched.is_cancelled) return false;
        const schedDate = sched.date ? new Date(sched.date).toISOString().split('T')[0] : null;
        return schedDate === data.date && newStart < sched.end_time.substring(0, 5) && newEnd > sched.start_time.substring(0, 5);
    });

    if (hasConflict) {
        await Swal.fire({
            icon: 'warning', title: 'Schedule Conflict',
            text: 'This time slot is already occupied.', confirmButtonColor: '#f59e0b'
        });
        return false;
    }

    return true;
}

async function submitAdHocReservation() {
    // 1. RFID ACCESS CHECK
    if (!currentRFIDUser) {
        return Swal.fire({ icon: 'warning', title: 'RFID Scan Required', text: 'Please tap your RFID card on the scanner before proceeding.', confirmButtonColor: '#f59e0b' });
    }

    // 2. TOUCHSCREEN PIN VALIDATION
    const enteredPin = (typeof pinBuffer !== 'undefined' ? pinBuffer : "").trim();
    const expectedPin = String(currentRFIDUser.security_pin || "").trim();

    if (!enteredPin || enteredPin.length < 4) {
        return Swal.fire({ icon: 'warning', title: 'Security PIN Required', text: 'Please enter your 4-digit security PIN using the touchscreen numpad.', confirmButtonColor: '#f59e0b' });
    }

    if (enteredPin !== expectedPin) {
        Swal.fire({ icon: 'error', title: 'Invalid PIN', text: `The security PIN entered does not match the credentials for ${currentRFIDUser.identifier || 'this account'}.`, confirmButtonColor: '#ef4444' });
        if (typeof clearPin === 'function') clearPin();
        return;
    }

    // 3. DYNAMIC ACCOUNT ROLE PARSING
    let sectionVal = "", subjectVal = "", professorVal = "TBA";

    if (currentRFIDUser.role === 'professor') {
        sectionVal = document.getElementById('dynSection')?.value || "";
        subjectVal = document.getElementById('dynSubject')?.value || "";
        professorVal = currentRFIDUser.identifier || "Unknown Professor";
    } else if (currentRFIDUser.role === 'student') {
        sectionVal = currentRFIDUser.identifier || "Unknown Section";
        const dynCombined = document.getElementById('dynCombined')?.value || "";
        
        if (dynCombined.includes('|')) {
            const [subj, prof] = dynCombined.split('|');
            subjectVal = subj.trim();
            professorVal = prof.trim();
        } else {
            subjectVal = dynCombined || "TBA";
        }
    }

    if (!sectionVal || !subjectVal || !professorVal || professorVal === "TBA") {
        return Swal.fire({
            icon: 'warning',
            title: 'Incomplete Academic Details',
            text: currentRFIDUser.role === 'professor' 
                ? 'Please select both the Handle Section and Subject before submitting.' 
                : 'Please select a valid Subject & Assigned Professor from the dropdown.',
            confirmButtonColor: '#f59e0b'
        });
    }

    // 4. PAYLOAD MATRIX CONSTRUCTION
    const reservationData = {
        room: typeof selectedRoomForReserve !== 'undefined' ? selectedRoomForReserve : "Room 103",
        rfid_tag: currentRFIDUser.rfid_serial || "",
        section: sectionVal,
        subject: subjectVal,
        professor: professorVal,
        date: document.getElementById('formDate')?.value || "",
        start_time: document.getElementById('formStart')?.value || "",
        end_time: document.getElementById('formEnd')?.value || "",
        purpose: document.getElementById('formPurpose')?.value || "CLASS"
    };

    const inputDate = document.getElementById('formDate')?.value || "";
    const todayDate = new Date().toLocaleDateString('sv-SE'); // Nagluluwa ng saktong "YYYY-MM-DD" base sa system clock
    if (!inputDate) {
        return Swal.fire({ icon: 'warning', title: 'Date Required', text: 'Please select a reservation date.', confirmButtonColor: '#f59e0b' });
    }
    if (inputDate < todayDate) {
        return Swal.fire({
            icon: 'error',
            title: 'Invalid Date',
            text: 'You cannot block or reserve a slot from a past date. Please select today or a future date.',
            confirmButtonColor: '#ef4444'
        });
    }

    // 5. POST TRANSMISSION TO EXPRESS API
    try {
        Swal.showLoading();

        const response = await fetch('api/reservations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(reservationData)
        });

        const result = await response.json().catch(() => ({ success: false, message: "Malformed server response received." }));

        if (response.ok && result.success) {
            await Swal.fire({ icon: 'success', title: 'Reservation Saved!', text: 'Your schedule request has been queued and is waiting for approval.', timer: 2000, showConfirmButton: false });

            if (typeof clearPin === 'function') clearPin();
            const modalElement = document.getElementById("modal");
            if (modalElement) modalElement.style.display = "none";
            if (typeof isModalOpen !== 'undefined') isModalOpen = false;
            if (typeof loadPendingRequests === 'function') loadPendingRequests();
        } else {
            Swal.fire({ icon: 'warning', title: 'Reservation Denied', text: result.message || 'The system detected a structural schedule conflict.' });
            if (typeof clearPin === 'function') clearPin();
        }
    } catch (err) {
        console.error("Critical Post Connection Failure:", err);
        Swal.fire({ icon: 'error', title: 'Server Timeout', text: 'Unable to communicate with the database gateway. Please verify network connection.' });
    }
}

function getTargetDate(selectedDay) {
    const now = new Date();
    
    const formatToYMD = (dateObj) => dateObj.toLocaleDateString('sv-SE');

    // 1. Kung 'today' o walang pinasa, ibigay agad ang petsa ngayon
    if (!selectedDay || selectedDay.toLowerCase() === 'today') return formatToYMD(now);

    // 2. Mapa ng mga araw para sa pagkukuwenta
    const daysMap = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
    const targetDayNum = daysMap[selectedDay.toLowerCase()];
    
    if (targetDayNum === undefined) return selectedDay; // Kung calendar date na ang pinasa, ibalik lang

    // 3. Alamin kung ilang araw ang bibilangin pasulong para marating ang target na araw
    let daysToAdd = targetDayNum - now.getDay();
    if (daysToAdd < 0) daysToAdd += 7; // Kung nakalipas na ang araw sa linggong ito, kunin ang sa susunod

    // 4. I-compute at i-return ang target date
    now.setDate(now.getDate() + daysToAdd);
    return formatToYMD(now);
}

/**
 * renderRoomSchedule:
 * Draws the "Existing Schedule" list on the right side of the popup.
 */
async function renderRoomSchedule(roomNo, selectedDay = 'today') {
    const scheduleList = document.getElementById("modalScheduleList");
    if (!scheduleList) return;

    const nowTime = new Date().toTimeString().split(' ')[0];
    const targetDateStr = getTargetDate(selectedDay);

    try {
        const [semRes, reserveRes] = await Promise.all([
            fetch(`/api/kiosk/upcoming-semester/${roomNo}?day=${selectedDay}`),
            fetch(`api/approved-reservations/${roomNo}?date=${targetDateStr}`)
        ]);

        const semSchedules = await semRes.json();
        const reservations = await reserveRes.json();

        // Merge, Tag, and Filter at the same time
        const combined = [
            ...semSchedules.map(s => ({ ...s, type: 'CLASS' })),
            ...reservations.map(r => ({ ...r, type: 'RESERVATION', course_section: r.section, professor: r.professor || 'N/A' }))
        ];

        const upcomingAndOngoing = (selectedDay === 'today' ? combined.filter(item => item.end_time > nowTime) : combined)
            .sort((a, b) => a.start_time.localeCompare(b.start_time));

        if (!upcomingAndOngoing.length) {
            scheduleList.innerHTML = `<div style="text-align:center; margin-top:40px; color:#94a3b8; font-size:13px;">No scheduled activities for this day.</div>`;
            return;
        }

        scheduleList.innerHTML = upcomingAndOngoing.map(item => {
            const isCancelled = item.is_cancelled === true;
            let statusColor = "#3b82f6", statusLabel = item.type === 'RESERVATION' ? "RESERVED" : "SCHEDULED";

            if (isCancelled) {
                statusColor = "#94a3b8"; statusLabel = "CANCELLED";
            } else if (selectedDay === 'today') {
                const isOngoing = nowTime >= item.start_time && nowTime <= item.end_time;
                statusColor = isOngoing ? "#ef4444" : "#f59e0b";
                statusLabel = isOngoing ? "ON-GOING" : "UPCOMING";
            }

            return `
            <div style="background: white; padding: 15px; border-radius: 12px; margin-bottom: 12px; border-left: 5px solid ${statusColor}; box-shadow: 0 2px 6px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 4px; ${isCancelled ? 'opacity: 0.8;' : ''}">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="background: ${statusColor}20; color: ${statusColor}; font-size: 10px; font-weight: 900; padding: 4px 8px; border-radius: 5px; text-transform: uppercase;">
                        ${statusLabel}
                    </span>
                    <div style="font-size: 12px; font-weight: 700; color: #475569; display: flex; align-items: center; gap: 4px;">
                        <span>${formatTo12Hour(item.start_time)} - ${formatTo12Hour(item.end_time)}</span>
                    </div>
                </div>
                <div style="font-size: 17px; font-weight: 900; color: ${isCancelled ? '#64748b' : '#0f172a'}; line-height: 1.2; margin-top: 4px;">
                    ${item.subject}
                    ${isCancelled ? '<small style="display:block; font-size:10px; color:#ef4444;">(This session is cancelled)</small>' : ''}
                </div>
                <div style="font-size: 11px; color: #64748b; font-weight: 600; border-top: 1px solid #f1f5f9; padding-top: 8px; margin-top: 4px;">
                    ${item.course_section} <span style="color: #cbd5e1; margin: 0 4px;">|</span> Prof. ${item.professor}
                </div>
            </div>`;
        }).join('');

    } catch (err) {
        console.error(err);
        scheduleList.innerHTML = `<p style="color:red; text-align:center; font-size:12px;">Connection Error.</p>`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const approvalModal = document.getElementById("approvalModal");

    // Buksan ang modal gamit ang 'flex' para laging gitna
    document.getElementById("openApprovalBtn")?.addEventListener("click", () => {
        if (approvalModal) approvalModal.style.display = "flex";
        if (typeof loadPendingRequests === 'function') loadPendingRequests();
    });

    // Isara ang modal pag pinindot yung 'X'
    document.getElementById("closeApprovalBtn")?.addEventListener("click", () => {
        if (approvalModal) approvalModal.style.display = "none";
    });

    // Isara ang modal pag pinindot yung labas/background ng table o window
    window.addEventListener("click", (e) => {
        if (e.target === approvalModal) approvalModal.style.display = "none";
    });
});

/**
 * formatTo12Hour:
 * Native JS time formatter setup. Changes "13:00" to "01:00 PM".
 */
function formatTo12Hour(time) {
    if (!time) return "";
    const [h, m] = time.split(':');
    return new Date(2000, 0, 1, h, m).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
}

/**
 * updateClock:
 * Keeps the digital clock on the Kiosk dashboard ticking every second.
 */
function updateClock() {
    const clockEl = document.getElementById("clock");
    if (clockEl) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        clockEl.innerText = new Date().toLocaleString('en-US', options);
    }
}

/**
 * closeModal:
 * Hides the popup and clears the RFID memory so the next student starts fresh.
 */
function closeModal() {
    document.getElementById("modal").style.display = "none";
    isModalOpen = false;
    rfidBuffer = "";
}

window.onload = init;