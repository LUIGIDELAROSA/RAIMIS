const app = {
    state: {
        currentUser: null,
        authMode: 'login',
        currentSelectedRating: 0,
        activeInquiryIdForRating: null
    },

    init: function() {
        if (!localStorage.getItem('bc_users')) {
            const defaultUsers = [
                { username: 'admin', password: '123', role: 'admin', name: 'System Admin', email: 'admin@bgy.gov', contact: '09123456789', address: 'Barangay Hall', isBanned: false, banUntil: null },
                { username: 'resident1', password: '123', role: 'resident', name: 'Juan Dela Cruz', email: 'juan@mail.com', contact: '09171112222', address: 'Blk 1 Lot 2, Phase 3', isBanned: false, banUntil: null },
                { username: 'provider1', password: '123', role: 'provider', name: 'Pedro Mario - Plumbing', email: 'pedro@mail.com', contact: '09183334444', address: 'St. Jude Subdivision', isBanned: false, banUntil: null }
            ];
            localStorage.setItem('bc_users', JSON.stringify(defaultUsers));
        }
        if (!localStorage.getItem('bc_posts')) localStorage.setItem('bc_posts', JSON.stringify([]));
        if (!localStorage.getItem('bc_services')) localStorage.setItem('bc_services', JSON.stringify([]));
        if (!localStorage.getItem('bc_ratings')) localStorage.setItem('bc_ratings', JSON.stringify([]));
        
        if (!localStorage.getItem('bc_wallets')) {
            const defaultWallets = { 'admin': 0.00, 'resident1': 0.00, 'provider1': 0.00 };
            localStorage.setItem('bc_wallets', JSON.stringify(defaultWallets));
        }
        
        if (!localStorage.getItem('bc_provider_credits')) {
            const defaultCredits = { 'provider1': 0.00 };
            localStorage.setItem('bc_provider_credits', JSON.stringify(defaultCredits));
        }

        if (!localStorage.getItem('bc_inquiries')) localStorage.setItem('bc_inquiries', JSON.stringify([]));
        if (!localStorage.getItem('bc_topup_requests')) localStorage.setItem('bc_topup_requests', JSON.stringify([]));

        document.getElementById('userRole').addEventListener('change', function() {
            app.handleRoleChange(this.value);
        });

        console.log("BarangayConnect: Flow Activated. Cash = Debt. Pay Debt = Admin Earnings.");
    },

    getData: function(key) { return JSON.parse(localStorage.getItem('bc_' + key)) || []; },
    setData: function(key, data) { localStorage.setItem('bc_' + key, JSON.stringify(data)); },
    
    getWalletBalance: function(username) {
        const wallets = JSON.parse(localStorage.getItem('bc_wallets')) || {};
        return wallets[username] !== undefined ? wallets[username] : 0;
    },

    getProviderCredit: function(username) {
        const credits = JSON.parse(localStorage.getItem('bc_provider_credits')) || {};
        return credits[username] !== undefined ? credits[username] : 0;
    },
    
    updateWalletBalance: function(username, amount) {
        const wallets = JSON.parse(localStorage.getItem('bc_wallets')) || {};
        if (wallets[username] === undefined) wallets[username] = 0.00;
        wallets[username] = parseFloat((wallets[username] + amount).toFixed(2));
        localStorage.setItem('bc_wallets', JSON.stringify(wallets));
        this.updateWalletUI();
        
        const wTab = document.getElementById('walletTab');
        if (wTab && wTab.style.display === 'block') {
            this.renderWalletTab();
        }
    },

    updateProviderCredit: function(username, amount) {
        const credits = JSON.parse(localStorage.getItem('bc_provider_credits')) || {};
        if (credits[username] === undefined) credits[username] = 0.00;
        credits[username] = parseFloat((credits[username] + amount).toFixed(2));
        localStorage.setItem('bc_provider_credits', JSON.stringify(credits));
    },

    updateWalletUI: function() {
        if (this.state.currentUser) {
            const bal = this.getWalletBalance(this.state.currentUser.username);
            const walletElement = document.getElementById('userWalletBalanceDisplay');
            if (walletElement) {
                walletElement.innerText = '₱' + bal.toFixed(2);
            }
        }
    },

    toggleAuth: function() {
        const regFields = document.getElementById('regFields');
        const authTitle = document.getElementById('authTitle');
        const mainAuthBtn = document.getElementById('mainAuthBtn');
        const toggleText = document.getElementById('toggleText');
        const toggleBtn = document.getElementById('toggleBtn');
        const adminOption = document.getElementById('adminOption');

        if (this.state.authMode === 'login') {
            this.state.authMode = 'register';
            regFields.style.display = 'block';
            authTitle.innerText = 'Register to Barangay';
            mainAuthBtn.innerText = 'Sign Up / Register';
            toggleText.innerText = 'Already have an account?';
            toggleBtn.innerText = 'Sign In here';
            if(adminOption) adminOption.style.display = 'none';
        } else {
            this.state.authMode = 'login';
            regFields.style.display = 'none';
            authTitle.innerText = 'Barangay Portal';
            mainAuthBtn.innerText = 'Sign In';
            toggleText.innerText = "Don't have an account?";
            toggleBtn.innerText = 'Register here';
            if(adminOption) adminOption.style.display = 'block';
        }
    },

    handleRoleChange: function(role) {
        const addressInput = document.getElementById('regAddress');
        if (role === 'provider') {
            if(addressInput) addressInput.placeholder = "Business Address / Shop Location";
        } else {
            if(addressInput) addressInput.placeholder = "Home Address (Street, Block, Lot)";
        }
    },

    handleAuth: function() {
        const role = document.getElementById('userRole').value;
        const userInp = document.getElementById('username').value.trim();
        const passInp = document.getElementById('password').value;
        const errContainer = document.getElementById('authErr');
        
        if (!userInp || !passInp) {
            Swal.fire('Error', 'Please fill in both username and password fields.', 'error');
            return;
        }

        let users = this.getData('users');

        if (this.state.authMode === 'login') {
            const user = users.find(u => u.username === userInp && u.password === passInp && u.role === role);
            
            if (user) {
                if (user.isBanned && user.banUntil) {
                    const now = Date.now();
                    const banExpiry = new Date(user.banUntil).getTime();

                    if (now < banExpiry) {
                        const remainingMs = banExpiry - now;
                        const remainingMins = Math.ceil(remainingMs / 60000);
                        
                        Swal.fire({
                            title: 'ACCOUNT BLOCK!',
                            text: `Your account is currently BANNED. There are ${remainingMins} minute(s) remaining before you can log in again.`,
                            icon: 'error',
                            confirmButtonColor: 'var(--danger)'
                        });
                        return;
                    } else {
                        user.isBanned = false;
                        user.banUntil = null;
                        this.setData('users', users);
                    }
                }

                this.state.currentUser = user;
                Swal.fire('Welcome!', `Welcome, ${user.name}!`, 'success');
                this.setupDashboard();
            } else {
                errContainer.innerText = "Invalid credentials or selected role does not match.";
            }
        } else {
            const name = document.getElementById('regName').value.trim();
            const email = document.getElementById('regEmail').value.trim();
            const contact = document.getElementById('regContact').value.trim();
            const address = document.getElementById('regAddress').value.trim();

            if (!name || !email || !contact || !address) {
                Swal.fire('Warning', 'Please fill out all registration fields.', 'warning');
                return;
            }

            if (users.some(u => u.username === userInp)) {
                errContainer.innerText = "This username is already taken.";
                return;
            }

            const newUser = { username: userInp, password: passInp, role: role, name: name, email: email, contact: contact, address: address, isBanned: false, banUntil: null };
            users.push(newUser);
            this.setData('users', users);
            this.updateWalletBalance(userInp, 0.00);
            this.updateProviderCredit(userInp, 0.00);

            Swal.fire('Success', 'Registration Complete! Your account is ready. Please log in.', 'success');
            this.toggleAuth();
        }
    },

    setupDashboard: function() {
        document.getElementById('authSec').style.display = 'none';
        document.getElementById('appSec').style.display = 'block';
        document.getElementById('navUser').style.display = 'flex';
        document.querySelectorAll('.uName').forEach(el => el.innerText = this.state.currentUser.name);

        const role = this.state.currentUser.role;
        
        if (role === 'admin') {
            document.getElementById('adminTabBtn').style.display = 'inline-block';
            document.getElementById('providerInqBtn').style.display = 'none'; 
            document.getElementById('providerOngoingBtn').style.display = 'none';
            document.getElementById('providerHistoryBtn').style.display = 'none';
            document.getElementById('providerPostBox').style.display = 'none';
        } else {
            document.getElementById('adminTabBtn').style.display = 'none';
            document.getElementById('providerInqBtn').style.display = 'inline-block';
            
            if (role === 'provider') {
                document.getElementById('providerPostBox').style.display = 'block';
                document.getElementById('providerOngoingBtn').style.display = 'inline-block';
                document.getElementById('providerHistoryBtn').style.display = 'inline-block';
            } else {
                document.getElementById('providerPostBox').style.display = 'none';
                document.getElementById('providerOngoingBtn').style.display = 'none';
                document.getElementById('providerHistoryBtn').style.display = 'inline-block';
            }
        }

        this.updateWalletUI();
        this.syncProfileData();
        this.renderFeed();
        this.renderServices();
        this.renderInquiries();
        this.renderOngoingAndHistory();
        if (role === 'admin') this.renderAdminMetrics();
    },

    logout: function() {
        this.state.currentUser = null;
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
        document.getElementById('navUser').style.display = 'none';
        document.getElementById('appSec').style.display = 'none';
        document.getElementById('authSec').style.display = 'block';
        this.state.authMode = 'login';
        document.getElementById('regFields').style.display = 'none';
        document.getElementById('authTitle').innerText = 'Barangay Portal';
        document.getElementById('mainAuthBtn').innerText = 'Sign In';
        document.getElementById('toggleText').innerText = "Don't have an account?";
        document.getElementById('toggleBtn').innerText = 'Register here';
        const adminOption = document.getElementById('adminOption');
        if(adminOption) adminOption.style.display = 'block';
    },

    switchTab: function(tabName, btnToken) {
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active-tab'));
        if (btnToken) btnToken.classList.add('active-tab');

        if(document.getElementById('feedTab')) document.getElementById('feedTab').style.display = 'none';
        if(document.getElementById('servicesTab')) document.getElementById('servicesTab').style.display = 'none';
        if(document.getElementById('inquiriesTab')) document.getElementById('inquiriesTab').style.display = 'none';
        if(document.getElementById('ongoingTab')) document.getElementById('ongoingTab').style.display = 'none';
        if(document.getElementById('historyTab')) document.getElementById('historyTab').style.display = 'none';
        if(document.getElementById('profileTab')) document.getElementById('profileTab').style.display = 'none';
        if(document.getElementById('adminTab')) document.getElementById('adminTab').style.display = 'none';
        if(document.getElementById('pendingDebtsTab')) document.getElementById('pendingDebtsTab').style.display = 'none';

        const wTab = document.getElementById('walletTab');
        if (wTab) wTab.style.display = 'none';

        const activeTabContainer = document.getElementById(tabName + 'Tab');
        if (activeTabContainer) activeTabContainer.style.display = 'block';

        if (tabName === 'wallet') {
            this.renderWalletTab();
        }

        if (tabName === 'pendingDebts') {
        this.renderPendingDebts();
}
    },

    // UI SECTION UPDATED: May "Pay Debt" option na ngayon ang Provider kung may utang sila sa cash commission
    renderWalletTab: function() {
        const user = this.state.currentUser;
        if (!user) return;

        const currentBal = this.getWalletBalance(user.username);
        const currentCredit = this.getProviderCredit(user.username);
        const tabContent = document.getElementById('walletTabContent');
        const requests = this.getData('topup_requests');

        const myRequests = requests.filter(r => r.username === user.username);
        let requestHistoryHtml = '';

        myRequests.forEach(r => {
            let statusColor = '#ecc94b'; 
            if(r.status === 'approved') statusColor = '#48bb78';
            if(r.status === 'rejected') statusColor = '#e53e3e';

            requestHistoryHtml += `
                <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #edf2f7; padding:8px 0; font-size:0.85rem;">
                    <div>
                        <strong>₱${parseFloat(r.amount).toFixed(2)}</strong> <br>
                        <small style="color:#718096;">Requested: ${r.timestamp}</small>
                    </div>
                    <span style="color:${statusColor}; font-weight:bold; text-transform:uppercase;">[${r.status}]</span>
                </div>
            `;
        });
        
        let creditSectionHtml = '';
        if (user.role === 'provider') {
            const disabledAttr = currentCredit <= 0 ? 'disabled style="background:#cbd5e0; color:#4a5568; cursor:not-allowed; border:none; padding:8px 15px; border-radius:5px; font-weight:bold;"' : 'onclick="app.providerPayDebtAction()" style="background:#e53e3e; color:white; border:none; padding:8px 15px; border-radius:5px; font-weight:bold; cursor:pointer;"';
            
            creditSectionHtml = `
                <div style="background: #fff5f5; border: 2px dashed #e53e3e; color: #c53030; padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap:10px;">
                    <div>
                        <h4 style="margin: 0; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 0.5px;">🔴 System Credit (Unpaid 5% Commission)</h4>
                        <p style="margin: 5px 0 0 0; font-size: 0.8rem; color: #9b2c2c;">Mula ito sa mga nakaraang Cash Bookings. Pindutin ang Pay Debt para pumasok sa kita ng website.</p>
                    </div>
                    <div style="text-align: right; display:flex; align-items:center; gap:15px;">
                        <h2 style="margin: 0; font-size: 1.6rem; font-weight: bold;">₱${currentCredit.toFixed(2)}</h2>
                        <button ${disabledAttr}>💳 Pay Debt</button>
                    </div>
                </div>
            `;
        }
        
        if (tabContent) {
            tabContent.innerHTML = `
                <div style="background: linear-gradient(135deg, #3182ce, #319795); color: white; padding: 25px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <p style="margin: 0; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Available Balance</p>
                    <h1 style="margin: 10px 0 0 0; font-size: 2.5rem; font-weight: bold;">₱${currentBal.toFixed(2)}</h1>
                    <p style="margin: 5px 0 0 0; font-size: 0.8rem; opacity: 0.7;">Account: ${user.name} (${user.role.toUpperCase()})</p>
                </div>

                ${creditSectionHtml}
                
                <div class="card" style="margin-bottom: 20px; text-align: center; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px;">
                    <h4 style="margin-top: 0;">Request Top-Up Funds</h4>
                    <p style="color:#718096; font-size:0.85rem; margin-bottom: 15px;">Submit a cash-in load request.</p>
                    <button id="submitTopupActionBtn" onclick="app.requestWalletTopUp()" style="background: #3182ce; color: white; border: none; border-radius: 5px; width: 100%; max-width: 250px; padding: 10px 20px; font-weight: bold; cursor: pointer;">📩 Submit Top-Up Request</button>
                </div>

                <div class="card" style="margin-bottom: 20px; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px;">
                    <h3 style="margin-top:0; border-bottom: 1px solid #edf2f7; padding-bottom: 10px;">Your Request Status History</h3>
                    <div style="max-height:180px; overflow-y:auto;">
                        ${requestHistoryHtml || '<p style="color:#a0aec0; font-size:0.85rem; text-align:center; padding:10px;">No top-up history requested yet.</p>'}
                    </div>
                </div>
            `;
        }
    },

    // BAGO: Dito na papasok sa Website Earnings (Admin) ang commission kapag nag bayad ng utang ang provider
    providerPayDebtAction: function() {
        const username = this.state.currentUser.username;
        const currentDebt = this.getProviderCredit(username);
        const currentBalance = this.getWalletBalance(username);

        if (currentDebt <= 0) return;

        if (currentBalance < currentDebt) {
            Swal.fire('Kulang ang Pondo', `Ang utang mo ay ₱${currentDebt.toFixed(2)} pero ang wallet mo ay ₱${currentBalance.toFixed(2)} lang. Mag-top up muna ng pondo.`, 'error');
            return;
        }

        Swal.fire({
            title: 'Settle System Credit',
            html: `Mababawasan ang iyong E-Wallet ng <b>₱${currentDebt.toFixed(2)}</b> para bayaran ang commission ng website. Ipagpatuloy?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#48bb78',
            confirmButtonText: 'Yes, Pay Now'
        }).then((result) => {
            if (result.isConfirmed) {
                // 1. Bawasan ang wallet ng provider
                this.updateWalletBalance(username, -currentDebt);
                // 2. I-zero o bawasan ang credit line record
                this.updateProviderCredit(username, -currentDebt);
                // 3. NGAYON LANG PAPASOK sa website earnings (admin wallet) ang komisyon!
                this.updateWalletBalance('admin', currentDebt);

                Swal.fire('Credit Settled', 'Salamat! Ang komisyon ay pumasok na sa website system earnings.', 'success');
                this.renderWalletTab();
            }
        });
    },

    requestWalletTopUp: function() {
        Swal.fire({
            title: 'Request Top-Up Amount',
            text: 'Enter the amount you wish to request for load (₱):',
            input: 'number',
            inputAttributes: { min: 50, step: 50 },
            inputValue: 500,
            showCancelButton: true,
            confirmButtonColor: '#3182ce',
            confirmButtonText: 'Submit Request',
            inputValidator: (value) => {
                if (!value || parseFloat(value) <= 0) {
                    return 'Please enter a valid amount!';
                }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const amount = parseFloat(result.value);
                let requests = this.getData('topup_requests');

                const newRequest = {
                    id: 'req_' + Date.now(),
                    username: this.state.currentUser.username,
                    name: this.state.currentUser.name,
                    role: this.state.currentUser.role,
                    amount: amount,
                    status: 'pending',
                    timestamp: new Date().toLocaleString()
                };

                requests.unshift(newRequest);
                this.setData('topup_requests', requests);

                Swal.fire('Request Filed', `Your top-up request for ₱${amount.toFixed(2)} has been submitted to Admin.`, 'success');
                this.renderWalletTab();
            }
        });
    },

    createPost: function() {
        const text = document.getElementById('postContent').value.trim();
        if (!text) return;

        let posts = this.getData('posts');
        const newPost = {
            id: 'post_' + Date.now(),
            author: this.state.currentUser.name,
            role: this.state.currentUser.role,
            content: text,
            timestamp: new Date().toLocaleString()
        };
        posts.unshift(newPost);
        this.setData('posts', posts);
        document.getElementById('postContent').value = '';
        this.renderFeed();
        if (this.state.currentUser.role === 'admin') this.renderAdminMetrics();
    },

    renderFeed: function() {
        const list = document.getElementById('feedList');
        if(!list) return;
        const posts = this.getData('posts');
        const user = this.state.currentUser;
        list.innerHTML = '';

        if(posts.length === 0) {
            list.innerHTML = '<p style="color:#718096; text-align:center; padding: 20px;">No announcements found.</p>';
            return;
        }

        posts.forEach(p => {
            const badgeColor = p.role === 'admin' ? 'red' : (p.role === 'provider' ? 'blue' : 'green');
            const deleteBtnHtml = (user && user.role === 'admin') 
                ? `<button onclick="app.adminDeletePost('${p.id}')" style="background:var(--danger); padding:4px 10px; font-size:0.75rem; float:right;">Delete Post</button>` 
                : '';

            list.innerHTML += `
                <div class="card" style="margin-top:15px; overflow:hidden;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong>${p.author}</strong>
                            <span style="background:${badgeColor}; color:white; font-size:0.7rem; padding:2px 8px; border-radius:10px; margin-left:10px;">${p.role.toUpperCase()}</span>
                        </div>
                        ${deleteBtnHtml}
                    </div>
                    <p style="margin:10px 0; color:#2d3748; clear:both;">${p.content}</p>
                    <small style="color:#a0aec0; font-size:0.75rem;">Published on: ${p.timestamp}</small>
                </div>
            `;
        });
    },

    adminDeletePost: function(postId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "This announcement will be permanently removed.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: 'var(--danger)',
            confirmButtonText: 'Yes, Delete!'
        }).then((result) => {
            if (result.isConfirmed) {
                let posts = this.getData('posts');
                posts = posts.filter(p => p.id !== postId);
                this.setData('posts', posts);
                Swal.fire('Deleted!', 'The post has been successfully removed.', 'success');
                this.renderFeed();
                if (this.state.currentUser.role === 'admin') this.renderAdminMetrics();
            }
        });
    },

    checkOtherCategory: function(val) {
        document.getElementById('otherCatWrapper').style.display = (val === 'Others') ? 'block' : 'none';
    },

    createService: function() {
        const title = document.getElementById('svcName').value.trim();
        let cat = document.getElementById('svcCat').value;
        const price = document.getElementById('svcPrice').value;
        const desc = document.getElementById('svcDesc').value.trim();

        if (cat === 'Others') {
            cat = document.getElementById('svcOtherName').value.trim() || 'Others';
        }

        if(!title || !price || !desc) {
            Swal.fire('Warning', 'Please complete all required service details.', 'warning');
            return;
        }

        let services = this.getData('services');
        const newService = {
            id: 'svc_' + Date.now(),
            providerUsername: this.state.currentUser.username,
            providerName: this.state.currentUser.name,
            title: title,
            category: cat,
            price: parseFloat(price).toFixed(2),
            desc: desc
        };

        services.push(newService);
        this.setData('services', services);

        document.getElementById('svcName').value = '';
        document.getElementById('svcPrice').value = '';
        document.getElementById('svcDesc').value = '';
        document.getElementById('svcOtherName').value = '';
        document.getElementById('otherCatWrapper').style.display = 'none';

        Swal.fire('Success', 'Your new Service Listing has been posted!', 'success');
        this.renderServices();
        if (this.state.currentUser.role === 'admin') this.renderAdminMetrics();
    },

    renderServices: function() {
        const container = document.getElementById('serviceResults');
        if(!container) return;
        const services = this.getData('services');
        const ratings = this.getData('ratings');
        const user = this.state.currentUser;
        container.innerHTML = '';

        if(services.length === 0) {
            container.innerHTML = '<p style="color:#718096; grid-column: 1/-1; text-align:center; padding:20px;">No active services listed.</p>';
            return;
        }

        services.forEach(s => {
            const providerRatings = ratings.filter(r => r.providerUsername === s.providerUsername);
            const avgRating = providerRatings.length > 0 
                ? (providerRatings.reduce((sum, r) => sum + r.stars, 0) / providerRatings.length).toFixed(1) 
                : 'No Ratings Yet';

            const ratingStars = avgRating !== 'No Ratings Yet' ? `★ ${avgRating} (${providerRatings.length})` : '⭐ New Provider';

            let actionBtnHtml = '';
            
            if (user && user.role === 'admin') {
                actionBtnHtml = `
                    <button style="width:100%; margin-bottom:5px;" onclick="app.openInquiryModal('${s.title}', '${s.providerUsername}', '${s.providerName}')">Book Service (Inquire)</button>
                    <button style="width:100%; background:var(--danger);" onclick="app.adminDeleteService('${s.id}')">Delete Service (Admin)</button>
                `;
            } else if (user && user.username !== s.providerUsername) {
                actionBtnHtml = `<button style="width:100%;" onclick="app.openInquiryModal('${s.title}', '${s.providerUsername}', '${s.providerName}')">Book Service</button>`;
            } else {
                actionBtnHtml = `<button style="width:100%; background:#cbd5e0; color:#4a5568;" disabled>Your Service</button>`;
            }

            container.innerHTML += `
                <div class="card" style="border-top: 4px solid var(--primary); display:flex; flex-direction:column; justify-content:space-between;">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:start;">
                            <span style="font-size:0.75rem; background:#e2e8f0; padding:2px 6px; border-radius:4px; font-weight:bold; color:#4a5568;">${s.category}</span>
                            <span style="color:#ecc94b; font-weight:bold; font-size:0.85rem;">${ratingStars}</span>
                        </div>
                        <h3 style="margin:10px 0 5px 0; color:var(--dark);">${s.title}</h3>
                        <p style="font-size:0.85rem; color:#718096; margin-bottom:10px;">By: <span style="text-decoration:underline; cursor:pointer; color:var(--primary);" onclick="app.viewProfile('${s.providerUsername}')">${s.providerName}</span></p>
                        <p style="font-size:0.9rem; color:#4a5568;">${s.desc}</p>
                    </div>
                    <div style="margin-top:15px; border-top:1px solid #edf2f7; padding-top:10px;">
                        <p style="font-weight:bold; color:var(--secondary); font-size:1.1rem; margin:0 0 10px 0;">₱${s.price}</p>
                        ${actionBtnHtml}
                    </div>
                </div>
            `;
        });
    },

    adminDeleteService: function(serviceId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "This service will be deleted.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: 'var(--danger)',
            confirmButtonText: 'Yes, Delete!'
        }).then((result) => {
            if (result.isConfirmed) {
                let services = this.getData('services');
                services = services.filter(s => s.id !== serviceId);
                this.setData('services', services);
                Swal.fire('Deleted!', 'Service removed.', 'success');
                this.renderServices();
                if (this.state.currentUser.role === 'admin') this.renderAdminMetrics();
            }
        });
    },

    search: function() {
        const query = document.getElementById('searchBar').value.toLowerCase();
        const cards = document.querySelectorAll('#serviceResults .card');
        
        cards.forEach(card => {
            const text = card.innerText.toLowerCase();
            card.style.display = text.includes(query) ? 'flex' : 'none';
        });
    },

    syncProfileData: function() {
        const user = this.state.currentUser;
        if(!document.getElementById('pInit')) return;
        document.getElementById('pInit').innerText = user.name.charAt(0).toUpperCase();
        document.getElementById('pRole').innerText = user.role.toUpperCase();
        document.getElementById('pUser').innerText = user.username;
        document.getElementById('pEmail').innerText = user.email;
        document.getElementById('pContact').innerText = user.contact;
        document.getElementById('pAddress').innerText = user.address;
        
        const bal = this.getWalletBalance(user.username);
        const pWallet = document.getElementById('pWalletBalance');
        if (pWallet) pWallet.innerText = '₱' + bal.toFixed(2);
    },

    enableProfileEdit: function() {
        const user = this.state.currentUser;
        document.getElementById('editFullName').value = user.name;
        document.getElementById('editEmail').value = user.email;
        document.getElementById('editContact').value = user.contact;
        document.getElementById('editAddress').value = user.address;
        document.getElementById('editPassword').value = '';

        document.getElementById('profileDisplay').style.display = 'none';
        document.getElementById('profileEdit').style.display = 'block';
    },

    cancelProfileEdit: function() {
        document.getElementById('profileEdit').style.display = 'none';
        document.getElementById('profileDisplay').style.display = 'block';
    },

    saveProfileChanges: function() {
        let users = this.getData('users');
        const index = users.findIndex(u => u.username === this.state.currentUser.username);
        
        if(index !== -1) {
            users[index].name = document.getElementById('editFullName').value.trim();
            users[index].email = document.getElementById('editEmail').value.trim();
            users[index].contact = document.getElementById('editContact').value.trim();
            users[index].address = document.getElementById('editAddress').value.trim();
            
            const newPass = document.getElementById('editPassword').value;
            if(newPass) users[index].password = newPass;

            this.state.currentUser = users[index];
            this.setData('users', users);
            
            this.syncProfileData();
            document.querySelectorAll('.uName').forEach(el => el.innerText = this.state.currentUser.name);
            this.cancelProfileEdit();
            Swal.fire('Updated', 'Your information has been successfully updated.', 'success');
        }
    },

    viewProfile: function(username) {
        const users = this.getData('users');
        const ratings = this.getData('ratings');
        const target = users.find(u => u.username === username);

        if(!target) return;

        const providerRatings = ratings.filter(r => r.providerUsername === username);
        const avgRating = providerRatings.length > 0 
            ? (providerRatings.reduce((sum, r) => sum + r.stars, 0) / providerRatings.length).toFixed(1) 
            : 'No ratings';

        let ratingLogsHtml = '';
        providerRatings.forEach(r => {
            ratingLogsHtml += `
                <div style="border-bottom:1px dashed #eee; padding:5px 0;">
                    <span style="color:#ecc94b;">${'★'.repeat(r.stars)}</span> 
                    <small style="color:#718096;">from ${r.senderName}</small>
                </div>
            `;
        });

        const modalData = document.getElementById('profileViewData');
        modalData.innerHTML = `
            <div style="text-align:center;">
                <div style="width:60px; height:60px; background:var(--secondary); color:white; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 10px; font-size:1.5rem; font-weight:bold;">${target.name.charAt(0).toUpperCase()}</div>
                <h2>${target.name}</h2>
                <span style="background:#e2e8f0; padding:2px 10px; border-radius:10px; font-size:0.8rem;">${target.role.toUpperCase()}</span>
                <p style="color:#ecc94b; font-weight:bold; margin:5px 0;">Reputation: ★ ${avgRating}</p>
                <hr style="margin:15px 0; border:0; border-top:1px solid #eee;">
                <div style="text-align:left; font-size:0.95rem; line-height:1.6;">
                    <p><strong>Email:</strong> ${target.email}</p>
                    <p><strong>Contact:</strong> ${target.contact}</p>
                    <p><strong>Address:</strong> ${target.address}</p>
                </div>
                ${target.role === 'provider' ? `
                    <div style="text-align:left; margin-top:15px;">
                        <h4>Neighbors' Feedback:</h4>
                        <div style="max-height:120px; overflow-y:auto;">${ratingLogsHtml || '<p style="color:#a0aec0; font-size:0.85rem;">No reviews yet.</p>'}</div>
                    </div>
                ` : ''}
            </div>
        `;
        document.getElementById('viewProfileModal').style.display = 'block';
    },

    closeProfileModal: function() {
        document.getElementById('viewProfileModal').style.display = 'none';
    },

    openInquiryModal: function(svcTitle, providerUser, providerName) {
        document.getElementById('tempSvcTitle').value = svcTitle;
        document.getElementById('tempSvcProvider').value = providerUser;
        
        document.getElementById('inqSenderDetails').innerHTML = `
            <strong>Send to:</strong> ${providerName}<br>
            <strong>Service Selected:</strong> ${svcTitle}
        `;
        document.getElementById('inqMessage').value = '';
        document.getElementById('inquiryModal').style.display = 'block';
    },

    submitInquiry: function() {
        const msg = document.getElementById('inqMessage').value.trim();
        const title = document.getElementById('tempSvcTitle').value;
        const providerUser = document.getElementById('tempSvcProvider').value;
        const services = this.getData('services');
        const targetSvc = services.find(s => s.title === title && s.providerUsername === providerUser);

        if(!msg) {
            Swal.fire('Error', 'Please provide a message or job details.', 'error');
            return;
        }

        let inquiries = this.getData('inquiries');
        const newInq = {
            id: 'inq_' + Date.now(),
            serviceTitle: title,
            providerUsername: providerUser,
            providerName: targetSvc ? targetSvc.providerName : 'Provider',
            senderUsername: this.state.currentUser.username,
            senderName: this.state.currentUser.name,
            senderContact: this.state.currentUser.contact,
            senderAddress: this.state.currentUser.address,
            message: msg,
            price: targetSvc ? targetSvc.price : '0.00',
            status: 'pending',
            rated: false
        };

        inquiries.unshift(newInq);
        this.setData('inquiries', inquiries);

        document.getElementById('inquiryModal').style.display = 'none';
        Swal.fire('Sent!', 'Inquiry sent.', 'success');
        this.renderInquiries();
    },

    renderInquiries: function() {
        const container = document.getElementById('inquiryList');
        if (!container) return;
        const inquiries = this.getData('inquiries');
        const user = this.state.currentUser;
        container.innerHTML = '';

        const activeInqs = inquiries.filter(i => i.status === 'pending' && (i.providerUsername === user.username || i.senderUsername === user.username));

        if(activeInqs.length === 0) {
            container.innerHTML = '<p style="color:#718096; text-align:center; padding:20px;">No private inquiries.</p>';
            return;
        }

        activeInqs.forEach(i => {
            const isProvider = user.username === i.providerUsername;
            container.innerHTML += `
                <div class="card" style="border-left: 4px solid #ecc94b; margin-bottom:10px;">
                    <div style="display:flex; justify-content:space-between; align-items:start;">
                        <h4>${i.serviceTitle}</h4>
                        <span style="font-size:0.8rem; background:#feebc8; color:#c05621; padding:2px 8px; border-radius:10px; font-weight:bold;">PENDING</span>
                    </div>
                    <p style="font-size:0.9rem; margin:5px 0;"><strong>From:</strong> ${i.senderName}</p>
                    <p style="background:#f7fafc; padding:10px; border-radius:5px; font-style:italic; font-size:0.9rem; color:#4a5568;">"${i.message}"</p>
                    <p style="font-weight:bold; color:var(--secondary);">Price: ₱${i.price}</p>
                    <div style="margin-top:10px; display:flex; gap:10px;">
                        ${isProvider ? `
                            <button onclick="app.updateInquiryStatus('${i.id}', 'ongoing')" style="background:#48bb78;">Accept & Start</button>
                            <button onclick="app.updateInquiryStatus('${i.id}', 'rejected')" style="background:var(--danger);">Decline</button>
                        ` : `
                            <p style="font-size:0.85rem; color:#a0aec0; font-style:italic;">Waiting for provider...</p>
                        `}
                    </div>
                </div>
            `;
        });
    },

    // CORE LOGIC UPDATED: Kung Cash, hindi muna papasok sa Admin Wallet (Earnings). Sa Credit lang siya mag-aaccumulate.
    updateInquiryStatus: function(id, newStatus) {
        let inquiries = this.getData('inquiries');
        const index = inquiries.findIndex(i => i.id === id);

        if(index !== -1) {
            const targetJob = inquiries[index];

            if (newStatus === 'waiting_payment') {
                inquiries[index].status = 'waiting_payment';
                this.setData('inquiries', inquiries);
                Swal.fire('Job Marked Done', 'Abisuhan ang kliyente na kailangan na itong bayaran sa kanilang dashboard.', 'success');
                this.refreshSystemLayout();
                return;
            }

            if (newStatus === 'process_payment_execution') {
                const jobCost = parseFloat(targetJob.price) || 0;
                const clientBalance = this.getWalletBalance(targetJob.senderUsername);
                const platformCut = jobCost * 0.05;
                const providerEarnings = jobCost - platformCut;

                // A. E-Wallet Option Execution (Diretsong pasok sa admin ang commission dito)
                if (clientBalance >= jobCost) {
                    Swal.fire({
                        title: 'Confirm E-Wallet Payment',
                        html: `Mababawasan ang iyong E-Wallet ng nagkakahalagang:<br><br><b style="font-size: 1.5rem; color: #3182ce;">₱${jobCost.toFixed(2)}</b><br><br>Ipagpatuloy?`,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3182ce',
                        cancelButtonColor: '#718096',
                        confirmButtonText: 'Yes, Deduct Now',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            this.updateWalletBalance(targetJob.senderUsername, -jobCost);
                            this.updateWalletBalance(targetJob.providerUsername, providerEarnings);
                            this.updateWalletBalance('admin', platformCut); // Pasok agad sa admin kapag e-wallet route

                            inquiries[index].status = 'completed';
                            inquiries[index].paymentMethod = 'e-wallet';
                            this.setData('inquiries', inquiries);

                            Swal.fire('Payment Success', `Ang halagang ₱${jobCost.toFixed(2)} ay matagumpay na naawas.`, 'success');
                            this.refreshSystemLayout();
                        }
                    });
                    return;
                } 
                // B. Cash Trigger Logic
                else {
                    Swal.fire({
                        title: 'Choose Payment Option',
                        html: `Ang kailangang halaga ay <b>₱${jobCost.toFixed(2)}</b> pero ang wallet mo lang ay <b>₱${clientBalance.toFixed(2)}</b>.<br><br>Piliin ang paraan ng pagbabayad:`,
                        icon: 'info',
                        showCancelButton: true,
                        showDenyButton: true,
                        confirmButtonColor: '#3182ce',
                        denyButtonColor: '#48bb78',
                        cancelButtonColor: '#718096',
                        confirmButtonText: '🚀 Go to Top-Up Panel',
                        denyButtonText: '💵 Pay Manually (Cash)',
                        cancelButtonText: 'Close'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            this.switchTab('wallet', document.getElementById('walletTabBtn'));
                        } else if (result.isDenied) {
                            // SAKTO SA INYONG INSTRUCTION:
                            // Dadagdag lang sa credit ng provider. HINDI MUNA ibibigay sa admin wallet/earnings!
                            this.updateProviderCredit(targetJob.providerUsername, platformCut);

                            inquiries[index].status = 'completed';
                            inquiries[index].paymentMethod = 'cash';
                            this.setData('inquiries', inquiries);

                            Swal.fire({
                                title: 'Manual Cash Settled',
                                icon: 'success'
                            });
                            this.refreshSystemLayout();
                        }
                    });
                    return;
                }
            }

            inquiries[index].status = newStatus;
            this.setData('inquiries', inquiries);
            this.refreshSystemLayout();
        }
    },

    refreshSystemLayout: function() {
        this.updateWalletUI();
        this.renderInquiries();
        this.renderOngoingAndHistory();
        if (this.state.currentUser && this.state.currentUser.role === 'admin') {
            this.renderAdminMetrics();
        }
    },

    renderOngoingAndHistory: function() {
        const ongoingContainer = document.getElementById('ongoingList');
        const historyContainer = document.getElementById('historyList');
        if (!historyContainer) return;
        
        const inquiries = this.getData('inquiries');
        const user = this.state.currentUser;

        if (ongoingContainer) ongoingContainer.innerHTML = '';
        historyContainer.innerHTML = '';

        const ongoingJobs = inquiries.filter(i => i.status === 'ongoing' && (i.providerUsername === user.username || i.senderUsername === user.username));
        const waitingPaymentJobs = inquiries.filter(i => i.status === 'waiting_payment' && (i.providerUsername === user.username || i.senderUsername === user.username));
        const historyJobs = inquiries.filter(i => (i.status === 'completed' || i.status === 'rejected') && (i.providerUsername === user.username || i.senderUsername === user.username));

        if(ongoingJobs.length === 0 && waitingPaymentJobs.length === 0) {
            if (ongoingContainer) ongoingContainer.innerHTML = '<p style="color:#718096; text-align:center;">No ongoing jobs.</p>';
        } else {
            if (ongoingContainer) {
                ongoingJobs.forEach(j => {
                    const isProvider = user.username === j.providerUsername;
                    ongoingContainer.innerHTML += `
                        <div class="card" style="border-left: 4px solid #4299e1; margin-bottom:10px;">
                            <h4>${j.serviceTitle}</h4>
                            <p style="font-size:0.85rem; color:#4a5568;">Client: ${j.senderName}</p>
                            <p style="font-weight:bold; color:var(--secondary);">Price: ₱${j.price}</p>
                            <div style="margin-top:10px;">
                                ${isProvider ? `
                                    <button onclick="app.updateInquiryStatus('${j.id}', 'waiting_payment')" style="background:#48bb78;">Mark as Complete</button>
                                ` : `
                                    <span style="font-size:0.85rem; color:#4299e1; font-weight:bold;">🔄 In progress...</span>
                                `}
                            </div>
                        </div>
                    `;
                });

                waitingPaymentJobs.forEach(j => {
                    const isSender = user.username === j.senderUsername;
                    if (isSender) {
                        ongoingContainer.innerHTML += `
                            <div class="card" style="border: 2px solid #ecc94b; background: #fffaf0; border-left: 6px solid #ecc94b; margin-bottom:10px;">
                                <h4 style="color:#b7791f; margin-top:0;">⚠️ Payment Required</h4>
                                <p style="font-size:0.9rem; margin:5px 0;">Tapos na ang trabaho sa <b>${j.serviceTitle}</b> ni <b>${j.providerName}</b>. Kailangan na itong bayaran.</p>
                                <p style="font-weight:bold; color:var(--secondary); margin-bottom:10px;">Billing Amount: ₱${j.price}</p>
                                <button onclick="app.updateInquiryStatus('${j.id}', 'process_payment_execution')" style="background:#ecc94b; color:#2d3748; font-weight:bold; width:100%; max-width:150px;">💵 Pay Now</button>
                            </div>
                        `;
                    } else {
                        ongoingContainer.innerHTML += `
                            <div class="card" style="border-left: 4px solid #ecc94b; opacity:0.8; margin-bottom:10px;">
                                <h4>${j.serviceTitle}</h4>
                                <span style="font-size:0.8rem; background:#feebc8; color:#c05621; padding:2px 6px; border-radius:4px; font-weight:bold;">WAITING CLIENT PAYMENT</span>
                                <p style="font-size:0.85rem; color:#4a5568; margin-top:5px;">Awtomatikong mag-s-sync ang billing kapag pinili ng kliyente ang payment route.</p>
                            </div>
                        `;
                    }
                });
            }
        }

        if(historyJobs.length === 0) {
            historyContainer.innerHTML = '<p style="color:#718096; text-align:center;">No project history.</p>';
        } else {
            historyJobs.forEach(h => {
                const statusColor = h.status === 'completed' ? '#48bb78' : 'var(--danger)';
                const isSender = user.username === h.senderUsername;
                const methodBadge = h.paymentMethod === 'cash' ? '<span style="background:#48bb78; color:white; font-size:0.7rem; padding:1px 5px; border-radius:3px; margin-left:5px;">CASH</span>' : '<span style="background:#3182ce; color:white; font-size:0.7rem; padding:1px 5px; border-radius:3px; margin-left:5px;">WALLET</span>';
                
                let rateButtonHtml = '';
                if(isSender && h.status === 'completed' && !h.rated) {
                    rateButtonHtml = `<button onclick="app.openRatingModal('${h.id}', '${h.providerName}', '${h.providerUsername}')" style="background:#ecc94b; color:#2d3748; margin-top:10px;">Leave a Rating</button>`;
                } else if (h.rated) {
                    rateButtonHtml = `<p style="color:#ecc94b; font-weight:bold; font-size:0.85rem; margin-top:10px;">✓ Rated</p>`;
                }

                historyContainer.innerHTML += `
                    <div class="card" style="border-left: 4px solid ${statusColor}; margin-bottom:10px;">
                        <div style="display:flex; justify-content:space-between;">
                            <h4>${h.serviceTitle} ${h.status === 'completed' ? methodBadge : ''}</h4>
                            <strong style="color:${statusColor}">${h.status.toUpperCase()}</strong>
                        </div>
                        <p style="font-weight:bold; margin:5px 0;">Total Cost: ₱${h.price}</p>
                        ${rateButtonHtml}
                    </div>
                `;
            });
        }
    },

    openRatingModal: function(inquiryId, providerName, providerUsername) {
        this.state.activeInquiryIdForRating = inquiryId;
        this.state.activeProviderUserForRating = providerUsername;
        
        document.getElementById('ratingProviderName').innerText = providerName;
        this.setRating(0);
        document.getElementById('ratingModal').style.display = 'block';
    },

    setRating: function(stars) {
        this.state.currentSelectedRating = stars;
        const starSpans = document.querySelectorAll('#starContainer .star-input');
        
        starSpans.forEach((span, index) => {
            span.style.color = (index < stars) ? '#ecc94b' : '#cbd5e0';
        });
    },

    submitRating: function() {
        const stars = this.state.currentSelectedRating;
        if(stars === 0) return;

        let ratings = this.getData('ratings');
        let inquiries = this.getData('inquiries');

        const inqIndex = inquiries.findIndex(i => i.id === this.state.activeInquiryIdForRating);
        
        if(inqIndex !== -1) {
            inquiries[inqIndex].rated = true;
            this.setData('inquiries', inquiries);

            const newRatingNode = {
                id: 'rate_' + Date.now(),
                inquiryId: this.state.activeInquiryIdForRating,
                providerUsername: this.state.activeProviderUserForRating,
                senderUsername: this.state.currentUser.username,
                stars: stars
            };
            ratings.push(newRatingNode);
            this.setData('ratings', ratings);

            document.getElementById('ratingModal').style.display = 'none';
            Swal.fire('Success', 'Rating submitted.', 'success');
            
            this.renderOngoingAndHistory();
            this.renderServices();
        }
    },

    renderAdminMetrics: function() {
        const users = this.getData('users');
        const posts = this.getData('posts');
        const services = this.getData('services');
        const inquiries = this.getData('inquiries');
        const topups = this.getData('topup_requests');

        if(document.getElementById('countUsers')) document.getElementById('countUsers').innerText = users.length;
        if(document.getElementById('countPosts')) document.getElementById('countPosts').innerText = posts.length;
        if(document.getElementById('countServices')) document.getElementById('countServices').innerText = services.length;

        // Website Earnings ay nakatali lang sa kung magkano talaga ang laman ng Admin Wallet ngayon
        const adminWalletActual = this.getWalletBalance('admin');
        if(document.getElementById('websiteRevenue')) document.getElementById('websiteRevenue').innerText = '₱' + adminWalletActual.toFixed(2);

        // Kasaysayan ng transaksyon sa ledger list ng Admin
        const completedJobs = inquiries.filter(i => i.status === 'completed');
        let revenueLedgerHtml = '';

        completedJobs.forEach(job => {
            const totalCost = parseFloat(job.price) || 0;
            const platformCut = totalCost * 0.05;

            if (job.paymentMethod === 'e-wallet') {
                revenueLedgerHtml += `
                    <div style="font-size:0.85rem; border-bottom:1px solid #edf2f7; padding:8px 0;">
                        <div style="display:flex; justify-content:space-between;">
                            <span>${job.serviceTitle} <b style="color:#3182ce;">[WALLET - PAID]</b></span>
                            <span style="color:#2b6cb0; font-weight:bold;">+₱${platformCut.toFixed(2)}</span>
                        </div>
                    </div>
                `;
            } else {
                revenueLedgerHtml += `
                    <div style="font-size:0.85rem; border-bottom:1px solid #edf2f7; padding:8px 0; opacity: 0.7;">
                        <div style="display:flex; justify-content:space-between;">
                            <span>${job.serviceTitle} <b style="color:#e53e3e;">[CASH DEBT]</b></span>
                            <span style="color:#718096; font-style:italic;">Pending till Provider pays</span>
                        </div>
                    </div>
                `;
            }
        });

        if(document.getElementById('adminRevenueStatement')) document.getElementById('adminRevenueStatement').innerHTML = revenueLedgerHtml || '<p style="color:#a0aec0; font-size:0.85rem;">No revenue logs yet.</p>';

        const pendingTopups = topups.filter(t => t.status === 'pending');
        let topupLedgerHtml = '<h4>Pending Wallet Load Requests</h4>';

        if(pendingTopups.length === 0) {
            topupLedgerHtml += '<p style="color:#a0aec0; font-size:0.85rem; font-style:italic;">No pending requests.</p>';
        } else {
            pendingTopups.forEach(t => {
                topupLedgerHtml += `
                    <div style="background:#fffaf0; border:1px solid #feebc8; border-radius:6px; padding:10px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong>${t.name} (@${t.username})</strong><br>
                            <span style="color:var(--secondary); font-weight:bold;">₱${parseFloat(t.amount).toFixed(2)}</span>
                        </div>
                        <div style="display:flex; gap:5px;">
                            <button onclick="app.adminProcessTopUp('${t.id}', 'approved')" style="background:#48bb78; color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer;">Approve</button>
                            <button onclick="app.adminProcessTopUp('${t.id}', 'rejected')" style="background:#e53e3e; color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer;">Reject</button>
                        </div>
                    </div>
                `;
            });
        }
        
        let topupBoxWrapper = document.getElementById('adminTopUpVerificationWrapper');
        if (!topupBoxWrapper) {
            const adminTab = document.getElementById('adminTab');
            if (adminTab) {
                topupBoxWrapper = document.createElement('div');
                topupBoxWrapper.id = 'adminTopUpVerificationWrapper';
                topupBoxWrapper.className = 'card';
                topupBoxWrapper.style.marginTop = '20px';
                adminTab.insertBefore(topupBoxWrapper, adminTab.firstChild);
            }
        }
        if (topupBoxWrapper) topupBoxWrapper.innerHTML = topupLedgerHtml;

        const userListContainer = document.getElementById('adminUserList');
        if(!userListContainer) return;
        userListContainer.innerHTML = '';
        
        users.forEach(u => {
            let banStatusBadge = `<span style="color:#48bb78; font-weight:bold;">[ACTIVE]</span>`;
            let isUserCurrentlyBanned = false;

            if (u.isBanned && u.banUntil) {
                const remains = Math.ceil((new Date(u.banUntil).getTime() - Date.now()) / 60000);
                if (remains > 0) {
                    banStatusBadge = `<span style="color:var(--danger); font-weight:bold;">[BAN: ${remains}m left]</span>`;
                    isUserCurrentlyBanned = true;
                }
            }

            const currentBal = this.getWalletBalance(u.username);
            const currentCredit = this.getProviderCredit(u.username);
            const displayCreditText = u.role === 'provider' ? ` | Credit Debt: <b style="color:#c53030;">₱${currentCredit.toFixed(2)}</b>` : '';

            let actionButtonsHtml = '';
            if (u.role !== 'admin') {
                if (isUserCurrentlyBanned) {
                    actionButtonsHtml = `<button onclick="app.adminLiftBan('${u.username}')" style="background:#48bb78; color:white; font-size:0.7rem; padding:3px 8px;">Lift Ban</button>`;
                } else {
                    actionButtonsHtml = `<button onclick="app.adminBanUserPrompt('${u.username}')" style="background:#ecc94b; color:#2d3748; font-size:0.7rem; padding:3px 8px;">Ban</button>`;
                }
                actionButtonsHtml += ` <button onclick="app.adminDeleteUser('${u.username}')" style="background:var(--danger); font-size:0.7rem; padding:3px 8px;">Kick</button>`;
            }

            userListContainer.innerHTML += `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 5px; border-bottom:1px solid #f7fafc; font-size:0.85rem;">
                    <div>
                        <strong>${u.name}</strong> ${banStatusBadge}<br>
                        <small style="color:#4a5568;">
                            User: <b>${u.username}</b> | Balance: <b style="color:var(--secondary);">₱${currentBal.toFixed(2)}</b> ${displayCreditText}
                        </small>
                    </div>
                    <div style="display:flex; gap:5px;">
                        ${actionButtonsHtml}
                    </div>
                </div>
            `;
        });
    },

    // Ginawang simple ang Top Up. Purely loading lang ito ng requested funds nang hindi kinakaltasan ang utang, 
    // para may sapat na balance ang provider na ipambayad gamit ang "Pay Debt" option sa wallet panel niya.
    adminProcessTopUp: function(requestId, decision) {
        let requests = this.getData('topup_requests');
        const rIndex = requests.findIndex(r => r.id === requestId);

        if(rIndex !== -1) {
            const targetReq = requests[rIndex];
            
            if(decision === 'approved') {
                let loadAmount = targetReq.amount;
                this.updateWalletBalance(targetReq.username, loadAmount);
                requests[rIndex].status = 'approved';
                Swal.fire('Approved', `Ang halagang ₱${parseFloat(loadAmount).toFixed(2)} ay pumasok na sa wallet.`, 'success');
            } else {
                requests[rIndex].status = 'rejected';
                Swal.fire('Rejected', 'Top-up denied.', 'info');
            }

            this.setData('topup_requests', requests);
            this.renderAdminMetrics();
        }
    },

    adminBanUserPrompt: function(username) {
        Swal.fire({
            title: `Ban ${username}`,
            text: 'Ban duration in minutes:',
            input: 'number',
            inputAttributes: { min: 1, step: 1 },
            inputValue: 5,
            showCancelButton: true,
            confirmButtonColor: '#ecc94b',
            confirmButtonText: 'Apply Ban',
            inputValidator: (value) => {
                if (!value || parseInt(value) <= 0) {
                    return 'Enter valid minutes!';
                }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                let users = this.getData('users');
                const idx = users.findIndex(u => u.username === username);

                if (idx !== -1) {
                    const minutes = parseInt(result.value);
                    const expiryDate = new Date(Date.now() + minutes * 60000);

                    users[idx].isBanned = true;
                    users[idx].banUntil = expiryDate.toISOString();
                    
                    this.setData('users', users);
                    Swal.fire('Suspended', 'User banned.', 'success');
                    this.renderAdminMetrics();
                }
            }
        });
    },

    

    adminLiftBan: function(username) {
        Swal.fire({
            title: 'Lift Ban?',
            text: `Unban ${username}?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#48bb78',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {
                let users = this.getData('users');
                const idx = users.findIndex(u => u.username === username);

                if (idx !== -1) {
                    users[idx].isBanned = false;
                    users[idx].banUntil = null;

                    this.setData('users', users);
                    Swal.fire('Ban Lifted', 'Restriction removed.', 'success');
                    this.renderAdminMetrics();
                }
            }
        });
    },

    adminDeleteUser: function(username) {
        Swal.fire({
            title: 'Are you sure?',
            text: `Remove ${username}?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: 'var(--danger)',
            confirmButtonText: 'Remove'
        }).then((result) => {
            if (result.isConfirmed) {
                let users = this.getData('users');
                users = users.filter(u => u.username !== username);
                this.setData('users', users);
                Swal.fire('Removed!', 'User deleted.', 'success');
                this.renderAdminMetrics();
            }
        });
    }
};

window.addEventListener('DOMContentLoaded', () => {
    app.init();
});