const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = 3000;
const DATA_FILE = './database.json';

app.use(cors());
app.use(express.json());

// Load data from JSON file
let data = { users: [], posts: [], services: [], inquiries: [], ratings: [] };
if (fs.existsSync(DATA_FILE)) {
    data = JSON.parse(fs.readFileSync(DATA_FILE));
}

// Helper to save data
const saveData = () => fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));

// API Routes
app.get('/api/data', (req, res) => res.json(data));

app.post('/api/save', (req, res) => {
    data = req.body;
    saveData();
    res.json({ status: "success" });
});

// Start Server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`To access on other devices, use your IP address.`);
});