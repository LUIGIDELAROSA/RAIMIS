/**
 * =====================================================
 * RAIMIS - BACKEND SERVER (OPTIMIZED)
 * =====================================================
 * Target: Computer Engineering Kiosk System
 * Database: PostgreSQL (raimis_db)
 * Year: 2026
 * DESCRIPTION:
 * Central server for handling room reservations, RFID verification,
 * admin approvals, and real-time analytics for the RAIMIS kiosk.
 */

const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");
const path = require("path");

const app = express();
const PORT = 3000;
const IP_ADDRESS = '192.168.1.12';

// =====================================================
// 1. MIDDLEWARES & CONFIGURATION
// =====================================================
app.use(cors());
app.use(express.json());
app.use(express.static('public')); // Serves frontend files from the 'public' folder

/** 
 * Database connection configuration (node-postgres)
 */
const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "raimis_db",
    password: "luigi",
    port: 5432
});

pool.connect()
    .then(() => console.log("✅ RAIMIS Database: Connected successfully"))
    .catch(err => console.error("❌ Connection Error:", err));

// =====================================================
// 2. RFID DATA (IN-MEMORY STORAGE)
// =====================================================
/** Registered RFID UIDs and their corresponding class sections */
const rfidDatabase = {
    "0006585813": "BSCpE 1-1",
    "0004768226": "BSCpE 1-2"
};

// =====================================================
// 3. RFID API ENDPOINTS
// =====================================================

/** Verifies if the scanned RFID UID exists in the database */
app.post("/api/verify-rfid", (req, res) => {
    const { uid } = req.body;
    const section = rfidDatabase[uid];

    if (section) {
        res.json({ success: true, section });
    } else {
        res.status(401).json({ success: false, message: "RFID Card: Not registered." });
    }
});

// =====================================================
// 4. KIOSK API ENDPOINTS (Public Access)
// =====================================================

/** Fetches all reservations to update room availability on the map */
app.get("/api/reservations", async(req, res) => {
    try {
        const query = `
            SELECT id, room, section, 
                   TO_CHAR(date, 'YYYY-MM-DD') AS date, 
                   TO_CHAR(start_time, 'HH24:MI') AS start_time, 
                   TO_CHAR(end_time, 'HH24:MI') AS end_time, 
                   purpose, status 
            FROM reservations 
            ORDER BY date ASC, start_time ASC`;
        const result = await pool.query(query);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: "Failed to fetch reservations." });
    }
});

/** Creates a new reservation request (Defaults to PENDING) */
app.post("/api/reserve", async(req, res) => {
    const { room, section, date, start_time, end_time, purpose } = req.body;
    try {
        const query = `
            INSERT INTO reservations (room, section, date, start_time, end_time, purpose, status) 
            VALUES ($1, $2, $3, $4, $5, $6, 'PENDING') 
            RETURNING *`;
        const values = [room, section, date, start_time, end_time, purpose];
        const result = await pool.query(query, values);
        res.status(200).json({ success: true, data: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: "Booking failed." });
    }
});

/** Marks a receipt as claimed once printed at the kiosk */
app.patch('/api/reservations/:id/claim', async(req, res) => {
    const { id } = req.params;
    try {
        const queryText = 'UPDATE reservations SET receipt_claimed = true WHERE id = $1 RETURNING *';
        const result = await pool.query(queryText, [id]);

        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, message: "Reservation record not found." });
        }

        console.log(`Reservation ${id}: Marked as claimed.`);
        res.status(200).json({ success: true, message: "Receipt: Marked as claimed successfully!" });
    } catch (err) {
        console.error("Database Error:", err);
        res.status(500).json({ success: false, error: "Database update error occurred." });
    }
});

// =====================================================
// 5. ADMIN API ENDPOINTS (Management Tools)
// =====================================================

/** Retrieves all PENDING requests for the Admin Dashboard */
app.get("/api/pending-reservations", async(req, res) => {
    try {
        const query = `
            SELECT id, room, section, TO_CHAR(date, 'YYYY-MM-DD') AS date, 
                   start_time, end_time, purpose, status 
            FROM reservations 
            WHERE status = 'PENDING' 
            ORDER BY id DESC`;
        const result = await pool.query(query);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/** Generic status update (Approve or Reject) */
app.post("/api/update-status", async(req, res) => {
    const { id, status } = req.body;
    try {
        const query = "UPDATE reservations SET status = $1 WHERE id = $2 RETURNING *";
        const result = await pool.query(query, [status, id]);
        if (result.rowCount === 0) return res.status(404).json({ error: "Record: Not found" });
        res.json({ success: true, status: status });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/** Approves a reservation with an expiration check */
app.put('/api/reservations/approve/:id', async(req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query('SELECT date, "end" FROM reservations WHERE id = $1', [id]);
        if (result.rows.length === 0) return res.status(404).send("Not found");

        const dbDate = result.rows[0].date.toISOString().split('T')[0];
        const dbEnd = result.rows[0].end;

        const expirationTime = new Date(`${dbDate} ${dbEnd}`);
        const currentTime = new Date();

        // Check if the time slot has already passed
        if (currentTime > expirationTime) {
            await pool.query("UPDATE reservations SET status = 'EXPIRED' WHERE id = $1", [id]);
            return res.status(400).json({ error: "Cannot approve. This time slot has already expired." });
        }

        await pool.query("UPDATE reservations SET status = 'APPROVED' WHERE id = $1", [id]);
        res.json({ message: "Success: Reservation approved!" });
    } catch (err) {
        console.error(err);
        res.status(500).send("Server Error");
    }
});

/** Retrieves full history of processed requests (APPROVED) */
app.get('/api/reservation-history', async(req, res) => {
    try {
        const query = `
            SELECT id, room, section, 
                   TO_CHAR(date, 'YYYY-MM-DD') AS date, 
                   start_time, end_time, purpose, status 
            FROM reservations 
            WHERE status IN ('APPROVED') 
            ORDER BY id DESC`;
        const result = await pool.query(query);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: "History retrieval failed." });
    }
});

// =====================================================
// 6. ANALYTICS & SYSTEM TOOLS
// =====================================================

/** Retrieves statistical data for dashboard charts */
app.get('/api/analytics/stats', async(req, res) => {
    try {
        // 1. Top Room (Lahat ng APPROVED reservations)
        const topRoomRes = await pool.query(`
            SELECT room, COUNT(*) AS usage_count 
            FROM reservations 
            WHERE status = 'APPROVED' AND room != 'COURT'
            GROUP BY room ORDER BY usage_count DESC LIMIT 1
        `);

        // 2. Today's Count (Bilang ng APPROVED reservations NGAYONG ARAW lang)
        const todayRes = await pool.query(`
            SELECT COUNT(*) AS count 
            FROM reservations 
            WHERE date = CURRENT_DATE AND status = 'APPROVED' AND room != 'COURT'
        `);

        // 3. Room Stats (Para sa Bar Chart - Room Demand)
        const roomStatsRes = await pool.query(`
            SELECT room, COUNT(*) AS usage_count 
            FROM reservations 
            WHERE status = 'APPROVED' AND room != 'COURT' 
            GROUP BY room
        `);

        // 4. 7-Day Trend (Para sa Line Chart)
        const trendRes = await pool.query(`
            SELECT TO_CHAR(date, 'Mon DD') AS day, COUNT(*) AS count 
            FROM reservations 
            WHERE status = 'APPROVED' AND room != 'COURT'
            AND date > CURRENT_DATE - INTERVAL '7 days'
            GROUP BY date ORDER BY date ASC
        `);

        // Query para makuha ang pinaka-busy na start_time
        const peakHourRes = await pool.query(`
            SELECT start_time, COUNT(*) as usage_count
            FROM reservations
            WHERE status = 'APPROVED' AND room != 'COURT'
            GROUP BY start_time
            ORDER BY usage_count DESC
            LIMIT 1
        `);

        // I-format ang result (halimbawa: mula "08:00:00" gagawing "08:00 AM")
        const rawTime = peakHourRes.rows[0] ? peakHourRes.rows[0].start_time : null;
        let peakTimeDisplay = "---";

        if (rawTime) {
            // Simple formatting para sa display
            const [h, m] = rawTime.split(':');
            const ampm = h >= 12 ? 'PM' : 'AM';
            const hour = h % 12 || 12;
            peakTimeDisplay = `${hour}:${m} ${ampm}`;
        }

        // I-send sa JSON
        res.json({
            topRoom: topRoomRes.rows[0] || { room: "None", usage_count: 0 },
            peakHour: peakTimeDisplay, // Plain string na ito: "8:00 AM"
            todayCount: parseInt(todayRes.rows[0].count) || 0,
            trend: trendRes.rows,
            roomStats: roomStatsRes.rows
        });

    } catch (err) {
        console.error("Database Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

/** Deletes old records that are past the current date */
app.delete("/api/cleanup", async(req, res) => {
    try {
        const today = new Date().toISOString().split('T')[0];
        const result = await pool.query("DELETE FROM reservations WHERE date < $1", [today]);
        res.json({ success: true, deletedCount: result.rowCount });
    } catch (err) {
        res.status(500).json({ error: "Cleanup failed." });
    }
});

app.patch('/api/reservations/:id/claim', async(req, res) => {
    const { id } = req.params;
    // Example SQL: UPDATE reservations SET receipt_claimed = true WHERE id = ?
    // Then return res.sendStatus(200);
});
// =====================================================
// 7. SERVER INITIALIZATION
// =====================================================
app.listen(PORT, '0.0.0.0', () => {
    console.log(`
    =============================================
    🚀 RAIMIS SERVER: OPERATIONAL
    🏠 Local:     http://localhost:${PORT}
    🌐 Network:   http://${IP_ADDRESS}:${PORT}
    =============================================
    `);
});