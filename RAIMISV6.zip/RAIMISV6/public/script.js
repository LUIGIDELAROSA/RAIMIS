/**
 * =====================================================
 * RAIMIS - KIOSK JAVASCRIPT
 * This script runs the Kiosk display. Its job is to 
 * show the rooms on the screen and update their status 
 * (Available or Occupied) every few seconds.
 * =====================================================
 */

// A simple list (Dictionary) of how many students can fit in each room.
const roomCapacities = {
    "101": 45,
    "102": 40,
    "103": 35,
    "106": 35,
    "107": 35,
    "COURT": 200,
    "202": 40,
    "203": 40,
    "205": 30,
    "207": 30,
    "208": 45,
    "209": 45,
    "210": 45,
    "212": 45,
    "213": 45,
    "301": 50,
    "302": 50,
    "303": 45,
    "304": 45,
    "305": 40,
    "307": 40,
    "308": 40,
    "309": 40,
    "310": 40,
    "401": 35,
    "402": 35,
    "403": 40,
    "404": 40,
    "405": 50,
    "406": 40
};

// Organizing the rooms by which Floor they are on.
const rooms = {
    "1st": ["101", "102", "103", "106", "107", "COURT"],
    "2nd": ["202", "203", "205", "207", "208", "209", "210", "212", "213"],
    "3rd": ["301", "302", "303", "304", "305", "307", "308", "309", "310"],
    "4th": ["401", "402", "403", "404", "405", "406"]
};

/**
 * The Start Function:
 * This runs as soon as the Kiosk screen turns on.
 */
function init() {
    renderFloors(); // Draw the rooms on the screen
    updateClock(); // Show the current time
    setInterval(updateClock, 1000); // Refresh the clock every 1 second
    setInterval(updateAllRoomStatuses, 3000); // Ask the server for room updates every 3 seconds
}

// -----------------------------------------------------
// ROOM DASHBOARD RENDERING
// This part actually creates the "Boxes" you see on the screen.
// -----------------------------------------------------
function renderFloors() {
    const floorsDiv = document.getElementById("floors");
    floorsDiv.innerHTML = ""; // Clear the screen first

    // Loop through each floor (1st, 2nd, etc.)
    for (let floor in rooms) {
        let floorHTML = `
            <div class="floor-section">
                <div class="floor-title">${floor} Floor</div>
                <div class="rooms-container">`;

        // Loop through each room on that specific floor
        rooms[floor].forEach(roomNo => {
            const cap = roomCapacities[roomNo] || 0; // Get the capacity number

            // Create the HTML for the Room Box
            floorHTML += `
                <div class="room-box available" id="room-${roomNo}" onclick="openRoom('${roomNo}')" data-room="${roomNo}">
                    <div class="room-number">${roomNo === "COURT" ? "COURT" : 'Room ' + roomNo}</div>
                    
                    <div id="status-${roomNo}" class="room-info">AVAILABLE</div>
                    
                    <div id="details-${roomNo}" class="room-details" style="font-size: 10px; margin-top: 5px; font-weight: bold; color: #1e3a8a;"></div>
                    
                    <div class="room-capacity">👤 Cap: ${cap}</div>
                </div>`;
        });

        floorHTML += `</div></div>`;
        floorsDiv.innerHTML += floorHTML; // Add the finished floor to the screen
    }

    // Immediately check the server to see which rooms are currently in use
    updateAllRoomStatuses();
}

/**
 * updateAllRoomStatuses:
 * This is the most important function for the Kiosk.
 * It constantly checks: "What is happening in this room right now?"
 */
async function updateAllRoomStatuses() {
    const allRoomNumbers = Object.values(rooms).flat();
    const now = new Date();
    const currentTimeStr = now.toTimeString().split(' ')[0]; // "HH:MM:SS"
    const nowVal = now.getHours() * 60 + now.getMinutes();

    // 1. Isang beses lang i-fetch ang maintenance para sa lahat
    let lockedRooms = [];
    try {
        const maintRes = await fetch('/api/maintenance/status');
        lockedRooms = await maintRes.json();
    } catch (err) { console.error("Maint error:", err); }

    for (const roomNo of allRoomNumbers) {
        try {
            const statusEl = document.getElementById(`status-${roomNo}`);
            const detailsEl = document.getElementById(`details-${roomNo}`);
            const roomBox = document.getElementById(`room-${roomNo}`);
            if (!statusEl || !roomBox) continue;

            roomBox.classList.remove('available', 'occupied', 'incoming', 'maintenance');

            // CHECK MAINTENANCE (Priority 1)
            const isMaint = lockedRooms.find(r => r.room_id === roomNo);
            if (isMaint) {
                roomBox.classList.add('maintenance');
                statusEl.innerText = "MAINTENANCE";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `<div class="status-subtext">${isMaint.reason}</div>`;
                continue;
            }

            // FETCH DATA
            const [semRes, reserveRes] = await Promise.all([
                fetch(`/api/kiosk/upcoming-semester/${roomNo}`),
                fetch(`http://192.168.1.2:3000/api/approved-reservations/${roomNo}`) // Siguraduhin na kasama rito ang Pending kung gusto mo makita
            ]);

            const semSchedules = await semRes.json();
            const reservations = await reserveRes.json();

            // NORMALIZATION & SORTING (Importante ang sort para makuha ang pinakamalapit na schedule)
            const allActivities = [
                ...semSchedules.map(s => ({...s, type: 'CLASS' })),
                ...reservations.map(r => ({
                    ...r,
                    type: 'RESERVATION',
                    course_section: r.section || 'RESERVATION',
                    professor: r.professor || 'N/A',
                    start_time: r.start_time,
                    end_time: r.end_time,
                    is_cancelled: false // I-assume na false kung approved na ito
                }))
            ].sort((a, b) => a.start_time.localeCompare(b.start_time)); // I-sort mula umaga hanggang gabi

            // 3. CHECK ONGOING
            const ongoing = allActivities.find(s =>
                currentTimeStr >= s.start_time &&
                currentTimeStr <= s.end_time &&
                !s.is_cancelled
            );

            // 4. CHECK UPCOMING (Dapat ay para sa araw na ito lang)
            const nextClass = allActivities.find(s => {
                if (currentTimeStr < s.start_time && !s.is_cancelled) {
                    const [sH, sM] = s.start_time.split(':').map(Number);
                    const startVal = sH * 60 + sM;
                    const diff = startVal - nowVal;
                    // Ipakita lang kung loob ng 3 hours (180 mins) at hindi pa nakalipas
                    return diff > 0 && diff <= 180;
                }
                return false;
            });

            // 5. RENDER LOGIC
            if (ongoing) {
                roomBox.classList.add('occupied');
                statusEl.innerText = "OCCUPIED";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `
                    <div class="course-tag">${ongoing.course_section}</div>
                    <div class="subject-tag">${ongoing.subject}</div>
                    <div class="prof-tag">Prof. ${ongoing.professor}</div>
                    <div class="status-subtext">ENDS: ${formatTo12Hour(ongoing.end_time)}</div>
                `;
            } else if (nextClass) {
                // Dito mo pwedeng i-check kung "Pending" ang reservation
                const isPending = nextClass.status === 'Pending';
                roomBox.classList.add('incoming');
                statusEl.innerText = isPending ? "PENDING" : "UPCOMING";
                detailsEl.style.display = "block";
                detailsEl.innerHTML = `
                    <div class="course-tag">${nextClass.course_section}</div>
                    <div class="subject-tag">${nextClass.subject}</div>
                    <div class="prof-tag">Prof. ${nextClass.professor}</div>
                    <div class="status-subtext">STARTS: ${formatTo12Hour(nextClass.start_time)}</div>
                `;
            } else {
                roomBox.classList.add('available');
                statusEl.innerText = "AVAILABLE";
                detailsEl.innerHTML = ""; // Linisin ang lumang text
                detailsEl.style.display = "none";
            }
        } catch (err) {
            console.error(`Error:`, err);
        }
    }
}

/**
 * checkMaintenanceStatus:
 * This is a secondary helper that specifically double-checks 
 * the maintenance status every 5 seconds.
 */
async function checkMaintenanceStatus() {
    try {
        const res = await fetch('/api/maintenance/status');
        const lockedRooms = await res.json();

        // Clear the maintenance color from all rooms first
        document.querySelectorAll('.room-box').forEach(box => box.classList.remove('maintenance'));

        // Put the Gray color back on only the rooms that are actually locked
        lockedRooms.forEach(data => {
            const roomBox = document.getElementById(`room-${data.room_id}`);
            if (roomBox) {
                roomBox.classList.add('maintenance');
                const statusEl = document.getElementById(`status-${data.room_id}`);
                if (statusEl) statusEl.innerText = "MAINTENANCE";

                const detailsEl = document.getElementById(`details-${data.room_id}`);
                if (detailsEl) detailsEl.innerHTML = `<div class="status-subtext">${data.reason}</div>`;
            }
        });
    } catch (err) {
        console.error("Maintenance check error:", err);
    }
}

// Start the timer: Check for "Broken" rooms every 5 seconds
setInterval(checkMaintenanceStatus, 5000);

/**
 * =====================================================
 * KIOSK MODAL & RFID SYSTEM
 * =====================================================
 */

// Variables to keep track of the RFID scanner and the popup window
let rfidBuffer = "";
let scanningTimer = null;
let currentRFIDUser = null;
let currentUserRole = "";

/**
 * openRoom:
 * This opens the popup (Modal) when you click a room box.
 */
function openRoom(roomNo) {
    const modal = document.getElementById("modal");
    const modalBody = document.querySelector(".kiosk-modal-body");
    const todayString = new Date().toISOString().split('T')[0];
    const roomBox = document.getElementById(`room-${roomNo}`);

    if (roomBox && roomBox.classList.contains('maintenance')) {
        Swal.fire({
            icon: 'error',
            title: 'Room Unavailable',
            text: 'This room is currently under maintenance.',
            confirmButtonColor: '#1e3a8a'
        });
        return;
    }

    isModalOpen = true;
    selectedRoomForReserve = roomNo;
    rfidBuffer = "";

    modal.style.display = "flex";
    document.getElementById("roomTitle").innerText = roomNo === "COURT" ? "Covered Court" : "Room " + roomNo;

    // BAGONG FORM LAYOUT
    modalBody.innerHTML = `
        <div style="display: flex; gap: 20px; min-height: 480px; width: 850px; align-items: stretch; margin: 0 auto;">
            
            <div style="flex: 1.5; display: flex; flex-direction: column; gap: 12px;">
                <div id="rfidStatus" style="background: #fef08a; color: #854d0e; padding: 10px; text-align: center; font-weight: 800; border-radius: 8px; font-size: 13px; border: 1px solid #fde047;">
                    🔐 TAP RFID TO START
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 5px;">
                    
                    <div id="pinBox" style="grid-column: span 2; display: none;">
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a; display: block; text-align: center; margin-bottom: 8px;"> 🔑 ENTER SECURITY PIN</label>
                            <input type="password" id="formPin" maxlength="4" readonly placeholder="• • • •" 
                            style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px; font-size: 24px; letter-spacing: 12px; text-align: center; font-weight: bold; background: white; margin-bottom: 12px; color: #1e3a8a;">
                        
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; max-width: 280px; margin: 0 auto;">
                            <button type="button" onclick="pressPinNum('1')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a; active-background: #e2e8f0;">1</button>
                            <button type="button" onclick="pressPinNum('2')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">2</button>
                            <button type="button" onclick="pressPinNum('3')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">3</button>
                            
                            <button type="button" onclick="pressPinNum('4')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">4</button>
                            <button type="button" onclick="pressPinNum('5')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">5</button>
                            <button type="button" onclick="pressPinNum('6')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">6</button>
                            
                            <button type="button" onclick="pressPinNum('7')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">7</button>
                            <button type="button" onclick="pressPinNum('8')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">8</button>
                            <button type="button" onclick="pressPinNum('9')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">9</button>
                            
                            <button type="button" onclick="clearPin()" style="padding: 15px; font-size: 16px; font-weight: bold; background: #ef4444; color: white; border: none; border-radius: 8px; cursor: pointer;">CLEAR</button>
                            <button type="button" onclick="pressPinNum('0')" style="padding: 15px; font-size: 18px; font-weight: bold; background: white; border: 1.5px solid #cbd5e1; border-radius: 8px; cursor: pointer; color: #1e3a8a;">0</button>
                            <button type="button" onclick="backspacePin()" style="padding: 15px; font-size: 18px; font-weight: bold; background: #475569; color: white; border: none; border-radius: 8px; cursor: pointer;">⌫</button>
                        </div>
                    </div>

                    <div style="grid-column: span 2;">
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">👥 User / Organization</label>
                        <input type="text" id="formIdentifier" placeholder="Waiting for RFID..." disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px; background: #f8fafc; font-weight: bold;">
                    </div>
                    
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📅 Date</label>
                        <input type="date" id="formDate" value="${todayString}" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🎯 Purpose</label>
                        <select id="formPurpose" disabled onchange="handlePurposeChange()" style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                            <option value="CLASS">CLASS</option>
                            <option value="EVENT">EVENT</option>
                            <option value="MEETING">MEETING</option>
                            <option value="EXAM">EXAM</option>
                        </select>
                    </div>

                    <div id="academicBox" style="grid-column: span 2; display: none; gap: 12px;">
                        </div>

                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🕒 Start Time</label>
                        <input type="time" id="formStart" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                    </div>
                    <div>
                        <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">🕒 End Time</label>
                        <input type="time" id="formEnd" disabled style="width: 100%; padding: 10px; border: 1.5px solid #e2e8f0; border-radius: 8px;">
                    </div>
                </div>

                <button id="submitBtn" onclick="submitAdHocReservation()" disabled style="margin-top: auto; background: #94a3b8; color: white; padding: 14px; border: none; border-radius: 8px; font-weight: bold; font-size: 13px; transition: 0.3s;">
                    🔒 LOCKED - TAP RFID
                </button>
            </div>

            <div style="flex: 1.1; background: #f8fafc; padding: 15px; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; flex-direction: column; max-height: 520px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 18px;">📅</span>
                        <h3 style="font-size: 15px; color: #1e3a8a; font-weight: 800; margin: 0;">Existing Schedule</h3>
                    </div>
                    <select id="dayFilter" onchange="renderRoomSchedule('${roomNo}', this.value)" style="font-size: 11px; padding: 4px; border-radius: 6px; border: 1px solid #cbd5e1; outline: none; cursor: pointer; background: white; font-weight: 600; color: #334155;">
                        <option value="today">TODAY</option>
                        <option value="Monday">MONDAY</option>
                        <option value="Tuesday">TUESDAY</option>
                        <option value="Wednesday">WEDNESDAY</option>
                        <option value="Thursday">THURSDAY</option>
                        <option value="Friday">FRIDAY</option>
                        <option value="Saturday">SATURDAY</option>
                    </select>
                </div>
                <div id="modalScheduleList" style="overflow-y: auto; flex-grow: 1; padding-right: 5px;">
                    <p style="text-align:center; font-size:12px; color: #94a3b8; margin-top: 20px;">Loading schedule...</p>
                </div>
            </div>
        </div>`;

    renderRoomSchedule(roomNo);
}



// Tawagin ito mula sa iyong RFID scanner listener event
function unlockFormWithRFID(userData) {
    // 🔥 FIX 1: I-save ang buong userData sa global variable para mabasa ng Submit Button ang .pin at .role mamaya
    currentRFIDUser = userData;
    currentUserRole = userData.role; // 'professor' o 'student'

    // 1. UI Unlock Styling (Gamitin ang pangalan galing DB)
    const statusBox = document.getElementById('rfidStatus');
    if (statusBox) {
        statusBox.innerHTML = `✅ ACCESS GRANTED: ${userData.identifier}`;
        statusBox.style.background = "#dcfce7";
        statusBox.style.color = "#166534";
        statusBox.style.border = "1px solid #4ade80";
    }

    // 2. Enable Standard Inputs
    if (document.getElementById('formDate')) document.getElementById('formDate').disabled = false;
    if (document.getElementById('formPurpose')) document.getElementById('formPurpose').disabled = false;
    if (document.getElementById('formStart')) document.getElementById('formStart').disabled = false;
    if (document.getElementById('formEnd')) document.getElementById('formEnd').disabled = false;

    // 3. Show PIN Input & Auto-fill Identifier
    if (document.getElementById('pinBox')) document.getElementById('pinBox').style.display = "block";
    if (document.getElementById('formIdentifier')) document.getElementById('formIdentifier').value = userData.identifier;

    // 🔥 FIX 2: Siguraduhing malinis ang PIN input/buffer tuwing may bagong tap ng card
    if (typeof clearPin === 'function') {
        clearPin(); // Kung may umiiral kang function na nagrereset ng numpad dots/values
    } else {
        const pinField = document.getElementById('formPin');
        if (pinField) pinField.value = ""; // Kung standard hidden input ang gamit mo
    }

    // 4. Update Submit Button
    const submitBtn = document.getElementById('submitBtn');
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = "💾 CONFIRM & RESERVE ROOM";
        submitBtn.style.background = "#2563eb";
    }

    // 5. Build Dynamic Dropdowns base sa laman ng additional_info sa database
    if (typeof buildDynamicDropdowns === 'function') {
        buildDynamicDropdowns(userData);
    }
}

function buildDynamicDropdowns(userData) {
    const academicBox = document.getElementById('academicBox');
    academicBox.style.display = "grid";

    const tags = userData.additional_info || [];

    if (userData.role === 'professor') {
        academicBox.style.gridTemplateColumns = "1fr 1fr";

        // Gagamit tayo ng Set para hindi mag-duplicate ang mga listahan sa dropdown
        const sectionsSet = new Set();
        const subjectsSet = new Set();

        tags.forEach(tag => {
            // Fallback utility: titingnan kung 'subjects' o 'subject' ang field sa DB
            const section = tag.course_section || tag.section;
            const subject = tag.subjects || tag.subject;

            if (section) sectionsSet.add(section.trim());
            if (subject) subjectsSet.add(subject.trim());
        });

        // I-convert ang Sets pabalik sa HTML Options
        let sectionOpts = '<option value="">Select Section</option>';
        sectionsSet.forEach(sec => {
            sectionOpts += `<option value="${sec}">${sec}</option>`;
        });

        let subjectOpts = '<option value="">Select Subject</option>';
        subjectsSet.forEach(subj => {
            subjectOpts += `<option value="${subj}">${subj}</option>`;
        });

        academicBox.innerHTML = `
            <div>
                <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">👥 Handle Section</label>
                <select id="dynSection" style="width: 100%; padding: 10px; border: 1.5px solid #cbd5e1; border-radius: 8px; background: white; color: #334155; font-weight: 600;">
                    ${sectionOpts}
                </select>
            </div>
            <div>
                <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📖 Subject</label>
                <select id="dynSubject" style="width: 100%; padding: 10px; border: 1.5px solid #cbd5e1; border-radius: 8px; background: white; color: #334155; font-weight: 600;">
                    ${subjectOpts}
                </select>
            </div>
        `;
    } else if (userData.role === 'student') {
        academicBox.style.gridTemplateColumns = "1fr";

        const combinedSet = new Set();

        tags.forEach(tag => {
            const prof = tag.professor_name || tag.professor || "TBA";
            const subj = tag.subjects || tag.subject || "Unknown Subject";

            // I-combine para sa malinis na string option
            combinedSet.add(`${subj.trim()}|${prof.trim()}`);
        });

        let combinedOpts = '<option value="">Select Subject & Professor</option>';
        combinedSet.forEach(item => {
            const [subj, prof] = item.split('|');
            combinedOpts += `<option value="${subj}|${prof}">${subj} (Prof. ${prof})</option>`;
        });

        academicBox.innerHTML = `
            <div>
                <label style="font-size: 11px; font-weight: 800; color: #1e3a8a;">📖 Subject & Assigned Professor</label>
                <select id="dynCombined" style="width: 100%; padding: 10px; border: 1.5px solid #cbd5e1; border-radius: 8px; background: white; color: #334155; font-weight: 600;">
                    ${combinedOpts}
                </select>
            </div>
        `;
    }
}

function handlePurposeChange() {
    const purpose = document.getElementById('formPurpose').value;
    const academicBox = document.getElementById('academicBox');

    // Tignan kung 'student' ang nag-scan (galing sa global variable)
    if (currentUserRole === 'student') {
        if (purpose === 'EVENT' || purpose === 'MEETING') {
            academicBox.style.display = 'none'; // Itago ang dropdown
        } else {
            // Ibalik ang display settings
            academicBox.style.display = 'grid';
            academicBox.style.gridTemplateColumns = '1fr';
        }
    }
}

/**
 * RFID SCANNER LISTENER:
 * This is always "listening" for a card tap. 
 * Most RFID scanners act like a super-fast keyboard that types 
 * a number and hits "Enter."
 */
// Makikinig ang Kiosk sa keyboard/scanner input
document.addEventListener('keydown', function(e) {
    // Siguraduhing bukas ang modal bago basahin ang RFID
    if (!isModalOpen) return;

    // Kapag pumindot ng "Enter", ibig sabihin tapos na mag-scan ang RFID reader
    if (e.key === 'Enter') {
        if (rfidBuffer.length > 3) {
            processKioskRFID(rfidBuffer);
        }
        rfidBuffer = ""; // i-reset agad
        return;
    }

    // Ipunin ang mga numbers galing sa scanner
    if (e.key.length === 1 && !isNaN(e.key)) {
        rfidBuffer += e.key;

        // Auto-clear buffer kung walang sumunod na number within 100ms
        clearTimeout(scanningTimer);
        scanningTimer = setTimeout(() => { rfidBuffer = ""; }, 100);
    }
});

async function processKioskRFID(rfidSerial) {
    try {
        const response = await fetch(`http://192.168.1.2:3000/api/rfid-users/${rfidSerial}`);
        const result = await response.json();

        if (response.ok && result.success) {
            // NAKITA ANG USER SA DATABASE!
            currentRFIDUser = result.data;
            unlockFormWithRFID(currentRFIDUser);
        } else {
            // HINDI REHISTREDO ANG RFID
            Swal.fire({
                icon: 'error',
                title: 'Unregistered Card',
                text: 'This RFID is not registered in the system.',
                confirmButtonColor: '#ef4444'
            });
            const statusBox = document.getElementById('rfidStatus');
            if (statusBox) {
                statusBox.innerHTML = "❌ UNREGISTERED RFID";
                statusBox.style.background = "#fee2e2";
                statusBox.style.color = "#991b1b";
            }
        }
    } catch (error) {
        console.error("Database connection error:", error);
        Swal.fire('Connection Error', 'Hindi maabot ang database server.', 'error');
    }
}

// =====================================================
// CHAPTER 2: SAFE TOUCHSCREEN NUMPAD ENGINES
// =====================================================
// Gagawa tayo ng internal variable para dito nakatago ang TOTOONG numero (e.g. "7122")
let pinBuffer = "";

function updatePinDisplay() {
    const pinInput = document.getElementById('formPin');
    if (!pinInput) return;

    // Kung ang element ay isang standard INPUT field:
    // Gagawin nating "••••" ang display para secured, pero ang totoong data ay nasa memory
    pinInput.value = "•".repeat(pinBuffer.length);

    // KUNG ang element mo naman ay isang DIV o SPAN, i-uncomment ang nasa ibaba:
    // pinInput.textContent = "•".repeat(pinBuffer.length);
}

// Function kapag pinindot ang mga numero (1-0)
function pressPinNum(num) {
    if (pinBuffer.length < 4) {
        pinBuffer += String(num); // Dito naiipon ang totoong numero gaya ng 7122
        updatePinDisplay(); // I-render ang mga tuldok sa screen
    }
}

// Function para burahin lahat (CLEAR)
function clearPin() {
    pinBuffer = "";
    updatePinDisplay();
}

// Function para mag-bura ng huling isang numero (Backspace)
function backspacePin() {
    if (pinBuffer.length > 0) {
        pinBuffer = pinBuffer.slice(0, -1);
        updatePinDisplay();
    }
}

// =====================================================
// CHAPTER 3: UNIFIED VALIDATION & CONFLICT ENGINE
// =====================================================
// Native helper function para siguradong hindi mag-error ang formatting ng oras
function localFormatTo12Hour(timeStr) {
    if (!timeStr) return '';
    const parts = timeStr.split(':');
    let hours = parseInt(parts[0], 10);
    const minutes = parts[1] || '00';
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    return `${String(hours).padStart(2, '0')}:${minutes} ${ampm}`;
}

async function isReservationValid(data, activities) {
    const newStart = data.start_time.substring(0, 5);
    const newEnd = data.end_time.substring(0, 5);

    const now = new Date();
    const currentTime = now.toTimeString().substring(0, 5);
    const todayDate = now.toISOString().split('T')[0];

    // 1. CHECK INVALID TIME RANGE
    if (newEnd <= newStart) {
        await Swal.fire({
            icon: 'error',
            title: 'Invalid Time Range',
            text: 'The End Time must be later than the Start Time.',
            confirmButtonColor: '#ef4444'
        });
        return false;
    }

    // 2. CHECK PAST TIME IF DATE IS TODAY
    if (data.date === todayDate && newStart < currentTime) {
        await Swal.fire({
            icon: 'warning',
            title: 'Time Already Passed',
            text: `You cannot book ${localFormatTo12Hour(newStart)} because the current time is already ${localFormatTo12Hour(currentTime)}.`,
            confirmButtonColor: '#f59e0b'
        });
        return false;
    }

    // 3. CHECK SCHEDULE CONFLICT (FIXED: Dinagdag ang data.date filtering)
    const conflict = activities.find(sched => {
        // Tiyakin na may date record, at i-extract ang date string (YYYY-MM-DD)
        const schedDate = sched.date ? new Date(sched.date).toISOString().split('T')[0] : null;

        return (!sched.is_cancelled &&
            schedDate === data.date && // 🔥 CRITICAL FIX: Dapat pareho sila ng araw para maging conflict!
            newStart < sched.end_time.substring(0, 5) &&
            newEnd > sched.start_time.substring(0, 5)
        );
    });

    if (conflict) {
        await Swal.fire({
            icon: 'warning',
            title: 'Schedule Conflict',
            text: 'This time slot is already occupied.',
            confirmButtonColor: '#f59e0b'
        });
        return false;
    }

    return true;
}

/**
 * Titirisin nito ang submission kapag pinalo ang "CONFIRM & RESERVE ROOM" button.
 */
async function submitAdHocReservation() {
    console.log("Submitting reservation to PostgreSQL database...");

    // 1. RFID CARD CHECK
    if (!currentRFIDUser) {
        return Swal.fire({
            icon: 'warning',
            title: 'RFID Required',
            text: 'Magsagawa muna ng RFID scan bago mag-submit.',
            confirmButtonColor: '#f59e0b'
        });
    }

    // 2. PIN ENGINE VALIDATION (Dito tinitiyak na string type sila pareho)
    const enteredPin = typeof pinBuffer !== 'undefined' ? pinBuffer : "";

    if (!enteredPin || enteredPin.length < 4) {
        return Swal.fire({
            icon: 'warning',
            title: 'Security PIN Required',
            text: 'Ipasok ang iyong 4-digit security PIN gamit ang touchscreen numpad.',
            confirmButtonColor: '#f59e0b'
        });
    }

    // Defensive trimming at formatting para iwas primitive type bugs sa conditional checks
    const cleanEnteredPin = String(enteredPin).trim();
    const cleanExpectedPin = currentRFIDUser.pin ? String(currentRFIDUser.pin).trim() : "";

    if (cleanEnteredPin !== cleanExpectedPin) {
        Swal.fire({
            icon: 'error',
            title: 'Maling PIN',
            text: `Hindi tugma ang security PIN para sa account ni ${currentRFIDUser.identifier || 'User'}.`,
            confirmButtonColor: '#ef4444'
        });
        if (typeof clearPin === 'function') clearPin(); // I-reset ang pin field dots pabalik sa zero
        return;
    }

    // 3. ACCOUNT ROLE PARSING
    let sectionVal = "";
    let subjectVal = "";
    let professorVal = "";

    if (currentRFIDUser.role === 'professor') {
        const dynSec = document.getElementById('dynSection');
        const dynSub = document.getElementById('dynSubject');

        sectionVal = dynSec ? dynSec.value : "";
        subjectVal = dynSub ? dynSub.value : "";
        professorVal = currentRFIDUser.identifier;
    } else if (currentRFIDUser.role === 'student') {
        sectionVal = currentRFIDUser.identifier; // Halimbawa: "DCPET 3-1"

        const dynCombined = document.getElementById('dynCombined');
        if (dynCombined && dynCombined.value) {
            const rawText = dynCombined.value;
            if (rawText.includes('|')) {
                const parts = rawText.split('|');
                subjectVal = parts[0].trim();
                professorVal = parts[1].trim();
            } else {
                subjectVal = rawText;
                professorVal = "TBA";
            }
        }
    }

    // 4. PAYLOAD MAP BUILD
    const dateInput = document.getElementById('formDate');
    const startInput = document.getElementById('formStart');
    const endInput = document.getElementById('formEnd');
    const purposeInput = document.getElementById('formPurpose');

    const reservationData = {
        room: (typeof selectedRoomForReserve !== 'undefined' && selectedRoomForReserve) ? selectedRoomForReserve : "Room 103",
        rfid_tag: currentRFIDUser.rfid_tag || currentRFIDUser.serial || "",
        section: sectionVal,
        subject: subjectVal,
        professor: professorVal,
        date: dateInput ? dateInput.value : "",
        start_time: startInput ? startInput.value : "",
        end_time: endInput ? endInput.value : "",
        purpose: purposeInput ? purposeInput.value : "CLASS"
    };

    if (!reservationData.section || !reservationData.subject || !reservationData.start_time || !reservationData.end_time) {
        return Swal.fire({
            icon: 'error',
            title: 'Incomplete Details',
            text: 'Mangyaring kumpletuhin ang Subject, Oras, at Section bago mag-submit.',
        });
    }

    // 5. SERVER POST TRANSMISSION
    try {
        Swal.showLoading();

        const response = await fetch('http://192.168.1.2:3000/api/reservations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(reservationData)
        });

        const serverResult = await response.json().catch(() => ({}));

        if (response.ok && serverResult.success) {
            Swal.close();

            await Swal.fire({
                icon: 'success',
                title: 'Reservation Saved!',
                text: 'Ang iyong kahilingan ay pumasok na sa database at naghihintay ng approval.',
                timer: 2000,
                showConfirmButton: false
            });

            // Tiyaking burado ang PIN entry strings sa browser cache/memory bago magsara ang transaction
            if (typeof clearPin === 'function') clearPin();

            // Isara ang modal framework view
            const modal = document.getElementById("modal");
            if (modal) modal.style.display = "none";
            isModalOpen = false;

            // 🔥 IPATUPAD ANG INTERFACE TABLE REFRESH:
            if (typeof loadPendingRequests === 'function') {
                loadPendingRequests();
            }

        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Database Entry Denied',
                text: serverResult.message || serverResult.error || 'May schedule conflict sa system sa piniling slot.',
                confirmButtonColor: '#f59e0b'
            });
        }

    } catch (error) {
        console.error("Fatal Post Error:", error);
        Swal.fire({
            icon: 'error',
            title: 'Network Timeout',
            text: 'Hindi maabot ang database server sa port 3000.',
        });
    }
}

// HELPER FUNCTION: Kinukuha ang eksaktong petsa (YYYY-MM-DD) ng piniling araw sa linggong ito
function getTargetDate(selectedDay) {
    if (selectedDay === 'today') return new Date().toISOString().split('T')[0];

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const targetDayIndex = days.indexOf(selectedDay);
    const now = new Date();
    const currentDayIndex = now.getDay();

    // Kunin ang petsa ng piniling araw (kukuwentahin mula sa araw ngayon)
    const diff = targetDayIndex - currentDayIndex;
    const targetDate = new Date(now);
    targetDate.setDate(now.getDate() + diff);

    const year = targetDate.getFullYear();
    const month = String(targetDate.getMonth() + 1).padStart(2, '0');
    const day = String(targetDate.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

/**
 * renderRoomSchedule:
 * This draws the "Existing Schedule" list on the right side of the popup.
 * It helps students avoid booking a room that already has a class.
 */
async function renderRoomSchedule(roomNo, selectedDay = 'today') {
    const scheduleList = document.getElementById("modalScheduleList");
    const nowFull = new Date();
    const nowTime = nowFull.toTimeString().split(' ')[0];

    // I-convert ang napiling araw para sa reservation fetch
    const targetDateStr = getTargetDate(selectedDay);

    try {
        // 1. Ipasa ang selectedDay at targetDate bilang "query parameters" (?day=...)
        const [semRes, reserveRes] = await Promise.all([
            fetch(`/api/kiosk/upcoming-semester/${roomNo}?day=${selectedDay}`),
            fetch(`http://192.168.1.2:3000/api/approved-reservations/${roomNo}?date=${targetDateStr}`)
        ]);

        const semSchedules = await semRes.json();
        const reservations = await reserveRes.json();

        // 2. MERGE & TAG
        const combined = [
            ...semSchedules.map(s => ({...s, type: 'CLASS' })),
            ...reservations.map(r => ({
                ...r,
                type: 'RESERVATION',
                course_section: r.section,
                professor: r.professor || 'N/A'
            }))
        ];

        // 3. FILTER LOGIC
        let upcomingAndOngoing = combined;

        // I-filter lang ang mga "tapos na" na klase KUNG ang tinitignan ay schedule "ngayon"
        if (selectedDay === 'today') {
            upcomingAndOngoing = combined.filter(item => item.end_time > nowTime);
        }

        // 4. SORT
        upcomingAndOngoing.sort((a, b) => a.start_time.localeCompare(b.start_time));

        // 5. EMPTY CHECK
        if (upcomingAndOngoing.length === 0) {
            scheduleList.innerHTML = `<div style="text-align:center; margin-top:40px; color:#94a3b8; font-size:13px;">No scheduled activities for this day.</div>`;
            return;
        }

        // 6. DRAW THE LIST
        scheduleList.innerHTML = upcomingAndOngoing.map(item => {
            let statusColor = "#3b82f6"; // Default Blue for other days
            let statusLabel = item.type === 'RESERVATION' ? "RESERVED" : "SCHEDULED";
            let isCancelled = item.is_cancelled === true;

            if (isCancelled) {
                statusColor = "#94a3b8";
                statusLabel = "CANCELLED";
            } else if (selectedDay === 'today') {
                // Gumagana lang ang "On-Going" at "Upcoming" indicator kung TODAY ang schedule
                if (nowTime >= item.start_time && nowTime <= item.end_time) {
                    statusColor = "#ef4444";
                    statusLabel = "ON-GOING";
                } else {
                    statusColor = "#f59e0b";
                    statusLabel = "UPCOMING";
                }
            }

            return `
            <div style="background: white; padding: 15px; border-radius: 12px; margin-bottom: 12px; border-left: 5px solid ${statusColor}; box-shadow: 0 2px 6px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 4px; ${isCancelled ? 'opacity: 0.8;' : ''}">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="background: ${statusColor}20; color: ${statusColor}; font-size: 10px; font-weight: 900; padding: 4px 8px; border-radius: 5px; text-transform: uppercase;">
                        ${statusLabel}
                    </span>
                    <div style="font-size: 12px; font-weight: 700; color: #475569; display: flex; align-items: center; gap: 4px;">
                        <span>🕒</span>
                        <span>${formatTo12Hour(item.start_time)} - ${formatTo12Hour(item.end_time)}</span>
                    </div>
                </div>
                <div style="font-size: 17px; font-weight: 900; color: ${isCancelled ? '#64748b' : '#0f172a'}; line-height: 1.2; margin-top: 4px;">
                    ${item.subject}
                    ${isCancelled ? '<small style="display:block; font-size:10px; color:#ef4444;">(This session is cancelled)</small>' : ''}
                </div>
                <div style="font-size: 11px; color: #64748b; font-weight: 600; border-top: 1px solid #f1f5f9; padding-top: 8px; margin-top: 4px;">
                    ${item.course_section} <span style="color: #cbd5e1; margin: 0 4px;">|</span> Prof. ${item.professor}
                </div>
            </div>`;
        }).join('');

    } catch (err) {
        console.error(err);
        scheduleList.innerHTML = `<p style="color:red; text-align:center; font-size:12px;">Connection Error.</p>`;
    }
}


/**
 * formatTo12Hour:
 * A simple converter. Changes "13:00" to "1:00 PM".
 */
function formatTo12Hour(time) {
    if (!time) return "";
    let [h, m] = time.split(':');
    let ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return `${h}:${m} ${ampm}`;
}

/**
 * updateClock:
 * Keeps the digital clock on the Kiosk dashboard ticking every second.
 */
function updateClock() {
    const clockEl = document.getElementById("clock");
    if (clockEl) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        clockEl.innerText = new Date().toLocaleString('en-US', options);
    }
}

/**
 * closeModal:
 * Hides the popup and clears the RFID memory so the next student starts fresh.
 */
function closeModal() {
    document.getElementById("modal").style.display = "none";
    isModalOpen = false;
    rfidBuffer = "";
}

window.onload = init;