/**
 * =====================================================
 * RAIMIS - ROOM RESERVATION & AVAILABILITY SYSTEM
 * Final Production Version (2026)
 * =====================================================
 * SYSTEM DESCRIPTION:
 * Manages university room bookings using a kiosk interface. 
 * Features: Real-time DB sync, RFID verification, and status detection.
 */

// =====================================================
// 1. GLOBAL VARIABLES & CONFIGURATION
// =====================================================

let reservations = []; // Holds approved reservation objects
let rfidBuffer = ""; // Temporary storage for RFID keystrokes
let isRfidVerified = false; // Security flag for unlocked state

/** Seating capacity mapping per room */
const roomCapacities = {
    "101": 45,
    "102": 40,
    "103": 35,
    "106": 35,
    "107": 35,
    "COURT": 200,
    "202": 40,
    "203": 40,
    "205": 30,
    "207": 30,
    "208": 45,
    "209": 45,
    "210": 45,
    "212": 45,
    "213": 45,
    "301": 50,
    "302": 50,
    "303": 45,
    "304": 45,
    "305": 40,
    "307": 40,
    "308": 40,
    "309": 40,
    "310": 40,
    "401": 35,
    "402": 35,
    "403": 40,
    "404": 40,
    "405": 50,
    "406": 40
};

// =====================================================
// 2. CORE INITIALIZATION
// =====================================================

async function init() {
    try {
        console.log("🚀 RAIMIS System: Initializing...");

        // Initial setup and rendering
        await loadFromServer();
        renderFloors();
        updateClock();
        updateRoomStatus();
        loadReservationSidebar();
        setupRFIDListener();

        // Intervals for real-time updates
        setInterval(updateClock, 1000); // Refresh clock (1s)
        setInterval(updateRoomStatus, 1000); // Check occupancy (1s) - Adjusted from 0 for stability
        setInterval(loadFromServer, 2000); // Sync DB (2s)

        console.log("✅ RAIMIS System: Ready.");
    } catch (error) {
        console.error("❌ Critical Initialization Error:", error);
    }
}

// =====================================================
// 3. DATA PERSISTENCE (API INTEGRATION)
// =====================================================

/** Fetches and filters APPROVED records from PostgreSQL */
async function loadFromServer() {
    try {
        const response = await fetch('http://192.168.1.12:3000/api/reservations');
        if (!response.ok) throw new Error("Server communication failed");

        const data = await response.json();

        // Data Transformation: Keep only APPROVED and format for UI
        reservations = data
            .filter(res => res.status === 'APPROVED')
            .map(res => {
                const d = new Date(res.date);
                return {
                    room: res.room.toString(),
                    section: res.section,
                    date: d.toISOString().split('T')[0],
                    start: res.start_time.substring(0, 5),
                    end: res.end_time.substring(0, 5),
                    purpose: res.purpose
                };
            });

        updateRoomStatus();
    } catch (err) {
        console.error("Fetch Error:", err);
    }
}

/** Sends a PENDING reservation request to the server */
async function saveReservation(roomNo) {
    const submitBtn = document.getElementById("submitBtn");
    const resData = {
        room: roomNo,
        section: document.getElementById('formSection').value,
        date: document.getElementById('formDate').value,
        start_time: document.getElementById('formStart').value,
        end_time: document.getElementById('formEnd').value,
        purpose: document.getElementById('formPurpose').value,
        status: 'PENDING'
    };

    try {
        submitBtn.disabled = true;
        submitBtn.innerHTML = "⌛ Wait for Approval...";

        const response = await fetch('http://192.168.1.12:3000/api/reserve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(resData)
        });

        if (response.ok) {
            submitBtn.style.background = "#22c55e";
            submitBtn.innerHTML = "✅ Sent Successfully!";

            setTimeout(() => {
                Swal.fire({
                    title: 'Success!',
                    text: 'Request submitted to Admin.',
                    icon: 'success',
                    timer: 1500,
                    showConfirmButton: false
                });
                closeModal();
            }, 2000);
        } else {
            throw new Error("Failed to send");
        }
    } catch (err) {
        console.error("Save Error:", err);
        Swal.fire('Error', 'Hindi maipadala ang request.', 'error');
        submitBtn.disabled = false;
        submitBtn.style.background = "#1e3a8a";
        submitBtn.innerHTML = "✅ CONFIRM RESERVATION";
    }
}

// =====================================================
// 4. RFID SECURITY LOGIC
// =====================================================

/** Global listener for RFID scanner inputs (acting as keyboard) */
function setupRFIDListener() {
    document.addEventListener('keydown', function(event) {
        const modal = document.getElementById('modal');
        if (isRfidVerified || modal.style.display !== 'flex') return;

        if (event.key === 'Enter') {
            event.preventDefault();
            if (rfidBuffer.length > 0) {
                handleRFIDInput(rfidBuffer.trim());
                rfidBuffer = "";
            }
        } else if (event.key.length === 1) {
            rfidBuffer += event.key;
        }
    });
}

/** Validates RFID UID and unlocks the form on success */
async function handleRFIDInput(uid) {
    try {
        const response = await fetch('http://192.168.1.12:3000/api/verify-rfid', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ uid })
        });

        const data = await response.json();
        const sectionInput = document.getElementById("formSection");
        const submitBtn = document.getElementById("submitBtn");
        const lockMsg = document.getElementById("rfid-lock-message");

        if (data.success) {
            isRfidVerified = true;
            sectionInput.value = data.section;
            lockMsg.style.background = "#dcfce7";
            lockMsg.innerHTML = `✅ <strong>VERIFIED: ${data.section}</strong>`;
            submitBtn.innerHTML = "🕐 INPUT TIME FIRST";
            submitBtn.style.background = "#94a3b8";
        } else {
            showInvalidCardFeedback(uid);
        }
    } catch (err) {
        console.error("RFID Verification Failed:", err);
    }
}

/** Visual error state for invalid cards */
function showInvalidCardFeedback(uid) {
    const lockMsg = document.getElementById('rfid-lock-message');
    const submitBtn = document.getElementById('submitBtn');

    lockMsg.innerHTML = `❌ <strong>INVALID CARD (${uid})</strong><br><small>Use registered Student ID</small>`;
    lockMsg.style.background = "#fee2e2";
    lockMsg.style.color = "#ef4444";
    submitBtn.disabled = true;
    submitBtn.innerHTML = "🔐 ACCESS DENIED";

    setTimeout(() => {
        if (!isRfidVerified) {
            lockMsg.innerHTML = `🔐 <strong>TAP YOUR RFID CARD</strong><br><small>Student ID required to unlock</small>`;
            lockMsg.style.background = "#fef3c7";
            lockMsg.style.color = "";
            submitBtn.innerHTML = "🔐 LOCKED - TAP RFID";
        }
    }, 3000);
}

// =====================================================
// 5. MODAL & RESERVATION UI
// =====================================================

/** Opens the booking interface for a specific room */
function openRoom(roomNo) {
    const modal = document.getElementById("modal");
    const modalBody = document.querySelector(".kiosk-modal-body");
    const today = new Date().toLocaleDateString('en-CA');

    modal.style.display = "flex";

    // Palitan ang title: Kung COURT, "BASKETBALL COURT" ang ipakita, kung hindi "Room XXX"
    document.getElementById("roomTitle").innerText = (roomNo === "COURT") ? "🏀 BASKETBALL COURT" : "Room " + roomNo;

    // --- LOGIC PARA SA PURPOSE OPTIONS ---
    let purposeOptions = "";
    if (roomNo === "COURT") {
        purposeOptions = `
            <option value="EVENT">EVENT</option>
            <option value="BB TRAINING">BB TRAINING</option>
            <option value="VB TRAINING">VB TRAINING</option>
            <option value="DANCE PRACTICE">DANCE PRACTICE</option>
        `;
    } else {
        purposeOptions = `
            <option value="CLASS">CLASS</option>
            <option value="MEETING">MEETING</option>
            <option value="EXAM">EXAM</option>
            <option value="EVENT">EVENT</option>
        `;
    }

    // --- RENDER MODAL BODY ---
    modalBody.innerHTML = `
        <div class="modal-split-view" style="display: flex; gap: 20px; min-height: 400px;">
            <div class="form-side" style="flex: 1.2; padding-right: 20px; border-right: 2px solid #f1f5f9;">
                <div id="rfid-lock-message" class="rfid-prompt-large" style="text-align:center; padding:15px; background:#fef3c7; border-radius:10px; margin-bottom:15px;">
                    🔐 <strong>TAP RFID TO START</strong>
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label>👥 Section/Organization</label>
                    <input type="text" id="formSection" readonly placeholder="Waiting for RFID..." style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                </div>
                <div class="form-row" style="display: flex; gap: 10px; margin-bottom:15px;">
                    <div style="flex: 1.2;">
                        <label>📅 Date</label>
                        <input type="date" id="formDate" value="${today}" min="${today}"
                               onchange="checkConflicts('${roomNo}'); renderRoomSchedule('${roomNo}')"
                               style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                    </div>
                    <div style="flex: 0.8;">
                        <label>🎯 Purpose</label>
                        <select id="formPurpose" style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px; background:white;">
                            ${purposeOptions}
                        </select>
                    </div>
                </div>
                <div class="form-row" style="display: flex; gap: 10px; margin-bottom:20px;">
                    <div style="flex: 1;">
                        <label>🕐 Start</label>
                        <input type="time" id="formStart" oninput="checkConflicts('${roomNo}')" style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                    </div>
                    <div style="flex: 1;">
                        <label>🕑 End</label>
                        <input type="time" id="formEnd" oninput="checkConflicts('${roomNo}')" style="width:100%; padding:10px; border:2px solid #ddd; border-radius:8px;">
                    </div>
                </div>
                <button id="submitBtn" disabled onclick="saveReservation('${roomNo}')" style="width:100%; padding:15px; background:#94a3b8; color:white; border:none; border-radius:10px; font-weight:bold; cursor:not-allowed;">
                    🔐 LOCKED - TAP RFID
                </button>
            </div>
            <div class="schedule-side" style="flex: 0.8; background: #f8fafc; padding: 15px; border-radius: 12px; overflow-y: auto;">
                <h3 style="font-size: 16px; color: #1e3a8a; margin-bottom: 15px; border-bottom: 2px solid #e2e8f0; padding-bottom: 5px;">📅 Upcoming Schedule</h3>
                <div id="modalScheduleList"></div>
            </div>
        </div>`;

    renderRoomSchedule(roomNo);
}

/** Handles logical validation and overlap detection */
function checkConflicts(roomNo) {
    const start = document.getElementById("formStart").value;
    const end = document.getElementById("formEnd").value;
    const submitBtn = document.getElementById("submitBtn");
    const lockMsg = document.getElementById("rfid-lock-message");

    if (!start || !end) {
        submitBtn.disabled = true;
        submitBtn.style.background = "#94a3b8";
        submitBtn.innerText = "🔐 INPUT TIME FIRST";
        return;
    }

    if (end <= start) {
        lockMsg.style.background = "#fee2e2";
        lockMsg.innerHTML = "⚠️ <strong>INVALID TIME:</strong> End must be later than start.";
        submitBtn.disabled = true;
        submitBtn.style.background = "#ef4444";
        return;
    }

    const conflict = reservations.find(r => r.room === roomNo && (start < r.end && end > r.start));

    if (conflict) {
        submitBtn.disabled = true;
        submitBtn.innerText = "❌ SLOT OCCUPIED";
    } else if (isRfidVerified) {
        submitBtn.disabled = false;
        submitBtn.style.background = "#1e3a8a";
        submitBtn.innerText = "✅ CONFIRM RESERVATION";
        submitBtn.style.cursor = "pointer";
    }
}

/** Resets all modal variables and UI states */
function closeModal() {
    document.getElementById('modal').style.display = 'none';
    isRfidVerified = false;
    rfidBuffer = "";

    const lockMsg = document.getElementById("rfid-lock-message");
    const sectionInput = document.getElementById("formSection");
    const submitBtn = document.getElementById("submitBtn");

    if (lockMsg) {
        lockMsg.innerHTML = `🔐 <strong>TAP RFID TO START</strong>`;
        lockMsg.style.background = "#fef3c7";
        lockMsg.style.color = "";
    }
    if (sectionInput) sectionInput.value = "";
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.style.background = "#94a3b8";
        submitBtn.innerHTML = "🔐 LOCKED - TAP RFID";
        submitBtn.style.cursor = "not-allowed";
    }
}

// =====================================================
// 6. DASHBOARD RENDERING & STATUS UPDATES
// =====================================================

/** Creates the physical layout of rooms on the dashboard */
function renderFloors() {
    const floorsDiv = document.getElementById("floors");
    floorsDiv.innerHTML = "";

    // Dito natin itatakda kung ano lang ang lalabas bawat floor
    const floorPlan = {
        1: ["101", "102", "103", "106", "107", "COURT"], // Floor 1 specific rooms
        2: ["202", "203", "205", "207", "208", "209", "210", "212", "213"],
        3: ["301", "302", "303", "304", "305", "307", "308", "309", "310"],
        4: ["401", "402", "403", "404", "405", "406"]
    };

    for (let floor = 1; floor <= 4; floor++) {
        let floorHTML = `<div class="floor"><h3>Floor ${floor}</h3><div class="rooms-grid">`;

        // Kukunin natin yung listahan ng rooms para sa floor na ito
        const roomsInFloor = floorPlan[floor];

        roomsInFloor.forEach(roomNo => {
            const cap = roomCapacities[roomNo] || 40;
            const displayName = roomNo === "COURT" ? "COURT" : `Room ${roomNo}`;

            floorHTML += `
                <div class="room available" id="room${roomNo}" onclick="openRoom('${roomNo}')">
                    <div class="room-number">${displayName}</div>
                    <div class="room-info">AVAILABLE</div>
                    <div class="room-timer"></div>
                    <div class="room-capacity">👤 Cap: ${cap}</div>
                </div>`;
        });

        floorHTML += `</div></div>`;
        floorsDiv.innerHTML += floorHTML;
    }
}

/** Logic to determine room colors (Green/Red/Yellow) based on time */
function updateRoomStatus() {
    const now = new Date();
    const today = now.toLocaleDateString('en-CA');
    const currentTime = now.getHours().toString().padStart(2, '0') + ":" +
        now.getMinutes().toString().padStart(2, '0');

    // Reset all to available first
    document.querySelectorAll('.room').forEach(el => {
        el.className = 'room available';
        const info = el.querySelector('.room-info');
        const timer = el.querySelector('.room-timer');
        if (info) info.innerText = "AVAILABLE";
        if (timer) timer.innerText = "";
    });

    // Apply specific status based on reservation schedule
    reservations.forEach(res => {
        if (res.date !== today) return;

        const roomEl = document.getElementById(`room${res.room}`);
        if (!roomEl) return;

        const info = roomEl.querySelector('.room-info');
        const timer = roomEl.querySelector('.room-timer');

        if (currentTime >= res.start && currentTime < res.end) {
            roomEl.classList.remove('available', 'upcoming');
            roomEl.classList.add('occupied');
            if (info) info.innerText = res.section;
            if (timer) timer.innerText = `Ends: ${formatTo12Hour(res.end)}`;
        } else if (isUpcoming(currentTime, res.start, 120)) {
            if (!roomEl.classList.contains('occupied')) {
                roomEl.classList.remove('available');
                roomEl.classList.add('upcoming');
                if (info) info.innerText = "UPCOMING: " + res.section;
                if (timer) timer.innerText = `Starts: ${formatTo12Hour(res.start)}`;
            }
        }
    });

    // Update Header Counts
    const totalRooms = 29;
    const occupiedCount = document.querySelectorAll('.room.occupied:not(#roomCOURT)').length;
    const availableCount = totalRooms - occupiedCount;

    const availableEl = document.querySelector('.header-stats div:nth-child(1)');
    const occupiedEl = document.querySelector('.header-stats div:nth-child(2)');

    if (availableEl) availableEl.innerText = `${availableCount} Available`;
    if (occupiedEl) occupiedEl.innerText = `${occupiedCount} Occupied`;

    const freeTextEl = document.getElementById('occupiedCount');
    if (freeTextEl) {
        freeTextEl.innerText = `${availableCount}/${totalRooms}`;
    }
}

function isUpcoming(current, start, threshold) {
    const [currH, currM] = current.split(':').map(Number);
    const [startH, startM] = start.split(':').map(Number);
    const diff = (startH * 60 + startM) - (currH * 60 + currM);
    return diff > 0 && diff <= threshold;
}

// =====================================================
// 7. RECEIPT & PENDING APPROVAL MODAL
// =====================================================

/** Initializes the Receipt/Approval overlay listeners */
document.addEventListener('DOMContentLoaded', function() {
    const openBtn = document.getElementById('openApprovalBtn');
    const closeBtn = document.getElementById('closeBox');
    const overlay = document.getElementById('pendingContainer');
    const modalBox = document.getElementById('modalBox');

    if (openBtn) {
        openBtn.onclick = function() {
            overlay.style.display = 'flex';
            modalBox.classList.remove('animate-close');
            modalBox.classList.add('animate-open');
            loadPendingList();
        };
    }

    if (closeBtn) closeBtn.onclick = closeOverlay;

    overlay.onclick = function(e) {
        if (e.target === overlay) closeOverlay();
    };

    function closeOverlay() {
        modalBox.classList.remove('animate-open');
        modalBox.classList.add('animate-close');
        setTimeout(() => { overlay.style.display = 'none'; }, 300);
    }
});

/** Fetches and displays reservations for receipt claiming */
/** Fetches and displays reservations for receipt claiming */
async function loadPendingList() {
    const content = document.getElementById('pendingContent');

    try {
        const response = await fetch('http://192.168.1.12:3000/api/reservations');
        if (!response.ok) throw new Error('Network response was not ok');

        const data = await response.json();
        const list = data.filter(res => res.status !== 'REJECTED' && res.receipt_claimed !== true);

        if (list.length === 0) {
            content.innerHTML = `<div style="text-align:center; padding:40px; color:#94a3b8;"><p style="font-size: 32px;">✅</p><p>Walang aktibong requests o claimed na lahat.</p></div>`;
            return;
        }

        content.innerHTML = `
            <table class="modal-table">
                <thead>
                    <tr><th>Room</th><th>Section</th><th>Schedule</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                    ${list.map(p => {
                        const isApproved = p.status === 'APPROVED';
                        const resId = p.id || p.reservation_id;
                        return `
                        <tr id="row-${resId}">
                            <td>${p.room.toLowerCase().includes('court') ? p.room : 'Room ' + p.room}</td>
                            <td>${p.section}</td>
                            <td>${p.date} (${p.start_time} - ${formatTo12Hour(p.end_time)})</td>
                            <td><span class="status-pill ${isApproved ? 'status-approved' : 'status-pending'}">${p.status}</span></td>
                            <td>
                                <button class="btn-receipt" ${!isApproved ? 'disabled' : ''} onclick="generateReceipt('${resId}')">
                                    ${isApproved ? '📄 Get Receipt' : '⏳ Waiting...'}
                                </button>
                            </td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>`;
    } catch (err) {
        console.error("Load Error:", err);
        content.innerHTML = `<div style="color:red; text-align:center; padding:20px;">Connection failed.</div>`;
    }
}

/** Handles receipt claim logic and row removal animation */
async function generateReceipt(id) {
    const row = document.getElementById(`row-${id}`);
    if (!row) return;

    // Visual feedback: disable button to prevent double-click
    const btn = row.querySelector('button');
    if (btn) {
        btn.disabled = true;
        btn.innerText = "Printing...";
    }

    try {
        const response = await fetch(`http://192.168.1.12:3000/api/reservations/${id}/claim`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' }
        });

        if (response.ok) {
            const receiptData = await response.json(); 
            
            // Trigger thermal print before removing the row
            handleThermalPrint(receiptData);

            // Animation and removal
            const targetRow = document.getElementById(`row-${id}`);
            if (targetRow) {
                removeRowWithAnimation(targetRow);
            }
        } else {
            alert("Failed to update database.");
            if (btn) {
                btn.disabled = false;
                btn.innerText = "Get Receipt";
            }
        }
    } catch (err) {
        console.error("Network Error:", err);
        alert("Connection error. Check if server is running.");
        if (btn) {
            btn.disabled = false;
            btn.innerText = "Get Receipt";
        }
    }
}

// Function para sa itsura ng Receipt
function handleThermalPrint(data) {
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    document.body.appendChild(iframe);

    const pri = iframe.contentWindow;
    pri.document.open();
    pri.document.write(`
        <html>
            <head>
                <style>
                    body { font-family: 'Courier New', monospace; width: 58mm; padding: 10px; font-size: 12px; color: #000; }
                    .center { text-align: center; }
                    .bold { font-weight: bold; }
                    .divider { border-top: 1px dotted #000; margin: 5px 0; }
                    .row { display: flex; justify-content: space-between; margin: 2px 0; }
                    
                    /* Style para sa Logo */
                    .logo-container { text-align: center; margin-bottom: 5px; }
                    .logo { 
                        width: 40mm; /* Swak sa 58mm na papel */
                        height: auto;
                        filter: grayscale(100%); /* Siguradong black and white */
                    }
                </style>
            </head>
            <body>
                <div class="logo-container">
                    <!-- Palitan ang src ng tamang path ng logo mo -->
                    <img src="./assets/LOGO.png" class="logo" alt="RAIMIS LOGO">
                </div>

                <div class="center">
                    <div class="bold" style="font-size: 16px;">RAIMIS</div>
                    <div style="font-size: 10px;">ROOM RESERVATION</div>
                </div>

                <div class="divider"></div>
                
                <div class="row"><span>ROOM:</span><span class="bold">${data.room || 'N/A'}</span></div>
                <div class="row"><span>SECTION:</span><span class="bold">${data.section || 'N/A'}</span></div>
                <div class="row"><span>DATE:</span><span class="bold">${data.date || 'N/A'}</span></div>
                <div class="row"><span>TIME:</span><span class="bold">${data.start_time} - ${data.end_time}</span></div>
                
                <div class="divider"></div>
                <div class="row"><span>STATUS:</span><span class="bold">${data.status || 'N/A'}</span></div>
                
                <div class="center" style="margin-top: 10px; font-size: 10px;">
                    Thank you for using RAIMIS!<br>
                    ${new Date().toLocaleString()}
                </div>
            </body>
        </html>
    `);
    pri.document.close();

    // Importante: Hintayin muna ma-load ang image bago i-print
    const img = pri.document.querySelector('img');
    
    if (img.complete) {
        triggerPrint(pri, iframe);
    } else {
        img.onload = () => triggerPrint(pri, iframe);
        img.onerror = () => triggerPrint(pri, iframe); // Print pa rin kahit failed ang logo
    }
}

/** Executes the browser print command and cleans up the iframe */
function triggerPrint(pri, iframe) {
    setTimeout(() => {
        pri.focus();
        pri.print();
        setTimeout(() => document.body.removeChild(iframe), 500);
    }, 500);
}

/** Slides out the table row upon successful receipt generation */
function removeRowWithAnimation(row) {
    row.style.transition = "all 0.5s ease";
    row.style.opacity = "0";
    row.style.transform = "translateX(20px)";

    setTimeout(() => {
        row.remove();
        // Show empty message if last item removed
        const tableBody = document.querySelector('#pending-table-body');
        if (tableBody && tableBody.children.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No pending reservations.</td></tr>';
        }
    }, 500);
}

// =====================================================
// 8. UI HELPERS
// =====================================================

function renderRoomSchedule(roomNo) {
    const listContainer = document.getElementById("modalScheduleList");
    const today = new Date().toLocaleDateString('en-CA');
    const currentTime = new Date().toTimeString().substring(0, 5);

    const filtered = reservations.filter(res =>
        res.room === roomNo && (res.date > today || (res.date === today && res.end > currentTime))
    ).sort((a, b) => a.date.localeCompare(b.date) || a.start.localeCompare(b.start));

    listContainer.innerHTML = filtered.length ? filtered.map(res => `
        <div style="background: white; border-left: 4px solid #1e3a8a; padding: 10px; margin-bottom: 10px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <div style="font-size: 10px; font-weight: bold; color: #64748b;">${res.date}</div>
            <div style="font-size: 13px; font-weight: bold; color: #1e3a8a;">${res.section}</div>
            <div style="font-size: 12px;">🕒 ${formatTo12Hour(res.start)} - ${formatTo12Hour(res.end)}</div>
        </div>
    `).join('') : "<p style='text-align:center; font-size:12px; color:#94a3b8;'>No upcoming bookings.</p>";
}

function loadReservationSidebar() {
    const list = document.getElementById("sideReservationList");
    if (!list) return;

    const today = new Date().toLocaleDateString('en-CA');
    const activeToday = reservations.filter(r => r.date === today).sort((a, b) => a.start.localeCompare(b.start));

    list.innerHTML = activeToday.length ? activeToday.map(r => `
        <div style="border-bottom:1px solid #eee; padding:8px; font-size:12px;">
            <b>Room ${r.room}</b> - ${r.section}<br>
            🕒 ${formatTo12Hour(r.start)} to ${formatTo12Hour(r.end)}
        </div>`).join('') : "<p style='padding:10px; font-size:12px;'>No active bookings today</p>";
}

function formatTo12Hour(time) {
    if (!time) return "";
    let [h, m] = time.split(':');
    let ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return `${h}:${m} ${ampm}`;
}

function updateClock() {
    const clockEl = document.getElementById("clock");
    if (clockEl) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        clockEl.innerText = new Date().toLocaleString('en-US', options);
    }
}

// Launch the system
init();