/**
 * =====================================================
 * RAIMIS - BACKEND SERVER
 * =====================================================
 */
const express = require("express");
const cors = require("cors");
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const { Pool } = require("pg");
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');

const upload = multer({ dest: 'uploads/' });
const app = express();
const PORT = 3000;
const IP_ADDRESS = '0.0.0.0';

// =====================================================
// 1. MIDDLEWARE & CONFIGURATION
// =====================================================
app.use(express.json());
app.use(express.static('public'));

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "raimis_db",
    password: "luigi",
    port: 5432
});

pool.connect()
    .then(() => console.log("✅ RAIMIS Database: Connected successfully"))
    .catch(err => console.error("❌ Database Connection Error:", err));

const formatAMPM = (timeStr) => {
    if (!timeStr) return "";
    const [h, m] = timeStr.split(':');
    return new Date(2000, 0, 1, h, m).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
};

// =====================================================
// 2. API ENDPOINTS
// (These are the "Service Windows" of your server)
// =====================================================
function convertTo24Hour(timeStr) {
    if (!timeStr) return null;
    if (!timeStr.includes('AM') && !timeStr.includes('PM')) return timeStr.substring(0, 5) + ":00";
    const [time, modifier] = timeStr.split(' ');
    const [h, m] = time.split(':');
    const adjustedHour = modifier === 'PM' && h !== '12' ? parseInt(h) + 12 : (modifier === 'AM' && h === '12' ? 0 : h);
    return new Date(2000, 0, 1, adjustedHour, m).toLocaleTimeString('en-GB');
}

app.post('/api/login', async (req, res) => {
    const { username, password, role } = req.body;

    try {
        if (username === 'admin001' && password === 'admin526') {
            // Kapag TAMA ang credentials
            return res.json({
                success: true,
                username: username,
                full_name: 'System Administrator',
                role: 'admin'
            });
        } else {
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid credentials' 
            });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// =====================================================
// GET ALL RFID USERS WITH COMPLETE MATRIX CONTEXT
// =====================================================
app.get('/api/rfid-users', async(req, res) => {
    try {
        const query = `
            SELECT id, rfid_serial, role, identifier, security_pin, additional_info, cancel_strikes, is_blocked 
            FROM rfid_users 
            ORDER BY id DESC
        `;
        const result = await pool.query(query);

        return res.status(200).json({
            success: true,
            count: result.rows.length,
            data: result.rows
        });
    } catch (err) {
        console.error("Express Gateway Fetch All Error:", err.message);
        return res.status(500).json({
            success: false,
            error: "Internal server error reading user registry entries."
        });
    }
});

// =====================================================
// GET SINGLE RFID USER BY SERIAL IDENTITY Key
// =====================================================
app.get('/api/rfid-users/:serial', async(req, res) => {
    try {
        const { serial } = req.params;

        if (!serial) {
            return res.status(400).json({ success: false, error: "Missing required rfid serial address parameter." });
        }

        const cleanSerial = String(serial).trim();

        // FIX: Idinagdag na si cancel_strikes at is_blocked sa SELECT fields para mabasa ng frontend wrapper guard
        const query = `
            SELECT id, rfid_serial, role, identifier, security_pin, additional_info, cancel_strikes, is_blocked 
            FROM rfid_users 
            WHERE rfid_serial = $1 
            LIMIT 1
        `;
        const result = await pool.query(query, [cleanSerial]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: `No registered account linked to serial tracker key [${cleanSerial}].`
            });
        }

        return res.status(200).json({
            success: true,
            data: result.rows[0]
        });
    } catch (err) {
        console.error(`Express Gateway Fetch Single Error [${req.params.serial}]:`, err.message);
        return res.status(500).json({
            success: false,
            error: "Database abstraction layer runtime interruption."
        });
    }
});

app.get('/api/rfid/scan/:cardId', async(req, res) => {
    try {
        const { cardId } = req.params;

        // FIXED: Ginamit ang tamang column names (identifier at rfid_serial) mula sa database.sql
        const userQuery = `
            SELECT id, identifier, role, rfid_serial, security_pin 
            FROM rfid_users 
            WHERE rfid_serial = $1 LIMIT 1
        `;
        const result = await pool.query(userQuery, [cardId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "RFID Card not registered." });
        }

        // Ibalik ang user data kasama ang PIN sa frontend
        return res.json({ success: true, user: result.rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// REGISTRATION & UPDATE ENDPOINT
app.post('/api/register', async(req, res) => {
    // 1. Isinama natin ang "id" na manggagaling sa frontend form kapag nag-eedit
    let { id, rfid_serial, role, identifier, security_pin, additional_info } = req.body;

    try {
        if (rfid_serial) {
            rfid_serial = String(rfid_serial).trim();
        } else {
            return res.status(400).json({ success: false, error: "RFID Serial is required" });
        }

        const jsonPayload = JSON.stringify(Array.isArray(additional_info) ? additional_info : []);

        let query;
        let values;

        // 2. DITO ANG LOGIC NG FIX:
        // Kung may 'id' na pinasa, nangangahulugan na nag-eedit tayo ng lumang card!
        if (id) {
            query = `
                UPDATE rfid_users 
                SET rfid_serial = $1, role = $2, identifier = $3, security_pin = $4, additional_info = $5
                WHERE id = $6
                RETURNING *`;

            values = [rfid_serial, role, identifier, security_pin, jsonPayload, id];
        }
        // Kung walang 'id', ibig sabihin ay bagong registration (gaya ng dati mong gawa)
        else {
            query = `
                INSERT INTO rfid_users (rfid_serial, role, identifier, security_pin, additional_info)
                VALUES ($1, $2, $3, $4, $5)
                ON CONFLICT (rfid_serial) 
                DO UPDATE SET 
                    role = EXCLUDED.role,
                    identifier = EXCLUDED.identifier,
                    security_pin = EXCLUDED.security_pin,
                    additional_info = EXCLUDED.additional_info
                RETURNING *`;

            values = [rfid_serial, role, identifier, security_pin, jsonPayload];
        }

        const result = await pool.query(query, values);

        res.status(200).json({ success: true, user: result.rows[0] });

    } catch (err) {
        console.error("FULL ERROR:", err);

        // BONUS FIX: Saluhin natin kung pinalitan ang serial number pero may kapareho na palang iba sa database
        if (err.code === '23505') {
            return res.status(400).json({
                success: false,
                error: "The new RFID Serial is already registered to another user!"
            });
        }

        res.status(500).json({
            success: false,
            error: "Database Error",
            detail: err.message
        });
    }
});

/**
 * GET: Retrieve All Fixed Schedules
 * This is used for the Admin's view to see the "Master List" 
 * of every class schedule stored in the database.
 */
app.get('/api/fixed-schedules', async(req, res) => {
    try {
        // Asking the database to give us everything, but keep it organized
        // by the Day (Monday, Tuesday...) and the Time.
        const result = await pool.query('SELECT * FROM fixed_schedules ORDER BY day_of_week, start_time');

        // Sending that organized list back to the Admin screen.
        res.json(result.rows);
    } catch (err) {
        // If the database is busy or has an error, tell the user what went wrong.
        res.status(500).json({ error: err.message });
    }
});

/**
 * POST: Add Semester Schedule (Admin Entry)
 * This is for the official school schedule. It has a "Traffic Jam" detector.
 */
app.post('/api/fixed-schedules', async(req, res) => {
    const { room, day, course, subject, prof, start, end } = req.body;

    // Check if the Admin forgot to fill in the time or room
    if (!room || !day || !start || !end) {
        return res.status(400).json({
            success: false,
            error: "Incomplete details: Room, Day, Start Time, and End Time are required."
        });
    }

    try {
        // 1. Conflict Validation (The Traffic Jam Detector)
        // This checks if the room is ALREADY booked at the time you are trying to set.
        const checkConflictQuery = `
            SELECT subject, start_time, end_time 
            FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND is_active = TRUE 
            AND (start_time < $4 AND end_time > $3)
            LIMIT 1
        `;

        const conflictResult = await pool.query(checkConflictQuery, [room, day, start, end]);

        // If a conflict is found, stop the process and tell the Admin who is using the room
        if (conflictResult.rows.length > 0) {
            const conflict = conflictResult.rows[0];
            const formattedStart = formatAMPM(conflict.start_time);
            const formattedEnd = formatAMPM(conflict.end_time);

            return res.status(409).json({
                success: false,
                error: `Schedule Conflict: Room already booked for "${conflict.subject}" from ${formattedStart} to ${formattedEnd}.`
            });
        }

        // 2. If the room is free, save the new schedule into the database
        const insertQuery = `
            INSERT INTO fixed_schedules (
                room_id, day_of_week, course_section, subject, professor, start_time, end_time, is_active
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE) 
            RETURNING *;
        `;

        const result = await pool.query(insertQuery, [room, day, course, subject, prof, start, end]);

        res.status(201).json({
            success: true,
            message: "Schedule successfully recorded.",
            data: result.rows[0]
        });

    } catch (err) {
        console.error("Transaction Error:", err.message);
        res.status(500).json({
            success: false,
            error: "Server error during schedule processing."
        });
    }
});

// POST endpoint para sa bulk import
app.post('/api/schedule/import', upload.single('scheduleFile'), async (req, res) => {
    // 1. I-check kung may file
    if (!req.file) {
        return res.status(400).json({ error: 'Walang file na na-upload.' });
    }

    const filePath = req.file.path;
    const results = [];

    try {
        // 2. Hintayin matapos ang CSV parsing
        await new Promise((resolve, reject) => {
            fs.createReadStream(filePath)
                .pipe(csv())
                .on('data', (data) => results.push(data))
                .on('end', resolve)
                .on('error', reject);
        });

        // 3. Database Transaction
        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            for (const row of results) {
                // DATA INTEGRITY CHECK: Iwasang magpasok ng blangkong linya
                if (!row.room || !row.day || !row.start_time || !row.end_time) {
                     continue; // Laktawan ang blangkong linya
                }

                const rawDay = row.day ? row.day.trim().toLowerCase() : '';
                const formattedDay = rawDay.charAt(0).toUpperCase() + rawDay.slice(1);

                const validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                const finalDay = validDays.includes(formattedDay) ? formattedDay : 'Monday';

                // ⚠️ DITO NATIN ITINUGMA ANG COLUMNS SA DATABASE MO
                const query = `
                    INSERT INTO fixed_schedules 
                    (room_id, day_of_week, course_section, subject, professor, start_time, end_time, is_active) 
                    VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE)
                    ON CONFLICT (room_id, day_of_week, start_time) 
                    DO UPDATE SET 
                        course_section = EXCLUDED.course_section,
                        subject = EXCLUDED.subject,
                        professor = EXCLUDED.professor,
                        end_time = EXCLUDED.end_time;
                `;
                
                await client.query(query, [
                    row.room, 
                    finalDay,
                    row.section, // Ipinasok ang section dito
                    row.subject, 
                    row.professor || 'N/A', 
                    row.start_time, 
                    row.end_time
                ]);
            }

            await client.query('COMMIT');
            res.json({ success: true, insertedCount: results.length });

        } catch (dbErr) {
            await client.query('ROLLBACK');
            throw dbErr; // I-pass sa main catch block
        } finally {
            client.release();
        }

    } catch (err) {
        console.error('Import Error:', err);
        res.status(500).json({ error: 'Failed to process file: ' + err.message });
    } finally {
        // Burahin ang temporary file
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }
});

app.patch('/api/schedule/toggle-cancel/:id', async (req, res) => {
    const { id } = req.params; // Ito yung schedule_id ng fixed class
    const { is_cancelled, target_date } = req.body; 

    if (!target_date) {
        return res.status(400).json({ error: "Missing required field: target_date (YYYY-MM-DD)" });
    }

    try {
        // Magsisimula ng database transaction para siguradong sabay silang gagana
        await pool.query('BEGIN');

        // STEP 1: I-update ang live state sa fixed_schedules table (Para mag-true o false)
        const updateSchedule = await pool.query(
            "UPDATE fixed_schedules SET is_cancelled = $1 WHERE id = $2 RETURNING *", 
            [is_cancelled, id]
        );

        if (updateSchedule.rowCount === 0) {
            await pool.query('ROLLBACK');
            return res.status(404).json({ error: "Schedule not found" });
        }

        // STEP 2: I-manage ang room_cancellations history table depende sa action
        if (is_cancelled === true) {
            // 🚫 KUNG CANCEL: Mag-insert ng row sa audit history log
            await pool.query(
                `INSERT INTO room_cancellations (schedule_id, cancelled_date) 
                 VALUES ($1, $2) 
                 ON CONFLICT DO NOTHING`, 
                [id, target_date]
            );
        } else {
            // 🔄 KUNG RESTORE: Burahin ang log entry para maging malinis ulit ang araw na iyon
            await pool.query(
                `DELETE FROM room_cancellations 
                 WHERE schedule_id = $1 AND cancelled_date = $2`, 
                [id, target_date]
            );
        }

        // Kapag walang nag-error sa dalawang step, i-save na sa database permanently
        await pool.query('COMMIT');
        
        res.json({ 
            success: true, 
            message: is_cancelled ? "Schedule cancelled and logged." : "Schedule restored and log cleared.",
            data: updateSchedule.rows[0] // Ibalik ang binagong row ng fixed_schedules
        });

    } catch (err) {
        // Kapag may sumablay kahit isa sa dalawang table, i-cancel ang buong transaction para walang masirang data
        await pool.query('ROLLBACK');
        console.error("Database Error during toggle-cancel transaction:", err);
        res.status(500).json({ error: "Server error during cancellation routine: " + err.message });
    }
});
// Route para i-toggle ang cancel status ng schedule
app.patch('/api/schedule/toggle-cancel/:id', async (req, res) => {
    const { id } = req.params; 
    const { is_cancelled, target_date } = req.body; 

    if (!target_date) {
        return res.status(400).json({ error: "Missing required field: target_date (YYYY-MM-DD)" });
    }

    try {
        await pool.query('BEGIN');

        const updateSchedule = await pool.query(
            "UPDATE fixed_schedules SET is_cancelled = $1 WHERE id = $2 RETURNING *", 
            [is_cancelled, id]
        );

        if (updateSchedule.rowCount === 0) {
            await pool.query('ROLLBACK');
            return res.status(404).json({ error: "Schedule not found" });
        }

        // STEP 2: HISTORICAL LOGGING LOGIC
        if (is_cancelled === true) {
            await pool.query(
                `INSERT INTO room_cancellations (schedule_id, cancelled_date) 
                 VALUES ($1, $2) 
                 ON CONFLICT DO NOTHING`, 
                [id, target_date]
            );
        } else {
            console.log(`Schedule ID ${id} restored for future dates. Past logs preserved.`);
        }

        await pool.query('COMMIT');
        
        res.json({ 
            success: true, 
            message: is_cancelled ? "Schedule cancelled and logged." : "Schedule activated for future weeks; historical logs kept.",
            data: updateSchedule.rows[0]
        });

    } catch (err) {
        await pool.query('ROLLBACK');
        console.error("Transaction Error:", err);
        res.status(500).json({ error: "Server error during cancellation routine: " + err.message });
    }
});
/**
 * DELETE: Remove a specific Fixed Schedule
 * Used when the Admin wants to cancel or delete a specific class schedule.
 */
app.delete('/api/fixed-schedules/:id', async(req, res) => {
    // The "id" is the unique number of the specific schedule we want to delete.
    const { id } = req.params;

    try {
        // Telling the database: "Find the schedule with this ID and erase it."
        const result = await pool.query('DELETE FROM fixed_schedules WHERE id = $1', [id]);

        // Checking if we actually deleted something. 
        // If rowCount is 0, it means the ID didn't exist in the cabinet.
        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, error: "Schedule not found." });
        }

        // Success! The schedule is gone.
        res.json({ success: true, message: "Schedule deleted successfully." });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/schedule/reset', async (req, res) => {
    try {
        // I-set ang lahat ng schedule sa is_active = FALSE
        const query = `UPDATE fixed_schedules SET is_active = FALSE`;
        await pool.query(query);
        
        res.json({ success: true, message: "Table reset successfully (Records archived)." });
    } catch (err) {
        console.error("Reset Error:", err);
        res.status(500).json({ success: false, error: "Failed to reset table." });
    }
});

app.post('/api/schedules/cancel', async (req, res) => {
    const { schedule_id, target_date } = req.body; // e.g., schedule_id: 12, target_date: '2026-05-16'
    try {
        await pool.query('BEGIN');

        // Step A: (Opsyonal) Baguhin ang live state sa fixed_schedules kung gusto mo, 
        // pero mas mainam na panatilihin itong nakabukas para sa ibang linggo.
        // O kaya, i-log lang natin ang kanselasyon para sa partikular na araw na ito:
        await pool.query(
            `INSERT INTO room_cancellations (schedule_id, cancelled_date) 
             VALUES ($1, $2) ON CONFLICT DO NOTHING`,
            [schedule_id, target_date]
        );

        await pool.query('COMMIT');
        res.json({ success: true, message: "Class cancelled successfully for this date." });
    } catch (err) {
        await pool.query('ROLLBACK');
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/schedules/restore', async (req, res) => {
    const { schedule_id, target_date } = req.body; // e.g., schedule_id: 12, target_date: '2026-05-16'
    try {
        await pool.query(
            `DELETE FROM room_cancellations 
             WHERE schedule_id = $1 AND cancelled_date = $2`,
            [schedule_id, target_date]
        );

        res.json({ success: true, message: "Class restored successfully for this date." });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/reservations/history', async(req, res) => {
    try {
        const query = `
            SELECT * FROM reservations 
            WHERE status = 'APPROVED' 
            ORDER BY date DESC, start_time DESC
        `;
        const result = await pool.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error("History Fetch Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.get('/api/approved-reservations/:roomNo', async(req, res) => {
    const { roomNo } = req.params;
    let targetDate = req.query.date;

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const todayStr = `${year}-${month}-${day}`; // Format: YYYY-MM-DD

    if (!targetDate || targetDate === 'today') {
        targetDate = todayStr;
    }

    const currentTime = now.toTimeString().split(' ')[0];

    try {
        let query;
        let values;

        if (targetDate === todayStr) {
            query = `
                SELECT id, room, subject, professor, section, start_time, end_time, purpose 
                FROM reservations 
                WHERE room = $1 
                  AND status = 'APPROVED' 
                  AND date = $2
                  AND end_time > $3  -- Gumagana lang ang time checking kung araw ngayon
                ORDER BY start_time ASC
            `;
            values = [roomNo, targetDate, currentTime];
        } else {
            query = `
                SELECT id, room, subject, professor, section, start_time, end_time, purpose 
                FROM reservations 
                WHERE room = $1 
                  AND status = 'APPROVED' 
                  AND date = $2 -- Ipakita lahat ng schedule para sa araw na ito nang walang time limit
                ORDER BY start_time ASC
            `;
            values = [roomNo, targetDate];
        }

        const result = await pool.query(query, values);
        res.json(result.rows);
    } catch (err) {
        console.error("Error fetching approved reservations:", err.message);
        res.status(500).json({ error: "Server Database Error" });
    }
});

app.post('/api/reservations', async(req, res) => {
    try {
        const { room, rfid_tag, section, date, start_time, end_time, purpose, subject, professor } = req.body;

        // Siguraduhing malinis ang time strings bago i-verify o i-save
        const formattedStart = convertTo24Hour(start_time);
        const formattedEnd = convertTo24Hour(end_time);

        if (formattedStart >= formattedEnd) {
            return res.status(400).json({
                success: false,
                message: "Logical Error: Start time cannot be later than or equal to End time."
            });
        }

        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const dayOfWeek = days[new Date(date).getDay()];

        // Conflict check Engine (APPROVED requests & Fixed Schedules)
        const conflictQuery = `
            SELECT id FROM reservations 
            WHERE room = $1 AND date = $2 AND status = 'APPROVED'
            AND (start_time < $4 AND end_time > $3)
            UNION
            SELECT id FROM fixed_schedules
            WHERE room_id = $1 AND day_of_week = $5 AND is_cancelled = false
            AND (start_time < $4 AND end_time > $3)
        `;

        const conflictCheck = await pool.query(conflictQuery, [room, date, formattedStart, formattedEnd, dayOfWeek]);

        if (conflictCheck.rows.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Double Booking Error: The requested time slot is already occupied by an approved schedule or a fixed class."
            });
        }

        const query = `
            INSERT INTO reservations (room, rfid_tag, section, date, start_time, end_time, purpose, subject, professor, status) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'APPROVED') 
            RETURNING *
        `;

        const values = [
            room,
            rfid_tag || null,
            section,
            date,
            formattedStart,
            formattedEnd,
            purpose,
            subject,
            professor
        ];

        const result = await pool.query(query, values);

        return res.status(201).json({
            success: true,
            message: "Reservation successfully approved and booked.", 
            data: result.rows[0]
        });

    } catch (err) {
        console.error("Database Insert Error:", err.message);
        return res.status(500).json({
            success: false,
            error: "Internal Database Error: " + err.message
        });
    }
});

app.post('/api/reservations/claim/:id', async (req, res) => {
    const { id } = req.params;
    try {
        
        const checkQuery = "SELECT print_count FROM reservations WHERE id = $1";
        const checkResult = await pool.query(checkQuery, [id]);

        if (checkResult.rows.length === 0) {
            return res.status(404).json({ success: false, error: "Reservation record not found." });
        }

        const currentCount = checkResult.rows[0].print_count || 0;

        if (currentCount >= 2) {
            return res.status(400).json({ 
                success: false, 
                error: "Access Denied: Isang schedule owner ay pinapayagan lamang mag-print ng resibo hanggang 2 beses." 
            });
        }

        const updateQuery = `
            UPDATE reservations 
            SET print_count = print_count + 1 
            WHERE id = $1 
            RETURNING *
        `;
        const result = await pool.query(updateQuery, [id]);
        
        return res.json({
            success: true,
            message: "Database record updated successfully.",
            reservationData: result.rows[0] // Ibalik ang data para sa thermal printer layout mamaya
        });

    } catch (err) {
        return res.status(500).json({ success: false, error: "Database internal operational error." });
    }
});

app.get('/api/reservations/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query(
            'SELECT * FROM reservations WHERE id = $1', [id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: "Reservation not found." });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/reservations/:id/status', async(req, res) => {
    const { id } = req.params;
    const { status } = req.body; // 'APPROVED' or 'REJECTED'

    try {
        if (status === 'REJECTED') {
            await pool.query("UPDATE reservations SET status = $1 WHERE id = $2", [status, id]);
            return res.json({ success: true, message: "Reservation rejected successfully." });
        }

        const currentReqRes = await pool.query("SELECT * FROM reservations WHERE id = $1", [id]);
        const currentReq = currentReqRes.rows[0];

        if (!currentReq) {
            return res.status(404).json({ error: "Reservation not found." });
        }

        const conflictQuery = `
            SELECT id FROM reservations 
            WHERE room = $1 
              AND date = $2 
              AND status = 'APPROVED'
              AND (start_time < $3 AND end_time > $4)`;

        const conflicts = await pool.query(conflictQuery, [
            currentReq.room,
            currentReq.date,
            currentReq.end_time,
            currentReq.start_time
        ]);

        if (conflicts.rows.length > 0) {
            return res.status(409).json({
                success: false,
                error: "Schedule Conflict",
                message: "May nauna nang na-approve na reservation sa slot na ito."
            });
        }

        await pool.query('BEGIN');

        await pool.query("UPDATE reservations SET status = 'APPROVED' WHERE id = $1", [id]);

        const autoRejectQuery = `
            UPDATE reservations 
            SET status = 'REJECTED' 
            WHERE id != $1 
              AND room = $2 
              AND date = $3 
              AND status = 'PENDING'
              AND (start_time < $4 AND end_time > $5)
        `;
        await pool.query(autoRejectQuery, [
            id,
            currentReq.room,
            currentReq.date,
            currentReq.end_time,
            currentReq.start_time
        ]);

        await pool.query('COMMIT');

        res.json({
            success: true,
            message: "Reservation approved! Other conflicting pending requests were automatically rejected."
        });

    } catch (err) {
        await pool.query('ROLLBACK'); // Bawiin ang changes kung may error
        console.error(err.message);
        res.status(500).json({ error: "Database error during status update." });
    }
});

//*Cancellation Logic
app.post('/api/reservations/cancel', async (req, res) => {
    const { reservation_id, rfid_tag } = req.body;

    if (!reservation_id || !rfid_tag) {
        return res.status(400).json({ success: false, message: "Missing reservation ID or RFID tag." });
    }

    const dbClient = typeof db !== 'undefined' ? db : pool; 

    try {
        await dbClient.query('BEGIN');

        // 1. TUGMA SA DB: I-check muna kung rehistrado nga ang RFID card
        const userCheck = await dbClient.query(
            'SELECT is_blocked, cancel_strikes FROM rfid_users WHERE TRIM(rfid_serial) = $1', 
            [rfid_tag.trim()]
        );
        
        if (userCheck.rows.length === 0) {
            await dbClient.query('ROLLBACK');
            return res.status(404).json({ success: false, message: "RFID serial not registered in the system." });
        }

        // 2. I-UPDATE ANG STATUS NG RESERVATION
        // Gumamit ng RETURNING clause para masiguradong may na-update talaga sa table
        const reservationUpdate = await dbClient.query(
            'UPDATE reservations SET status = \'CANCELLED\' WHERE id = $1 RETURNING id', 
            [reservation_id]
        );

        // SAFE GUARD: Kung walang nabagong reservation, baka ito ay nasa fixed_schedules table
        if (reservationUpdate.rows.length === 0) {
            // OPTIONAL ALTERNATIVE: Kung fixed schedule ang pinapakansela niyo sa screen:
            // await dbClient.query('UPDATE fixed_schedules SET is_cancelled = true WHERE id = $1', [reservation_id]);
            console.log(`Warning: No row found in reservations table for ID ${reservation_id}. Checking flow...`);
        }

        // 3. I-UPDATE ANG CANCEL STRIKES NG USER
        const userUpdate = await dbClient.query(
            `UPDATE rfid_users 
             SET cancel_strikes = cancel_strikes + 1 
             WHERE TRIM(rfid_serial) = $1 
             RETURNING cancel_strikes`, 
            [rfid_tag.trim()]
        );

        // SAFE GUARD PROTECTION: Siguraduhing may bumalik na row bago basahin ang property
        if (userUpdate.rows.length === 0) {
            await dbClient.query('ROLLBACK');
            return res.status(500).json({ success: false, message: "Failed to update user cancellation counter." });
        }

        const currentStrikes = userUpdate.rows[0].cancel_strikes;
        let message = `Reservation cancelled successfully. You have ${Math.max(0, 3 - currentStrikes)} strikes left.`;
        
        // 4. Kung umabot o lumampas na sa 3 strikes, tuluyan nang i-block ang card
        if (currentStrikes >= 3) {
            await dbClient.query(
                'UPDATE rfid_users SET is_blocked = true WHERE TRIM(rfid_serial) = $1', 
                [rfid_tag.trim()]
            );
            message = "Reservation cancelled. Your RFID has been BLOCKED due to reaching 3 cancellation strikes.";
        }

        await dbClient.query('COMMIT');
        
        // SIGURADONG MALINIS NA JSON RESPONSE
        return res.status(200).json({ success: true, message });

    } catch (err) {
        try { await dbClient.query('ROLLBACK'); } catch(e) {}
        console.error("CRITICAL BACKEND CANCELLATION CRASH:", err.message);
        
        // Piliting magbalik ng JSON para hindi maging HTML Error page ang response ng Express
        return res.status(500).json({ success: false, message: "Internal Server Error: " + err.message });
    }
});

// Endpoint para sa pag-unblock ng RFID card (Admin Privileges)
app.post('/api/admin/reset-strikes', async (req, res) => {
    // Kinukuha ang rfid_tag/rfid_serial na ipinadala mula sa frontend body
    const { rfid_tag } = req.body; 

    // Guard Clause: Siguraduhing may ipinasang serial bago mag-query sa DB
    if (!rfid_tag) {
        return res.status(400).json({ 
            success: false, 
            message: "Missing RFID serial address parameter." 
        });
    }

    try {
        // TUGMA SA DB: 'rfid_users' ang table at 'rfid_serial' ang column name
        // Nilalagyan din natin ng TRIM para siguradong walang hidden spaces ang RFID string
        const query = `
            UPDATE rfid_users 
            SET cancel_strikes = 0, 
                is_blocked = false 
            WHERE TRIM(rfid_serial) = $1
            RETURNING identifier;
        `;
        
        const result = await pool.query(query, [rfid_tag.trim()]);

        // Kung walang nahanap na record sa database na may ganoong serial
        if (result.rows.length === 0) {
            return res.status(404).json({ 
                success: false, 
                message: "RFID serial not found in the records." 
            });
        }

        const userName = result.rows[0].identifier;

        // Magpasa ng tagumpay na response pabalik sa frontend admin panel
        return res.status(200).json({ 
            success: true, 
            message: `Account privileges for ${userName} have been successfully restored. Strikes reset to 0.` 
        });

    } catch (err) {
        console.error("CRITICAL ADMIN UNBLOCK ERROR:", err.message);
        return res.status(500).json({ 
            success: false, 
            message: "Database runtime interruption during account reset." 
        });
    }
});

/**GET: Real-time Room Status Check*/
app.get('/api/kiosk/check-status/:room_id', async(req, res) => {
    const { room_id } = req.params;
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const today = days[new Date().getDay()];
    const now = new Date();
    const currentTime = now.toTimeString().split(' ')[0];

    try {
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND start_time <= $3 
            AND end_time >= $3
            LIMIT 1`;
        const result = await pool.query(query, [room_id, today, currentTime]);

        if (result.rows.length > 0) {
            res.json({ occupied: true, data: result.rows[0] });
        } else {
            res.json({ occupied: false });
        }
    } catch (err) {
        console.error("Status Check Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

/**
 * GET: Fetch Upcoming Classes for a Specific Room
 * Used by the Kiosk to show students what classes are coming up NEXT today.
 */
app.get('/api/kiosk/upcoming-semester/:room_id', async(req, res) => {
    const { room_id } = req.params;
    const { day } = req.query; // Kunin ang araw mula sa dropdown

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    let targetDay = day;
    let timeFilter = '00:00:00'; // Default: Ipakita LAHAT ng klase sa araw na iyon

    // Kung "today" ang pinili, i-filter base sa kasalukuyang oras at araw
    if (!day || day === 'today') {
        targetDay = days[new Date().getDay()];
        timeFilter = new Date().toTimeString().split(' ')[0];
    }

    try {
        const query = `
            SELECT * FROM fixed_schedules 
            WHERE room_id = $1 
            AND day_of_week = $2 
            AND end_time > $3
            ORDER BY start_time ASC`;

        const result = await pool.query(query, [room_id, targetDay, timeFilter]);
        res.json(result.rows);
    } catch (err) {
        console.error("Fetch Upcoming Error:", err.message);
        res.status(500).json({ error: err.message });
    }
});

/**
 * GET: Retrieve Maintenance Status
 * This is used to see a list of every room that is 
 * currently under repair or "Locked" for maintenance.
 */
app.get('/api/maintenance/status', async(req, res) => {
    try {
        // Asking the database to show us all rooms inside the maintenance table.
        const result = await pool.query('SELECT * FROM room_maintenance');

        // Sending the list of locked rooms back to the dashboard.
        res.json(result.rows);
    } catch (err) {
        // If something goes wrong with the database, send an error message.
        res.status(500).json({ error: err.message });
    }
});

/**
 * POST: Lock a Room for Maintenance
 * Think of this as putting an "Under Repair" sign on a door.
 */
app.post('/api/maintenance/lock', async(req, res) => {
    // The "room_id" is which room to lock, and "reason" is why (like "Broken AC").
    const { room_id, reason } = req.body;

    try {
        /**
         * "ON CONFLICT" Logic: 
         * If the room is NOT in the table yet, it adds it (Locks the room).
         * If the room is ALREADY in the table, it just updates the reason.
         */
        const query = `
            INSERT INTO room_maintenance (room_id, reason) 
            VALUES ($1, $2) 
            ON CONFLICT (room_id) DO UPDATE SET reason = $2
            RETURNING *`;

        const result = await pool.query(query, [room_id, reason]);

        // Sending back a success message so the Admin knows the room is now locked.
        res.json({ success: true, data: result.rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Database error" });
    }
});

/**
 * DELETE: Unlock a Room (Remove Maintenance)
 * Used when the repair is finished and the room is ready for students again.
 */
app.delete('/api/maintenance/unlock/:room_id', async(req, res) => {
    // We get the room number from the URL address.
    const { room_id } = req.params;

    try {
        // Telling the database to remove this room from the maintenance list.
        // Once removed, the room is "Unlocked" and can be used again.
        await pool.query('DELETE FROM room_maintenance WHERE room_id = $1', [room_id]);

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to unlock room" });
    }
});

/**GET: Analytics Statistics - UPDATED FOR TODAY ONLY DEMAND*/
app.get('/api/analytics/stats', async(req, res) => {
    try {
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        
        // ==========================================================
        // FIX #1: GUMAMIT NG TIMEZONE-AWARE DATE PARA SA PILIPINAS
        // ==========================================================
        const today = new Date();
        const todayStr = days[today.getDay()];
        
        // Kunin ang pangalan ng araw ngayon (e.g., 'Thursday') at petsa ngayon (YYYY-MM-DD) base sa local time zone
        const phDayName = today.toLocaleDateString('en-US', { weekday: 'long', timeZone: 'Asia/Manila' });
        const todayDate = today.toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' }); 

        // Status condition variable niyo
        const activeStatusFilter = "status NOT IN ('CANCELLED', 'REJECTED')";

        // 1. Today's Total Usage (Fixed + Approved/Pending) - Exclude Sunday
        let todayCount = 0;
        if (todayStr !== 'Sunday') {
            const todayCountQuery = `
                SELECT 
                    (SELECT COUNT(*) FROM fixed_schedules WHERE day_of_week = $1 AND is_cancelled = false) +
                    (SELECT COUNT(*) FROM reservations WHERE date = $2 AND ${activeStatusFilter}) as total
            `;
            const todayCountRes = await pool.query(todayCountQuery, [phDayName, todayDate]);
            todayCount = parseInt(todayCountRes.rows[0].total) || 0;
        }

        // ==========================================================
        // FIX #2: ROOM DEMAND FOR TODAY ONLY (Sinala para sa araw na ito)
        // ==========================================================
        const roomDemandQuery = `
            SELECT room, COUNT(*)::int as usage_count FROM (
                -- 1. Kunin LANG ang mga fixed classes para sa ARAW NA ITO NGAYON
                SELECT 
                    CASE 
                        WHEN TRIM(CAST(room_id AS VARCHAR)) NOT LIKE 'Room%' 
                        THEN 'Room ' || TRIM(CAST(room_id AS VARCHAR))
                        ELSE TRIM(CAST(room_id AS VARCHAR))
                    END as room 
                FROM fixed_schedules 
                WHERE is_cancelled = false 
                  AND day_of_week = $1 -- 👈 BAGONG FILTER: Kung anong araw lang ngayon (e.g., Thursday)
                
                UNION ALL
                
                -- 2. Kunin LANG ang mga reservations para sa PETSA NGAYON
                SELECT 
                    CASE 
                        WHEN TRIM(CAST(room AS VARCHAR)) NOT LIKE 'Room%' 
                        THEN 'Room ' || TRIM(CAST(room AS VARCHAR))
                        ELSE TRIM(CAST(room AS VARCHAR))
                    END as room 
                FROM reservations 
                WHERE ${activeStatusFilter} 
                  AND date = $2 -- 👈 BAGONG FILTER: Petsa lang ngayon (Today)
            ) combined
            WHERE room IS NOT NULL AND room != ''
            GROUP BY room
            ORDER BY usage_count DESC
        `;

        // Ipasa ang [phDayName, todayDate] para salain ang magkabilang table
        const roomDemandRes = await pool.query(roomDemandQuery, [phDayName, todayDate]);
        const roomStats = roomDemandRes.rows;
        
        const topRoom = roomStats[0] ? { room: roomStats[0].room, usage_count: roomStats[0].usage_count } : { room: '---', usage_count: 0 };

        // ==========================================================
        // FIX #3: PEAK HOUR FOR TODAY ONLY (Para tugma sa room demand)
        // ==========================================================
        const peakHourQuery = `
            SELECT hour, COUNT(*) as count FROM (
                SELECT generate_series(
                    EXTRACT(HOUR FROM (start_time::time))::int, 
                    EXTRACT(HOUR FROM ((end_time::time) - interval '1 minute'))::int
                ) as hour 
                FROM fixed_schedules 
                WHERE is_cancelled = false AND day_of_week = $1 -- 👈 Ngayong araw lang
                UNION ALL
                SELECT generate_series(
                    EXTRACT(HOUR FROM (start_time::time))::int, 
                    EXTRACT(HOUR FROM ((end_time::time) - interval '1 minute'))::int
                ) as hour 
                FROM reservations 
                WHERE ${activeStatusFilter} AND date = $2 -- 👈 Ngayong araw lang
            ) combined
            GROUP BY hour
            ORDER BY count DESC, hour ASC
            LIMIT 1
        `;
        const peakHourRes = await pool.query(peakHourQuery, [phDayName, todayDate]);
        let peakHour = "---";
        if (peakHourRes.rows.length > 0) {
            const hour = parseInt(peakHourRes.rows[0].hour);
            const nextHour = (hour + 1) % 24; 
            
            const formatHour = (h) => {
                const ampm = h >= 12 ? 'PM' : 'AM';
                const displayH = h % 12 || 12;
                return `${displayH} ${ampm}`;
            };
            
            peakHour = `${formatHour(hour)} - ${formatHour(nextHour)}`;
        }

        // ==========================================================
        // FIX #4: 7-DAY TREND LOOP (Mananatiling intact)
        // ==========================================================
        const trend = [];
        let i = 0;
        let daysCounted = 0;
        while (daysCounted < 7) {
            const d = new Date();
            d.setDate(d.getDate() - i);
            const dayName = days[d.getDay()];

            if (dayName !== 'Sunday') {
                const dateStr = d.toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' });
                
                const countQuery = `
                    SELECT 
                        (SELECT COUNT(*) FROM fixed_schedules WHERE day_of_week = $1 AND is_cancelled = false) +
                        (SELECT COUNT(*) FROM reservations WHERE date = $2 AND ${activeStatusFilter}) as total
                `;
                const countRes = await pool.query(countQuery, [dayName, dateStr]);
                trend.push({
                    day: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
                    count: parseInt(countRes.rows[0].total) || 0
                });
                daysCounted++;
            }
            i++;
            if (i > 14) break; 
        }
        trend.reverse(); 

        // Ibalik ang malinis at fully repaired object sa frontend admin panel
        res.json({
            todayCount,
            topRoom,
            peakHour,
            roomStats,
            trend
        });
    } catch (err) {
        console.error("Analytics Sync Error:", err.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// ==========================================================
// ENDPOINT #1: EXCEL REPORT GENERATOR (7, 14, 30 Days)
// ==========================================================
app.get('/api/reports/excel', async (req, res) => {
    try {
        // Kinuha ang targetMonth at currentYear gaya ng sa PDF para walang error sa query
        const targetMonth = req.query.month ? parseInt(req.query.month) : 5; // Default sa 5 (May)
        const currentYear = new Date().getFullYear(); // 2026

        const workbook = new ExcelJS.Workbook();
        const sheet = workbook.addWorksheet('RAIMIS Audit Log');
        
        sheet.views = [{ showGridLines: true }];

        // Design Styles (Excel "CSS")
        const headerFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1E3A8A' } }; 
        const zebraFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F8FAFC' } };  
        
        // 🎨 Naka-map na kulay para sa Status Fills at Fonts
        const presentFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'DCFCE7' } }; // Light Green Background
        const presentFont = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '15803D' } }; // Dark Green Text

        const absentFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FEE2E2' } }; // Light Red Background
        const absentFont = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '991B1B' } }; // Dark Red Text
        
        const headerFont = { name: 'Segoe UI', size: 11, bold: true, color: { argb: 'FFFFFF' } };
        const bodyFont = { name: 'Segoe UI', size: 10 };

        const thinBorder = {
            top: { style: 'thin', color: { argb: 'CBD5E1' } },
            left: { style: 'thin', color: { argb: 'CBD5E1' } },
            bottom: { style: 'thin', color: { argb: 'CBD5E1' } },
            right: { style: 'thin', color: { argb: 'CBD5E1' } }
        };

        // SETUP COLUMNS
        sheet.columns = [
            { header: 'Type', key: 'type', width: 14 }, // Inayos ang key para magtugma sa SQL ('type')
            { header: 'Room', key: 'room', width: 12 }, 
            { header: 'Subject/Purpose', key: 'subject', width: 30 },
            { header: 'Course & Section', key: 'section', width: 15 },
            { header: 'Professor', key: 'professor', width: 22 },
            { header: 'Day of Week', key: 'sched_day', width: 14 },
            { header: 'Exact Date', key: 'exact_date', width: 14 }, 
            { header: 'Time Slot', key: 'time_window', width: 22 }, 
            { header: 'Status', key: 'status', width: 16 }
        ];

        // Style sa Header Row
        sheet.getRow(1).eachCell((cell) => {
            cell.fill = headerFill;
            cell.font = headerFont;
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
            cell.border = thinBorder;
        });
        sheet.getRow(1).height = 26;

        // =========================================================================
        // SQL QUERY: KAPAREHAS NA KAPAREHAS NG LOGIC SA PDF REPORT
        // =========================================================================
        const reportQuery = `
            SELECT 
                'RESERVATION' as type, 
                CASE 
                    WHEN TRIM(CAST(room AS VARCHAR)) NOT LIKE 'Room%' THEN 'Room ' || TRIM(CAST(room AS VARCHAR)) 
                    ELSE TRIM(CAST(room AS VARCHAR)) 
                END as room, 
                subject, 
                professor, 
                COALESCE(section, 'N/A') as section, 
                TRIM(to_char(date, 'Day')) as sched_day,
                date::text as exact_date, 
                to_char(start_time::time, 'HH:MI AM') || ' - ' || to_char(end_time::time, 'HH:MI AM') as time_window, 
                'PRESENT' as status -- 🌟 APPROVED RESERVATIONS ay ginawa na ding 'PRESENT'
            FROM reservations 
            WHERE EXTRACT(MONTH FROM date) = ${targetMonth} 
            AND EXTRACT(YEAR FROM date) = ${currentYear}
            AND UPPER(status) = 'APPROVED' -- Sinasala para APPROVED lang talaga ang makasama
            
            UNION ALL
            
            SELECT 
                'FIXED CLASS' as type, 
                'Room ' || TRIM(CAST(fs.room_id AS VARCHAR)) as room, 
                fs.subject, 
                fs.professor, 
                TRIM(CAST(fs.course_section AS VARCHAR)) as section,   
                TRIM(fs.day_of_week) as sched_day,
                to_char(fs.created_at, 'YYYY-MM-DD') as exact_date,    
                to_char(fs.start_time::time, 'HH:MI AM') || ' - ' || to_char(fs.end_time::time, 'HH:MI AM') as time_window, 
                
                -- FIXED CLASS PRESENT/ABSENT LOGIC
                CASE 
                    WHEN rc.id IS NOT NULL THEN 'ABSENT' 
                    ELSE 'PRESENT' 
                END as status
            FROM fixed_schedules fs
            LEFT JOIN room_cancellations rc ON fs.id = rc.schedule_id 
                AND rc.cancelled_date = fs.created_at::date
            WHERE EXTRACT(MONTH FROM fs.created_at) = ${targetMonth} 
            AND EXTRACT(YEAR FROM fs.created_at) = ${currentYear}
            
            ORDER BY exact_date DESC, time_window ASC;
        `;
        
        const dataRes = await pool.query(reportQuery);

        dataRes.rows.forEach((rowData, index) => {
            const row = sheet.addRow(rowData);
            row.height = 20;
            const isEven = index % 2 === 0;

            row.eachCell((cell, colNumber) => {
                cell.font = bodyFont;
                cell.border = thinBorder;
                cell.alignment = { vertical: 'middle', horizontal: 'left' };

                // I-center align ang mga maiikling codes o petsa (Columns 1, 2, 4, 6, 7, 8, 9)
                if ([1, 2, 4, 6, 7, 8, 9].includes(colNumber)) {
                    cell.alignment = { vertical: 'middle', horizontal: 'center' };
                }

                // Zebra striping para sa alternating rows
                if (isEven) cell.fill = zebraFill;

                // 🌟 DYNAMIC COLORING PARA SA STATUS COLUMN (Column 9)
                if (colNumber === 9) {
                    if (cell.value === 'PRESENT') {
                        cell.fill = presentFill;
                        cell.font = presentFont;
                    } else if (cell.value === 'ABSENT') {
                        cell.fill = absentFill;
                        cell.font = absentFont;
                    }
                }
            });
        });

        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename=RAIMIS_Report_${monthNames[targetMonth - 1]}_${currentYear}.xlsx`);
        
        await workbook.xlsx.write(res);
        res.end();

    } catch (err) {
        console.error("EXCEL ERROR:", err.message);
        res.status(500).send(`Database error: ${err.message}`);
    }
});
// ==========================================================
// ENDPOINT #2: PDF REPORT GENERATOR (7, 14, 30 Days)
// ==========================================================
app.get('/api/reports/pdf', async (req, res) => {
    try {
        const targetMonth = req.query.month ? parseInt(req.query.month) : 5; 
        const currentYear = new Date().getFullYear(); 

        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=RAIMIS_Report_Month_${targetMonth}.pdf`);

        const doc = new PDFDocument({ layout: 'landscape', margin: 30 });
        doc.pipe(res);

        // BANNER BACKGROUND
        doc.rect(0, 0, 792, 60).fill('#1E3A8A'); 
        doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(15).text('RAIMIS SYSTEM LOGS AUDIT', 30, 22);
        
        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        doc.fillColor('#93C5FD').font('Helvetica-Oblique').fontSize(9).text(`Scope Duration: Month of ${monthNames[targetMonth - 1]} ${currentYear}`, 30, 42, { align: 'right', width: 732 });

        let currentY = 85;
        doc.rect(30, currentY, 732, 22).fill('#334155');
        
        const cleanColumns = [
            { label: 'Type', x: 35, width: 80 }, 
            { label: 'Room', x: 120, width: 60 }, 
            { label: 'Subject Description', x: 185, width: 130 },
            { label: 'Course/Sec', x: 320, width: 75 }, 
            { label: 'Professor', x: 400, width: 90 }, 
            { label: 'Day', x: 495, width: 55 },
            { label: 'Exact Date', x: 555, width: 60 }, 
            { label: 'Time Slot', x: 620, width: 80 }, 
            { label: 'Status', x: 705, width: 55 }
        ];

        doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(8.5);
        cleanColumns.forEach(col => { doc.text(col.label, col.x, currentY + 6); });
        currentY += 22;

        // =========================================================================
        // SQL QUERY: APPROVED RESERVATIONS MAPPA-MAP NA DIN SA 'PRESENT'
        // =========================================================================
        const reportQuery = `
            SELECT 
                'RESERVATION' as type, 
                CASE 
                    WHEN TRIM(CAST(room AS VARCHAR)) NOT LIKE 'Room%' THEN 'Room ' || TRIM(CAST(room AS VARCHAR)) 
                    ELSE TRIM(CAST(room AS VARCHAR)) 
                END as room, 
                subject, 
                professor, 
                COALESCE(section, 'N/A') as section, 
                TRIM(to_char(date, 'Day')) as sched_day,
                date::text as exact_date, 
                to_char(start_time::time, 'HH:MI AM') || ' - ' || to_char(end_time::time, 'HH:MI AM') as time_window, 
                'PRESENT' as status -- 🌟 MAPPED: Lahat ng approved reservations ay 'PRESENT' na ang lalabas
            FROM reservations 
            WHERE EXTRACT(MONTH FROM date) = ${targetMonth} 
            AND EXTRACT(YEAR FROM date) = ${currentYear}
            AND UPPER(status) = 'APPROVED' -- Sinasala pa rin para approved lang ang makapasok
            
            UNION ALL
            
            SELECT 
                'FIXED CLASS' as type, 
                'Room ' || TRIM(CAST(fs.room_id AS VARCHAR)) as room, 
                fs.subject, 
                fs.professor, 
                TRIM(CAST(fs.course_section AS VARCHAR)) as section,   
                TRIM(fs.day_of_week) as sched_day,
                to_char(fs.created_at, 'YYYY-MM-DD') as exact_date,    
                to_char(fs.start_time::time, 'HH:MI AM') || ' - ' || to_char(fs.end_time::time, 'HH:MI AM') as time_window, 
                
                CASE 
                    WHEN rc.id IS NOT NULL THEN 'ABSENT' 
                    ELSE 'PRESENT' 
                END as status
            FROM fixed_schedules fs
            LEFT JOIN room_cancellations rc ON fs.id = rc.schedule_id 
                AND rc.cancelled_date = fs.created_at::date
            WHERE EXTRACT(MONTH FROM fs.created_at) = ${targetMonth} 
            AND EXTRACT(YEAR FROM fs.created_at) = ${currentYear}
            
            ORDER BY exact_date DESC, time_window ASC;
        `;
        
        const result = await pool.query(reportQuery);

        doc.font('Helvetica').fontSize(7.5); 
        result.rows.forEach((row, index) => {
            if (currentY > 530) { 
                doc.addPage({ layout: 'landscape', margin: 30 }); 
                currentY = 40; 
            }
            
            if (index % 2 === 0) { doc.rect(30, currentY, 732, 24).fill('#F8FAFC'); }
            
            doc.fillColor('#0F172A'); 
            doc.text(row.type, cleanColumns[0].x, currentY + 7);
            doc.text(row.room, cleanColumns[1].x, currentY + 7);
            
            doc.text(row.subject, cleanColumns[2].x, currentY + 7, { width: cleanColumns[2].width, height: 14, ellipsis: true }); 
            doc.text(row.section, cleanColumns[3].x, currentY + 7); 
            
            doc.text(row.professor, cleanColumns[4].x, currentY + 7, { width: cleanColumns[4].width, height: 14, ellipsis: true });
            
            doc.text(row.sched_day, cleanColumns[5].x, currentY + 7);
            doc.text(row.exact_date, cleanColumns[6].x, currentY + 7);
            doc.text(row.time_window, cleanColumns[7].x, currentY + 7); 

            // 🎨 PINASIMPLESENG COLOR ENGINE (PRESENT o ABSENT na lang)
            if (row.status === 'ABSENT') {
                doc.fillColor('#DC2626').font('Helvetica-Bold').text(row.status, cleanColumns[8].x, currentY + 7).font('Helvetica');
            } else {
                // Berde para sa lahat ng 'PRESENT' (Fixed classes at Approved Reservations)
                doc.fillColor('#16A34A').font('Helvetica-Bold').text(row.status, cleanColumns[8].x, currentY + 7).font('Helvetica');
            }
            
            doc.strokeColor('#E2E8F0').lineWidth(0.5).moveTo(30, currentY + 24).lineTo(762, currentY + 24).stroke();
            currentY += 24; 
        });

        doc.end();
    } catch (err) {
        console.error("PDF ERROR:", err.message);
        res.status(500).send(`Database error: ${err.message}`);
    }
});
// =====================================================
// 3. SERVER INITIALIZATION
// =====================================================
app.listen(PORT, IP_ADDRESS, () => {
    console.log(`🚀 RAIMIS Server is running on http://${IP_ADDRESS}:${PORT}`);
    console.log(`📡 Local Network Access: Ready`);
});